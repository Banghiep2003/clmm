<?php session_start(); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/head.php'); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/nav.php'); ?>
<?php
// cài đặt chung
$setting = $soicoder->fetch_assoc("SELECT * FROM `settings` ", 1);
// điểm danh nhận quà
$attendance = $soicoder->fetch_assoc("SELECT * FROM `attendance` ", 1);
// top
$top_up = $soicoder->fetch_assoc("SELECT * FROM `top_up` ", 0);
$top = $top_up[0];
$sdt_fake = $top_up[1];
$top_fake = $top_up[2];
// nhiệm vụ ngày
$day_mission = $soicoder->fetch_assoc("SELECT * FROM `day_miss_up` ", 0);
$landmark = $day_mission[0];
$day_mission_bonus = $day_mission[1];
?>
<!-- Content -->
<div class="content">
    <div class="content__inner">
        <div class="content__inner__heading">
            <p>Cài đặt</p>
            <span> >&ensp; Minigame&ensp;></span>
            <span>Cài đặt</span>
        </div>
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__ant__card">
                    <div class="momo__card__info__notify">
                        <p>
                            Cài Đặt Chung, Top Thắng Tuần, Top Fake, Nhiệm Vụ Ngày Tại Đây
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="card card-body">
            <!-- Website -->
            <div class="general__body__list">
                <div class="row">
                    <div class="general__body__item col-md-12">
                        <h1 class="general__body__item__title">
                            Website
                        </h1>
                        <form action="/api/momo/settingall" method="POST" class="general__body__item__form">
                            <input type="hidden" name="type" value="config"/>
                            <div class="form-group">
                                <label>Bật website</label>
                                <label class="switch">
                                    <input type="checkbox" name="status" value="<?=$setting['status'];?>" <?php if ($setting['status'] == 'on') { echo "checked"; } ?> />
                                    <span class="slider round"></span>
                                </label>
                            </div>
                            <div class="form-group">
                                <label for="account">Tài khoản MoMo</label>
                                <select class="form-control" id="theme" name="theme">
                                    <?php if ($setting['theme'] == '1') { ?>
                                        <option value="1">Theme 1</option>
                                        <option value="2">Theme 2</option>
                                    <?php } else { ?>
                                        <option value="2">Theme 2</option>
                                        <option value="1">Theme 1</option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>URL</label>
                                <input type="text" name="url" class="form-control" placeholder="Website URL" value="<?=$setting['url'];?>"/>
                            </div>

                            <div class="form-group">
                                <label>LINK FAVION</label>
                                <input type="text" name="favion" class="form-control" placeholder="URL FAVION" value="<?=$setting['favion'];?>"/>
                            </div>

                            <div class="form-group">
                                <label>LOGO</label>
                                <input type="text" name="logo" class="form-control" placeholder="LOGO" value="<?=$setting['logo'];?>" />
                            </div>

                            <div class="form-group">
                                <label>MÔ TẢ</label>
                                <input type="text" name="description" class="form-control" placeholder="MÔ TẢ" value="<?=$setting['description'];?>" />
                            </div>

                            <div class="form-group">
                                <label>TỪ KHÓA</label>
                                <input type="text" name="keyword" class="form-control" placeholder="TỪ KHÓA" value="<?=$setting['keyword'];?>" />
                            </div>

                            <div class="form-group">
                                <label>Giới hạn (Tối thiểu 1 LSGD tối đa 20 LSGD)</label>
                                <input type="text" name="limit_trans" class="form-control" placeholder="Limit chỉ nhập số" value="<?=$setting['limit_trans'];?>" />
                            </div>
                            <div class="form-group">
                                <label>Nội Dung Trả Thưởng</label>
                                <input type="text" name="content" class="form-control" placeholder="Chúc Mừng..." value="<?=$setting['content'];?>" />
                            </div>
                            <div class="form-group">
                                <label>Video Hướng Dẫn</label>
                                <input type="text" name="video" class="form-control" placeholder="https://youtube.com/..." value="<?=$setting['video'];?>" />
                            </div>
                            <div class="form-group">
                                <label>Telegram</label>
                                <input type="text" name="tele" class="form-control" placeholder="https://" value="<?=$setting['tele'];?>" />
                            </div>
                            <div class="form-group">
                                <label>Box Telegram</label>
                                <input type="text" name="box_tele" class="form-control" placeholder="https://" value="<?=$setting['box_tele'];?>" />
                            </div>
                            <div class="form-group">
                                <label>Box Zalo</label>
                                <input type="text" name="box_zalo" class="form-control" placeholder="https://" value="<?=$setting['box_zalo'];?>" />
                            </div>
                            <button type="submit" class="btn btn-success">Lưu</button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Close Website -->
            <!-- Điểm Danh -->
            <div class="general__body__list border-top">
                <div class="row">
                    <div class="general__body__item col-md-12">
                        <h1 class="general__body__item__title">
                            Điểm Danh Nhận Quà
                        </h1>
                        <form action="/api/momo/settingall" method="POST" class="general__body__item__form">
                            <input type="hidden" name="type" value="attendance"/>
                            <div class="form-group">
                                <label for="account">Tài khoản MoMo</label>
                                <select class="form-control" id="momo_reward" name="momo_reward">
                                    <?php
                                        if ($attendance['momo_reward'] == 'NULL') {
                                            echo '<option value="NULL">Chọn danh sách MoMo</option>';
                                        } else {
                                            echo '<option value="'.$attendance['momo_reward'].'">'.$attendance['momo_reward'].'</option>';
                                            echo '<option value="NULL">Chọn danh sách MoMo</option>';
                                        }
                                        $list = $soicoder->fetch_assoc("SELECT `id`, `phone`,`BALANCE` FROM `cron_momo` LIMIT 1000", 0);
                                        foreach ($list as $data) { 
                                            if ($attendance['momo_reward'] == $data['phone']) {
                                                continue;
                                            } else {
                                            ?>
                                            <option value= "<?=$data['phone'];?>"><?=$data['phone'];?> (<?=format_cash($data['BALANCE']);?>đ)</option>
                                    <?php }} ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Thời Gian Quay</label>
                                <input type="text" name="time_turn" class="form-control" placeholder="60" value="<?=$attendance['time_turn'];?>"/>
                            </div>
                            <div class="form-group">
                                <label>Số Tiền Min Nhận</label>
                                <input type="text" name="min" class="form-control" placeholder="10000" value="<?=$attendance['min'];?>" />
                            </div>
                            <div class="form-group">
                                <label>Số Tiền Max Nhận</label>
                                <input type="text" name="max" class="form-control" placeholder="100000" value="<?=$attendance['max'];?>" />
                            </div>
                            <div class="form-group">
                                <label>Tổng Tiền Đã Trao (Fake)</label>
                                <input type="text" name="sum_fake" class="form-control" placeholder="1039032" value="<?=$attendance['sum_fake'];?>" />
                            </div>
                            <button type="submit" class="btn btn-success">Lưu</button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Close Điểm Danh -->
            <!-- Top -->
            <div class="general__body__list border-top">
                <div class="row">
                    <div class="general__body__item col-md-4">
                        <h1 class="general__body__item__title">
                            Top Thắng Tuần
                        </h1>
                        <form action="/api/momo/settingall" method="POST" class="general__body__item__form">
                            <input type="hidden" name="type" value="top"/>
                            <div class="form-group">
                                <label>Top 1</label>
                                <input type="text" name="top1" class="form-control" placeholder="5.000" value="<?=$top['top1'];?>"/>
                            </div>
                            <div class="form-group">
                                <label>Top 2</label>
                                <input type="text" name="top2" class="form-control" placeholder="4.000" value="<?=$top['top2'];?>" />
                            </div>
                            <div class="form-group">
                                <label>Top 3</label>
                                <input type="text" name="top3" class="form-control" placeholder="3.000" value="<?=$top['top3'];?>" />
                            </div>
                            <div class="form-group">
                                <label>Top 4</label>
                                <input type="text" name="top4" class="form-control" placeholder="2.000" value="<?=$top['top4'];?>" />
                            </div>
                            <div class="form-group">
                                <label>Top 5</label>
                                <input type="text" name="top5" class="form-control" placeholder="1.000" value="<?=$top['top5'];?>" />
                            </div>

                            <!-- <div class="form-group">
                                <label>Hoạt động</label>
                                <label class="switch">
                                    <input type="checkbox" checked />
                                    <span class="slider round"></span>
                                </label>
                            </div> -->
                            <button type="submit" class="btn btn-success">Lưu</button>
                        </form>
                    </div>
                    <div class="general__body__item col-md-8">
                        <h1 class="general__body__item__title">
                            Top Fake
                        </h1>
                        <form action="/api/momo/settingall" method="POST" class="general__body__item__form row">
                            <input type="hidden" name="type" value="topfake"/>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Top 1</label>
                                    <input type="text" name="sdt1" class="form-control" placeholder="037656115" value="<?=$sdt_fake['top1'];?>" />
                                </div>
                                <div class="form-group">
                                    <label>Top 2</label>
                                    <input type="text" name="sdt2" class="form-control" placeholder="082654234" value="<?=$sdt_fake['top2'];?>" />
                                </div>
                                <div class="form-group">
                                    <label>Top 3</label>
                                    <input type="text" name="sdt3" class="form-control" placeholder="092853652" value="<?=$sdt_fake['top3'];?>" />
                                </div>
                                <div class="form-group">
                                    <label>Top 4</label>
                                    <input type="text" name="sdt4" class="form-control" placeholder="085685654" value="<?=$sdt_fake['top4'];?>" />
                                </div>
                                <div class="form-group">
                                    <label>Top 5</label>
                                    <input type="text" name="sdt5" class="form-control" placeholder="095625458" value="<?=$sdt_fake['top5'];?>" />
                                </div>
                                <div class="form-group">
                                    <label>Hoạt động</label>
                                    <label class="switch">
                                        <input type="checkbox" name="topfake" value="<?=$setting['topfake'];?>" <?php if ($setting['topfake'] == 'on') { echo "checked"; } ?> />
                                        <span class="slider round"></span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Tiền chơi</label>
                                    <input type="text" name="top1" class="form-control" placeholder="5,000,000" value="<?=$top_fake['top1'];?>" />
                                </div>
                                <div class="form-group">
                                    <label>Tiền chơi</label>
                                    <input type="text" name="top2" class="form-control" placeholder="5,001,000" value="<?=$top_fake['top2'];?>" />
                                </div>
                                <div class="form-group">
                                    <label>Tiền chơi</label>
                                    <input type="text" name="top3" class="form-control" placeholder="3,000,000" value="<?=$top_fake['top3'];?>" />
                                </div>
                                <div class="form-group">
                                    <label>Tiền chơi</label>
                                    <input type="text" name="top4" class="form-control" placeholder="2,000,000" value="<?=$top_fake['top4'];?>" />
                                </div>
                                <div class="form-group">
                                    <label>Tiền chơi</label>
                                    <input type="text" name="top5" class="form-control" placeholder="1,000,000" value="<?=$top_fake['top5'];?>" />
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success">Lưu</button>
                        </form>
                    </div>
                </div>
                <!-- Close Top -->
                <!-- Day Mission -->
                <div class="general__body__list border-top">
                    <div class="row">
                        <div class="general__body__item col-md-12">
                            <h1 class="general__body__item__title">
                                Nhiệm Vụ Ngày
                            </h1>
                            <form action="/api/momo/settingall" method="POST" class="general__body__item__form">
                                <input type="hidden" name="type" value="day_mission"/>
                                <div class="row">
                                    <div class="general__body__list col-md-6">
                                        <div class="form-group">
                                            <label>Ngưỡng mốc 1</label>
                                            <input type="text" name="landmark1" class="form-control" placeholder="1,000" value="<?=$landmark['top1'];?>"/>
                                            <small class="form-text text-muted">Số tiền chơi mốc 1</small>
                                        </div>
                                        <div class="form-group">
                                            <label>Ngưỡng mốc 2</label>
                                            <input type="text" name="landmark2" class="form-control" placeholder="1,500" value="<?=$landmark['top2'];?>"/>
                                            <small class="form-text text-muted">Số tiền chơi mốc 2</small>
                                        </div>
                                        <div class="form-group">
                                            <label>Ngưỡng mốc 3</label>
                                            <input type="text" name="landmark3" class="form-control" placeholder="2,000" value="<?=$landmark['top3'];?>"/>
                                            <small class="form-text text-muted">Số tiền chơi mốc 3</small>
                                        </div>
                                        <div class="form-group">
                                            <label>Ngưỡng mốc 4</label>
                                            <input type="text" name="landmark4" class="form-control" placeholder="2,500" value="<?=$landmark['top4'];?>"/>
                                            <small class="form-text text-muted">Số tiền chơi mốc 4</small>
                                        </div>
                                        <div class="form-group">
                                            <label>Ngưỡng mốc 5</label>
                                            <input type="text" name="landmark5" class="form-control" placeholder="3,000" value="<?=$landmark['top5'];?>"/>
                                            <small class="form-text text-muted">Số tiền chơi mốc 5</small>
                                        </div>
                                        <div class="form-group">
                                            <label>Tổng số tiền đã trao</label>
                                            <input type="text" name="sum_bonus" class="form-control" placeholder="60,000" value="<?=$landmark['sum_bonus'];?>"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="account">Tài khoản MoMo</label>
                                            <select class="form-control" id="momo_reward_daymiss" name="momo_reward_daymiss">
                                                <?php
                                                if ($setting['momo_reward_daymiss'] == 'NULL') {
                                                    echo '<option value="NULL">Chọn danh sách MoMo</option>';
                                                } else {
                                                    echo '<option value="'.$setting['momo_reward_daymiss'].'">'.$setting['momo_reward_daymiss'].'</option>';
                                                    echo '<option value="NULL">Chọn danh sách MoMo</option>';
                                                }
                                                $list = $soicoder->fetch_assoc("SELECT `id`, `phone`,`BALANCE` FROM `cron_momo` LIMIT 1000", 0);
                                                    foreach ($list as $data) { 
                                                        if ($setting['momo_reward_daymiss'] == $data['phone']) {
                                                            continue;
                                                        } else {
                                                    ?>
                                                <option value= "<?=$data['phone'];?>"><?=$data['phone'];?> (<?=format_cash($data['BALANCE']);?>đ)</option>
                                                <?php }} ?>
                                            </select>
                                        </div>
                                        <!-- <div class="form-group">
                                            <label>Hoạt động</label>
                                            <label class="switch">
                                                <input type="checkbox" name="status" checked />
                                                <span class="slider round"></span>
                                            </label>
                                        </div> -->
                                        
                                    </div>
                                

                                    <div class="general__body__list col-md-6">
                                        <div class="form-group">
                                            <label>Thưởng mốc 1</label>
                                            <input type="text" name="top1" class="form-control" placeholder="500" value="<?=$day_mission_bonus['top1'];?>"/>
                                            <small class="form-text text-muted">Số tiền thưởng mốc 1</small>
                                        </div>
                                        <div class="form-group">
                                            <label>Thưởng mốc 2</label>
                                            <input type="text" name="top2" class="form-control" placeholder="600" value="<?=$day_mission_bonus['top2'];?>"/>
                                            <small class="form-text text-muted">Số tiền thưởng mốc 2</small>
                                        </div>
                                        <div class="form-group">
                                            <label>Thưởng mốc 3</label>
                                            <input type="text" name="top3" class="form-control" placeholder="700" value="<?=$day_mission_bonus['top3'];?>"/>
                                            <small class="form-text text-muted">Số tiền thưởng mốc 3</small>
                                        </div>
                                        <div class="form-group">
                                            <label>Thưởng mốc 4</label>
                                            <input type="text" name="top4" class="form-control" placeholder="800" value="<?=$day_mission_bonus['top4'];?>"/>
                                            <small class="form-text text-muted">Số tiền thưởng mốc 4</small>
                                        </div>
                                        <div class="form-group">
                                            <label>Thưởng mốc 5</label>
                                            <input type="text" name="top5" class="form-control" placeholder="900" value="<?=$day_mission_bonus['top5'];?>"/>
                                            <small class="form-text text-muted">Số tiền thưởng mốc 5</small>
                                        </div>
                                        <div class="form-group">
                                            <label>Tổng giao dịch đã trao</label>
                                            <input type="text" name="sum_reward_daymiss" class="form-control" placeholder="0" value="<?=$day_mission_bonus['sum_bonus'];?>"/>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-success">Lưu</button>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- Close Day Mission -->
            </div>
        </div>




    </div>
    <!-- Close Content -->
</div>
<!-- Modal -->
<!-- Add User -->
<div class="modal fade" id="exampleAddUser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="background-color: #fff">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Thêm liên hệ</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="transfer__form row" style="margin-left: 0; width: 85%">
                    <form action="#">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" placeholder="Name"
                                style="text-align: inherit" />
                        </div>
                        <div class="form-group">
                            <label for="url">URL</label>
                            <input type="text" class="form-control" id="url" placeholder="URL"
                                style="text-align: inherit" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light mr-3" data-dismiss="modal">
                    Quay lại
                </button>
                <button type="button" data-dismiss="modal" class="btn btn-success">
                    Lưu
                </button>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Update User -->
<div class="modal fade" id="exampleUpdateUser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="background-color: #fff">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Thêm liên hệ</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="transfer__form row" style="margin-left: 0; width: 85%">
                    <form action="#">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" placeholder="box zalo"
                                style="text-align: inherit" />
                        </div>
                        <div class="form-group">
                            <label for="url">URL</label>
                            <input type="text" class="form-control" id="url" placeholder="demo7.webtienich.com"
                                style="text-align: inherit" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light mr-3" data-dismiss="modal">
                    Quay lại
                </button>
                <button type="button" data-dismiss="modal" class="btn btn-success">
                    Lưu
                </button>
            </div>
        </div>
    </div>
</div>
<!-- Delete User -->
<div class="modal fade" id="exampleDeleteUser" tabindex="-1" role="dialog" aria-labelledby="exampleDeleteUser"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="background-color: #fff">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color: #000">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h2 style="font-size: 22px">Xóa liên hệ</h2>
                <p>Bạn có chắc chắn muốn xoá liện hệ này này không?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light mr-3" data-dismiss="modal">
                    Hủy
                </button>
                <button type="button" data-dismiss="modal" class="btn btn-primary">
                    Xác nhận
                </button>
            </div>
        </div>
    </div>
</div>
</div>
<script src="../assets/scripts/collapse.js"></script>
<script src="../assets/scripts/navbar.js"></script>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>