<?php session_start(); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/head.php'); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/nav.php'); ?>
<?php

if (!isset($_GET['phone'])) {
  echo "<script language='javascript'>alert('Vui Lòng Chọn Số Để Cài Đặt');window.location='/';</script>";
} else {
  $phone = $_GET['phone'];
  $get = $soicoder->fetch_assoc("SELECT `id`, `phone`, `DataJson` FROM `cron_momo` WHERE `phone` = '".$phone."' LIMIT 1", 1);
  $data = json_decode($get['DataJson'], true);
}

?>
<!-- Content -->
<div class="content">
    <div class="content__inner">
        <div class="content__inner__heading">
            <p>Cài đặt</p>
            <span> >&ensp; Minigame&ensp;></span>
            <span>Cài đặt</span>
        </div>
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__ant__card">
                    <div class="momo__card__info__notify">
                        <p>
                            Cài đặt ở đây sẽ không được đồng bộ cho tất cả tài khoản momo của bạn.<br>
                            Để đồng bộ hóa vui lòng bấm vào nút "Đồng Bộ Tất Cả" ở cuối cùng<br>
                            Nếu không đồng bộ, hiển thị ở giao diện ngoài phần tỉ lệ trả thưởng sẽ là số momo đầu tiên từ dưới lên của mục danh sách momo<br>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__ant__card">
                    <div class="general__content">
                        <div class="general__info" type="button" data-toggle="collapse" data-target="#collapseExample"
                            aria-expanded="false" aria-controls="collapseExample">
                            <button class="btn general__btn">Cài đặt chẵn lẻ</button>
                        </div>
                        <div class="collapse" id="collapseExample">
                            <div class="card card-body">
                                <div class="general__body__list">
                                    <div class="row">
                                        <div class="general__body__item col-md-6">
                                            <h1 class="general__body__item__title">
                                                Chẵn lẻ
                                            </h1>
                                            <form action="/api/momo/setting" method="POST" class="general__body__item__form">
                                                <input type="hidden" name="phone" value="<?=$phone;?>"/>
                                                <input type="hidden" name="type" value="CL"/>
                                                <div class="form-group">
                                                    <label for="Commentn+2">Comment Chẵn</label>
                                                    <input type="text" class="form-control" name="cmt_C" placeholder="C" value="<?=$data['CL']['cmt_C'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định C</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Comment Lẻ</label>
                                                    <input type="text" class="form-control" name="cmt_L" placeholder="L" value="<?=$data['CL']['cmt_L'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định L</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối thiểu</label>
                                                    <input type="text" class="form-control" name="min" placeholder="100.000" value="<?=$data['CL']['min'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định 100,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối đa</label>
                                                    <input type="text" class="form-control" name="max" placeholder="1.000.000" value="<?=$data['CL']['max'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1,000,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ</label>
                                                    <input type="text" class="form-control" name="ratio" placeholder="2" value="<?=$data['CL']['ratio'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1
                                                    </small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Hoạt động</label>
                                                    <label class="switch">
                                                        <input type="checkbox" name="status" value="<?=$data['CL']['status'];?>" <?php if ($data['CL']['status'] == 'on') { echo "checked"; } ?> />
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                                <div class="form-group">
                                                    <label>Mặc định thua</label>
                                                    <input type="text" name="md_thua" class="form-control" placeholder="Mặc định thua" value="<?=$data['CL']['md_thua'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Mặc định hoàn tiền</label>
                                                    <input type="text" name="md_ht" class="form-control" placeholder="3,000" value="<?=$data['CL']['md_ht'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <button type="submit" class="btn btn-success">Lưu</button>
                                            </form>
                                        </div>
                                        <div class="general__body__item col-md-6">
                                            <h1 class="general__body__item__title">
                                                Chẵn lẻ 2
                                            </h1>
                                            <form action="/api/momo/setting" method="POST" class="general__body__item__form">
                                                <input type="hidden" name="phone" value="<?=$phone;?>"/>
                                                <input type="hidden" name="type" value="CL2"/>
                                                <div class="form-group">
                                                    <label for="Commentn+2">Comment Chẵn 2</label>
                                                    <input type="text" name="cmt_C" class="form-control" id="Commentn+2" placeholder="C2" value="<?=$data['CL2']['cmt_C'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc
                                                        định C2</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Comment Lẻ 2</label>
                                                    <input type="text" name="cmt_L" class="form-control" placeholder="L2" value="<?=$data['CL2']['cmt_L'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc
                                                        định L2</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối thiểu</label>
                                                    <input type="text" name="min" class="form-control" placeholder="100.000" value="<?=$data['CL2']['min'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc
                                                        định
                                                        100,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối đa</label>
                                                    <input type="text" name="max" class="form-control" placeholder="1.000.000" value="<?=$data['CL2']['max'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định
                                                        1,000,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ</label>
                                                    <input type="text" name="ratio" class="form-control" placeholder="1.9" value="<?=$data['CL2']['ratio'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định 1
                                                    </small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Hoạt động</label>
                                                    <label class="switch">
                                                        <input type="checkbox" name="status" value="<?=$data['CL2']['status'];?>" <?php if ($data['CL2']['status'] == 'on') { echo "checked"; } ?>/>
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                                <div class="form-group">
                                                    <label>Mặc định thua</label>
                                                    <input type="text" name="md_thua" class="form-control" placeholder="Mặc định thua" value="<?=$data['CL2']['md_thua'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Mặc định hoàn tiền</label>
                                                    <input type="text" name="md_ht" class="form-control" placeholder="3,000" value="<?=$data['CL2']['md_ht'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <button type="submit" class="btn btn-success">Lưu</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Cài đặt tài xỉu -->
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__ant__card">
                    <div class="general__content">
                        <div class="general__info" type="button" data-toggle="collapse" data-target="#collapseTaiXiu"
                            aria-expanded="false" aria-controls="collapseTaiXiu">
                            <button class="btn general__btn">Cài đặt tài xỉu</button>
                        </div>
                        <div class="collapse" id="collapseTaiXiu">
                            <div class="card card-body">
                                <div class="general__body__list">
                                    <div class="row">
                                        <div class="general__body__item col-md-6">
                                            <h1 class="general__body__item__title">
                                                Tài xỉu
                                            </h1>
                                            <form action="/api/momo/setting" method="POST" class="general__body__item__form">
                                                <input type="hidden" name="phone" value="<?=$phone;?>"/>
                                                <input type="hidden" name="type" value="TX"/>
                                                <div class="form-group">
                                                    <label for="Commentn+2">Comment Tài</label>
                                                    <input type="text" name="cmt_T" class="form-control" id="Commentn+2" placeholder="X" value="<?=$data['TX']['cmt_T'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định T</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Comment Xỉu</label>
                                                    <input type="text" name="cmt_X" class="form-control" placeholder="X" value="<?=$data['TX']['cmt_X'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định X</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối thiểu</label>
                                                    <input type="text" name="min" class="form-control" placeholder="100.000" value="<?=$data['TX']['min'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc
                                                        định
                                                        100,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối đa</label>
                                                    <input type="text" name="max" class="form-control" placeholder="1.000.000" value="<?=$data['TX']['max'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định
                                                        1,000,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ</label>
                                                    <input type="text" name="ratio" class="form-control" placeholder="2.1" value="<?=$data['TX']['ratio'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định 1
                                                    </small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Hoạt động</label>
                                                    <label class="switch">
                                                        <input type="checkbox" name="status" value="<?=$data['TX']['status'];?>" <?php if ($data['TX']['status'] == 'on') { echo "checked"; } ?> />
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                                <div class="form-group">
                                                    <label>Mặc định thua</label>
                                                    <input type="text" name="md_thua" class="form-control" placeholder="0,9" value="<?=$data['TX']['md_thua'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu
                                                        phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Mặc định hoàn tiền</label>
                                                    <input type="text" name="md_ht" class="form-control" placeholder="3,000" value="<?=$data['TX']['md_ht'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <button type="submit" class="btn btn-success">Lưu</button>
                                            </form>
                                        </div>
                                        <div class="general__body__item col-md-6">
                                            <h1 class="general__body__item__title">
                                                Tải xỉu 2
                                            </h1>
                                            <form action="/api/momo/setting" method="POST" class="general__body__item__form">
                                                <input type="hidden" name="phone" value="<?=$phone;?>"/>
                                                <input type="hidden" name="type" value="TX2"/>
                                                <div class="form-group">
                                                    <label for="Commentn+2">Comment Tài</label>
                                                    <input type="text" name="cmt_T" class="form-control" id="Commentn+2" placeholder="T2" value="<?=$data['TX2']['cmt_T'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định T2</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Comment xỉu</label>
                                                    <input type="text" name="cmt_X" class="form-control" placeholder="X2" value="<?=$data['TX2']['cmt_X'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định X2</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối thiểu</label>
                                                    <input type="text" name="min" class="form-control" placeholder="100.000" value="<?=$data['TX2']['min'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định 100,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối đa</label>
                                                    <input type="text" name="max" class="form-control" placeholder="1.000.000" value="<?=$data['TX2']['max'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định
                                                        1,000,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ</label>
                                                    <input type="text" name="ratio" class="form-control" placeholder="1.9" value="<?=$data['TX2']['ratio'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1
                                                    </small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Hoạt động</label>
                                                    <label class="switch">
                                                        <input type="checkbox" name="status" value="<?=$data['TX2']['status'];?>" <?php if ($data['TX2']['status'] == 'on') { echo "checked"; } ?> />
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                                <div class="form-group">
                                                    <label>Mặc định thua</label>
                                                    <input type="text" name="md_thua" class="form-control" placeholder="Mặc định thua" value="<?=$data['TX2']['md_thua'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Mặc định hoàn tiền</label>
                                                    <input type="text" name="md_ht" class="form-control" placeholder="3,000" value="<?=$data['TX2']['md_ht'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <button class="btn btn-success">Lưu</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- close Cài đặt tài xỉu -->
        <!-- ------------------------- -->
        <!-- Cài đặt X3, Gấp 3, Tổng 3 số, Lô  -->
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__ant__card">
                    <div class="general__content">
                        <div class="general__info" type="button" data-toggle="collapse" data-target="#collapseX3"
                            aria-expanded="false" aria-controls="collapseX3">
                            <button class="btn general__btn">
                                Cài đặt X3, Gấp 3, Tổng 3 số, Lô
                            </button>
                        </div>
                        <div class="collapse" id="collapseX3">
                            <div class="card card-body">
                                <div class="general__body__list">
                                    <div class="row">
                                        <div class="general__body__item col-md-6">
                                            <h1 class="general__body__item__title">
                                                Một Phần 3
                                            </h1>
                                            <form action="/api/momo/setting" method="POST" class="general__body__item__form">
                                                <input type="hidden" name="phone" value="<?=$phone;?>"/>
                                                <input type="hidden" name="type" value="1P3"/>
                                                <div class="form-group">
                                                    <label>Comment N0</label>
                                                    <input type="text" name="cmt_N0" class="form-control" placeholder="N0" value="<?=$data['1P3']['cmt_N0'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định N0</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Comment N1</label>
                                                    <input type="text" name="cmt_N1" class="form-control" placeholder="N1" value="<?=$data['1P3']['cmt_N1'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định N1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Comment N2</label>
                                                    <input type="text" name="cmt_N2" class="form-control" placeholder="N2" value="<?=$data['1P3']['cmt_N2'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định N2</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Comment N3</label>
                                                    <input type="text" name="cmt_N3" class="form-control" placeholder="N3" value="<?=$data['1P3']['cmt_N3'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định N3</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối thiểu</label>
                                                    <input type="text" name="min" class="form-control" placeholder="100.000" value="<?=$data['1P3']['min'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định 100,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối đa</label>
                                                    <input type="text" name="max" class="form-control" placeholder="1.000.000" value="<?=$data['1P3']['max'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1,000,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ N0</label>
                                                    <input type="text" name="ratio_N0" class="form-control" placeholder="6" value="<?=$data['1P3']['ratio_N0'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 6</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ N1</label>
                                                    <input type="text" name="ratio_N1" class="form-control" placeholder="3" value="<?=$data['1P3']['ratio_N1'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 3</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ N2</label>
                                                    <input type="text" name="ratio_N2" class="form-control" placeholder="3" value="<?=$data['1P3']['ratio_N2'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 3</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ N3</label>
                                                    <input type="text" name="ratio_N3" class="form-control" placeholder="3" value="<?=$data['1P3']['ratio_N3'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Hoạt động</label>
                                                    <label class="switch">
                                                        <input type="checkbox" name="status" value="<?=$data['1P3']['status'];?>" <?php if ($data['1P3']['status'] == 'on') { echo "checked"; } ?> />
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                                <button type="submit" class="btn btn-success">Lưu</button>
                                            </form>
                                        </div>
                                        <div class="general__body__item col-md-6">
                                            <h1 class="general__body__item__title">Gấp 3</h1>
                                            <form action="/api/momo/setting" method="POST" class="general__body__item__form">
                                                <input type="hidden" name="phone" value="<?=$phone;?>"/>
                                                <input type="hidden" name="type" value="G3"/>
                                                <div class="form-group">
                                                    <label>Comment</label>
                                                    <input type="text" name="cmt" class="form-control" placeholder="G3" value="<?=$data['G3']['cmt'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định G3</small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Số tiền tối thiểu</label>
                                                    <input type="text" name="min" class="form-control" placeholder="100.000" value="<?=$data['G3']['min'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định 100,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối đa</label>
                                                    <input type="text" name="max" class="form-control" placeholder="1.000.000" value="<?=$data['G3']['max'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1,000,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 2 (2 số cuối mã GD)</label>
                                                    <input type="text" name="rules_2" class="form-control" placeholder="69,66,99" value="<?=$data['G3']['rules_2'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ Rules 2 </label>
                                                    <input type="text" name="ratio_2" class="form-control" placeholder="4" value="<?=$data['G3']['ratio_2'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 3 (2 số cuối mã GD)</label>
                                                    <input type="text" name="rules_3" class="form-control" placeholder="123,234,456,678,789" value="<?=$data['G3']['rules_3'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ Rules 3 </label>
                                                    <input type="text" name="ratio_3" class="form-control" placeholder="5" value="<?=$data['G3']['ratio_3'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Hoạt động</label>
                                                    <label class="switch">
                                                        <input name="status" type="checkbox" value="<?=$data['G3']['status'];?>" <?php if ($data['G3']['status'] == 'on') { echo "checked"; } ?> />
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                                <button type="submit" class="btn btn-success">Lưu</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="general__body__list border-top">
                                    <div class="row">
                                        <div class="general__body__item col-md-6">
                                            <h1 class="general__body__item__title">
                                                Tổng số 3
                                            </h1>
                                            <form action="/api/momo/setting" method="POST" class="general__body__item__form">
                                                <input type="hidden" name="phone" value="<?=$phone;?>"/>
                                                <input type="hidden" name="type" value="T3S"/>
                                                <div class="form-group">
                                                    <label>Comment</label>
                                                    <input type="text" name="cmt" class="form-control" placeholder="S" value="<?=$data['T3S']['cmt'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định S</small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Số tiền tối thiểu</label>
                                                    <input type="text" name="min" class="form-control" placeholder="100.000" value="<?=$data['T3S']['min'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định 100,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối đa</label>
                                                    <input type="text" name="max" class="form-control" placeholder="1.000.000" value="<?=$data['T3S']['max'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1,000,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 1 (2 số cuối mã GD)</label>
                                                    <input type="text" name="rules_1" class="form-control" placeholder="7,17,27" value="<?=$data['T3S']['rules_1'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ Rules 1 </label>
                                                    <input type="text" name="ratio_1" class="form-control" placeholder="3" value="<?=$data['T3S']['ratio_1'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 2 (2 số cuối mã GD)</label>
                                                    <input type="text" name="rules_2" class="form-control" placeholder="8,18" value="<?=$data['T3S']['rules_2'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ Rules 2 </label>
                                                    <input type="text" name="ratio_2" class="form-control" placeholder="4" value="<?=$data['T3S']['ratio_2'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 3 (2 số cuối mã GD)</label>
                                                    <input type="text" name="rules_3" class="form-control" placeholder="9,19" value="<?=$data['T3S']['rules_3'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ Rules 3 </label>
                                                    <input type="text" name="ratio_3" class="form-control" placeholder="5" value="<?=$data['T3S']['ratio_3'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1</small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Hoạt động</label>
                                                    <label class="switch">
                                                        <input name="status" type="checkbox" value="<?=$data['T3S']['status'];?>" <?php if ($data['T3S']['status'] == 'on') { echo "checked"; } ?> />
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                                <button type="submit" class="btn btn-success">Lưu</button>
                                            </form>
                                        </div>



                                        <div class="general__body__item col-md-6">
                                            <h1 class="general__body__item__title">
                                                Hiệu số 2
                                            </h1>
                                            <form action="/api/momo/setting" method="POST" class="general__body__item__form">
                                                <input type="hidden" name="phone" value="<?=$phone;?>"/>
                                                <input type="hidden" name="type" value="H2S"/>
                                                <div class="form-group">
                                                    <label>Comment</label>
                                                    <input type="text" name="cmt" class="form-control" placeholder="H3" value="<?=$data['H2S']['cmt'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định H3</small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Số tiền tối thiểu</label>
                                                    <input type="text" name="min" class="form-control" placeholder="100.000" value="<?=$data['H2S']['min'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định 100,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối đa</label>
                                                    <input type="text" name="max" class="form-control" placeholder="1.000.000" value="<?=$data['H2S']['max'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1,000,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 1 (2 số cuối mã GD)</label>
                                                    <input type="text" name="rules_1" class="form-control" placeholder="3" value="<?=$data['H2S']['rules_1'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ Rules 1 </label>
                                                    <input type="text" name="ratio_1" class="form-control" placeholder="3" value="<?=$data['H2S']['ratio_1'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 2 (2 số cuối mã GD)</label>
                                                    <input type="text" name="rules_2" class="form-control" placeholder="5" value="<?=$data['H2S']['rules_2'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ Rules 2 </label>
                                                    <input type="text" name="ratio_2" class="form-control" placeholder="5" value="<?=$data['H2S']['ratio_2'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 3 (2 số cuối mã GD)</label>
                                                    <input type="text" name="rules_3" class="form-control" placeholder="7" value="<?=$data['H2S']['rules_3'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ Rules 3 </label>
                                                    <input type="text" name="ratio_3" class="form-control" placeholder="7" value="<?=$data['H2S']['ratio_3'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 4 (2 số cuối mã GD)</label>
                                                    <input type="text" name="rules_4" class="form-control" placeholder="9" value="<?=$data['H2S']['rules_4'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ Rules 4 </label>
                                                    <input type="text" name="ratio_4" class="form-control" placeholder="9" value="<?=$data['H2S']['ratio_4'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Hoạt động</label>
                                                    <label class="switch">
                                                        <input type="checkbox" name="status" value="<?=$data['H2S']['status'];?>" <?php if ($data['H2S']['status'] == 'on') { echo "checked"; } ?> />
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                                <button type="submit" class="btn btn-success">Lưu</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>



                                
                                <div class="general__body__list border-top">
                                    <div class="row">
                                        <div class="general__body__item col-md-6">
                                            <h1 class="general__body__item__title">Lô</h1>
                                            <form action="/api/momo/setting" method="POST" class="general__body__item__form">
                                                <input type="hidden" name="phone" value="<?=$phone;?>"/>
                                                <input type="hidden" name="type" value="LO"/>
                                                <div class="form-group">
                                                    <label>Comment</label>
                                                    <input type="text" name="cmt" class="form-control" placeholder="LO" value="<?=$data['LO']['cmt'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định LO</small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Số tiền tối thiểu</label>
                                                    <input type="text" name="min" class="form-control" placeholder="100.000" value="<?=$data['LO']['min'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc định 100,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối đa</label>
                                                    <input type="text" name="max" class="form-control" placeholder="1.000.000" value="<?=$data['LO']['max'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1,000,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules (2 số cuối mã GD)</label>
                                                    <input type="text" name="rules" class="form-control" placeholder="24,18,38" value="<?=$data['LO']['rules'];?>"/>
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ Rules</label>
                                                    <input type="text"name="ratio" class="form-control" placeholder="4" value="<?=$data['LO']['ratio'];?>"/>
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc định 1</small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Hoạt động</label>
                                                    <label class="switch">
                                                        <input type="checkbox" name="status" value="<?=$data['LO']['status'];?>" <?php if ($data['CL2']['status'] == 'on') { echo "checked"; } ?> />
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                                <button type="submit" class="btn btn-success">Lưu</button>
                                            </form>
                                        </div>
                                        <div class="general__body__item col-md-6"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ------------------------- -->
        <!-- Cài đặt XSMB, Xiên  -->
        <!-- <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__ant__card">
                    <div class="general__content">
                        <div class="general__info" type="button" data-toggle="collapse" data-target="#collapseXSMB"
                            aria-expanded="false" aria-controls="collapseXSMB">
                            <button class="btn general__btn">
                                Cài đặt XSMB, Xiên
                            </button>
                        </div>
                        <div class="collapse" id="collapseXSMB">
                            <div class="card card-body">
                                <div class="general__body__list">
                                    <div class="row">
                                        <div class="general__body__item col-md-6">
                                            <h1 class="general__body__item__title">XSMB</h1>
                                            <form action="#" class="general__body__item__form">
                                                <div class="form-group">
                                                    <label>Comment</label>
                                                    <input type="text" class="form-control" placeholder="XS" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc
                                                        định XS</small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Số tiền tối thiểu</label>
                                                    <input type="text" class="form-control" placeholder="100.000" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc
                                                        định
                                                        100,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối đa</label>
                                                    <input type="text" class="form-control" placeholder="1.000.000" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định
                                                        1,000,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 1 (2 số cuối mã GD)</label>
                                                    <input type="text" class="form-control"
                                                        placeholder="55,86,41,85,04,77,45,95,48,71,24,77,00,40,91,55,11,08,58,00,70,56,01" />
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu
                                                        phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ Rules 1 </label>
                                                    <input type="text" class="form-control" placeholder="3.3" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 2 (2 số cuối mã GD)</label>
                                                    <input type="text" class="form-control" placeholder="77,44,57,13" />
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu
                                                        phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ Rules 2 </label>
                                                    <input type="text" class="form-control" placeholder="3.3" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 3 (2 số cuối mã GD)</label>
                                                    <input type="text" class="form-control"
                                                        placeholder="677,644,957,813" />
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu
                                                        phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ Rules 3 </label>
                                                    <input type="text" class="form-control" placeholder="3.3" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định 1</small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Hoạt động</label>
                                                    <label class="switch">
                                                        <input type="checkbox" checked />
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                                <button class="btn btn-success">Lưu</button>
                                            </form>
                                        </div>
                                        <div class="general__body__item col-md-6">
                                            <h1 class="general__body__item__title">Xiên</h1>
                                            <form action="#" class="general__body__item__form">
                                                <div class="form-group">
                                                    <label>Comment CX</label>
                                                    <input type="text" class="form-control" placeholder="CX" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc
                                                        định CX</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Comment CT</label>
                                                    <input type="text" class="form-control" placeholder="CT" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc
                                                        định CT</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Comment LT</label>
                                                    <input type="text" class="form-control" placeholder="LT" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc
                                                        định LT</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Comment LX</label>
                                                    <input type="text" class="form-control" placeholder="LX" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc
                                                        định LX</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối thiểu</label>
                                                    <input type="text" class="form-control" placeholder="100.000" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. Mặc
                                                        định
                                                        100,000</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Số tiền tối đa</label>
                                                    <input type="text" class="form-control" placeholder="1.000.000" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định
                                                        1,000,000</small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Rules 1 (1 số cuối mã GD)</label>
                                                    <input type="text" class="form-control" placeholder="0,2,4" />
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu
                                                        phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ CX </label>
                                                    <input type="text" class="form-control" placeholder="3.3" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 2 (1 số cuối mã GD)</label>
                                                    <input type="text" class="form-control" placeholder="5,7,9" />
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu
                                                        phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ LT </label>
                                                    <input type="text" class="form-control" placeholder="3.3" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 3 (1 số cuối mã GD)</label>
                                                    <input type="text" class="form-control" placeholder="6,8" />
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu
                                                        phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ CT </label>
                                                    <input type="text" class="form-control" placeholder="3.3" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định 1</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Rules 4 (1 số cuối mã GD)</label>
                                                    <input type="text" class="form-control" placeholder="1,3" />
                                                    <small class="form-text text-muted">Các số cách nhau bởi dấu
                                                        phẩy</small>
                                                </div>
                                                <div class="form-group">
                                                    <label>Tỉ lệ LX </label>
                                                    <input type="text" class="form-control" placeholder="3.3" />
                                                    <small class="form-text text-muted">Vui lòng không để trống. mặc
                                                        định 1</small>
                                                </div>

                                                <div class="form-group">
                                                    <label>Hoạt động</label>
                                                    <label class="switch">
                                                        <input type="checkbox" checked />
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                                <button class="btn btn-success">Lưu</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- Close Cài đặt XSMB, Xiên  -->
        <!-- ------------------------- -->
        <!-- Cài đặt chung -->
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__ant__card">
                    <div class="general__content">
                        <div class="general__info" type="button" data-toggle="collapse" data-target="#collapseChung"
                            aria-expanded="false" aria-controls="collapseChung">
                            <button class="btn general__btn">Cài đặt khác</button>
                        </div>
                        <div class="collapse" id="collapseChung">
                            <div class="card card-body">
                                Vui Lòng Vào Cài Đặt Chung, Ở Đây Chỉ Có Cài Đặt Cho Momo Thôi
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Close Cài đặt chung -->
        <center>
            <button type="button" class="btn btn-success">
                <a style="text-decoration: none; color:#fff;" href="/api/momo/setting?type=sync&phone=<?=$phone;?>">Đồng Bộ Hóa Tất Cả</a>
            </button>
        </center>
    </div>
    <!-- Close Content -->
</div>
<!-- Modal -->
<!-- Add User -->
<div class="modal fade" id="exampleAddUser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="background-color: #fff">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Thêm liên hệ</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="transfer__form row" style="margin-left: 0; width: 85%">
                    <form action="#">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" placeholder="Name"
                                style="text-align: inherit" />
                        </div>
                        <div class="form-group">
                            <label for="url">URL</label>
                            <input type="text" class="form-control" id="url" placeholder="URL"
                                style="text-align: inherit" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light mr-3" data-dismiss="modal">
                    Quay lại
                </button>
                <button type="button" data-dismiss="modal" class="btn btn-success">
                    Lưu
                </button>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Update User -->
<div class="modal fade" id="exampleUpdateUser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="background-color: #fff">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Thêm liên hệ</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="transfer__form row" style="margin-left: 0; width: 85%">
                    <form action="#">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" placeholder="box zalo"
                                style="text-align: inherit" />
                        </div>
                        <div class="form-group">
                            <label for="url">URL</label>
                            <input type="text" class="form-control" id="url" placeholder="demo7.webtienich.com"
                                style="text-align: inherit" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light mr-3" data-dismiss="modal">
                    Quay lại
                </button>
                <button type="button" data-dismiss="modal" class="btn btn-success">
                    Lưu
                </button>
            </div>
        </div>
    </div>
</div>
<!-- Delete User -->
<div class="modal fade" id="exampleDeleteUser" tabindex="-1" role="dialog" aria-labelledby="exampleDeleteUser"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="background-color: #fff">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color: #000">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h2 style="font-size: 22px">Xóa liên hệ</h2>
                <p>Bạn có chắc chắn muốn xoá liện hệ này này không?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light mr-3" data-dismiss="modal">
                    Hủy
                </button>
                <button type="button" data-dismiss="modal" class="btn btn-primary">
                    Xác nhận
                </button>
            </div>
        </div>
    </div>
</div>
</div>
<script src="../assets/scripts/collapse.js"></script>
<script src="../assets/scripts/navbar.js"></script>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>