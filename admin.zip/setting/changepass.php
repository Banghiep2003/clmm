<?php session_start(); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/head.php'); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/nav.php'); ?>
<!-- Content -->
<div class="content">
    <div class="content__inner">
        <div class="content__inner__heading">
            <p>Đổi Mật Khẩu</p>
            <span> >&ensp; Settings&ensp;></span>
            <span>Đổi Mật Khẩu</span>
        </div>
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__ant__card">
                    <div class="transfer__card__info">
                        <h2 class="transfer__card__info__heading">
                            Đổi Mật Khẩu
                        </h2>
                        <div class="transfer__form row">
                            <form action="/api/momo/changepass" method="POST" class="col-lg-5 col-md-9">
                                <div class="form-group">
                                    <label for="value">Mật Khẩu Cũ</label>
                                    <input type="password" class="form-control" name="oldpass" placeholder="Mật Khẩu Cũ" />
                                </div>
                                <div class="form-group">
                                    <label for="value">Mật Khẩu Mới</label>
                                    <input type="password" class="form-control" name="password" placeholder="Mật Khẩu Mới" />
                                </div>
                                <div class="form-group">
                                    <label for="content">Nhập Lại Mật Khẩu Mới</label>
                                    <input type="password" class="form-control" name="newpassword" placeholder="Nhập Lại Mật Khẩu Mới" />
                                </div>
                                <button type="submit" class="transfer__btn">Đổi Mật Khẩu Ngay</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        



    </div>
</div>

</div>
</div>
<script src="../assets/scripts/collapse.js"></script>
<script src="../assets/scripts/navbar.js"></script>

<!--<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>-->
<!--<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>