<?php session_start(); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/head.php'); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/nav.php'); ?>
<!-- Content -->
<div class="content">
    <div class="content__inner">
        <div class="content__inner__heading">
            <!-- <p>Check Lịch Sử</p> -->
            <span> >&ensp; Momo&ensp;></span>
            <span>Check Lịch Sử</span>
        </div>
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__ant__card">
                    <div class="transfer__card__info">
                        <h2 class="transfer__card__info__heading">
                            Check Lịch Sử MoMo
                        </h2>
                        <div class="transfer__form row">
                            <form action="/api/momo/checkhis" method="POST" class="col-lg-5 col-md-9">
                                <div class="form-group">
                                    <label for="account">Tài khoản MoMo</label>
                                    <select class="form-control" id="account" name="account">
                                        <option>Chọn danh sách MoMo</option>
                                        <?php
                                            $list = $soicoder->fetch_assoc("SELECT `id`, `phone`,`BALANCE` FROM `cron_momo` LIMIT 1000", 0);
                                            foreach ($list as $data) { ?>
                                        <option value= "<?=$data['phone'];?>"><?=$data['phone'];?> (<?=format_cash($data['BALANCE']);?>đ)</option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="phone">Mã Giao Dịch</label>
                                    <input type="text" class="form-control" id="tranId" name="tranId" placeholder="Nhập Mã Giao Dịch" />
                                </div> 
                                <button type="submit" class="transfer__btn">Kiểm Tra</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__ant__card">
                    <div class="momo__card__info">
                        <h2 class="transfer__card__info__heading">
                            Kết Quả
                        </h2>
                    </div>
                    <div class="content__ant__card__table table--responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th style="text-align: center">ID</th>
                                    <th style="text-align: center">Mã Giao Dịch</th>
                                    <th style="text-align: center">MoMo Chuyển</th>
                                    <th style="text-align: center">Số tiền</th>
                                    <th style="text-align: center">Nội Dung</th>
                                    <th style="text-align: center">Time</th>
                                    <th style="text-align: center">Trạng Thái</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if (isset($_SESSION['check_his'])) { ?>
                                <tr>
                                    <td style="text-align: center"><?=$_SESSION['check_his']['id'];?></td>
                                    <td style="text-align: center"><?=$_SESSION['check_his']['tranId'];?></td>
                                    <td style="text-align: center"><?=$_SESSION['check_his']['partnerId'];?></td>
                                    <td style="text-align: center"><?=format_cash($_SESSION['check_his']['amount']);?>đ</td>
                                    <td style="text-align: center"><?=$_SESSION['check_his']['comment'];?></td>
                                    <td style="text-align: center"><?=date('H:i:s d/m/Y', substr($_SESSION['check_his']['millisecond'] , 0, 10));?></td>
                                    <td style="text-align: center"><pre><?=$_SESSION['check_his']['status'];?></pre></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>



    </div>
</div>
<!-- Modal -->
<!-- <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="#">
                    <h3>Nhập số điện thoại</h3>
                    <p>Dùng số điện thoại để đăng ký hoặc đăng nhập ví MoMo</p>
                    <input type="tel" placeholder="Nhập số điện thoại" />
                    <button>TIẾP TỤC</button>
                </form>
            </div>
        </div>
    </div>
</div> -->
<!-- Close Content -->
</div>
</div>
<script src="../assets/scripts/collapse.js"></script>
<script src="../assets/scripts/navbar.js"></script>

<!--<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>-->
<!--<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>