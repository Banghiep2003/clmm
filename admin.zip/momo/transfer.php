<!--chuyển tiền không pass khi bị lỗi token-->
<?php session_start(); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/head.php'); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/nav.php'); ?>
<!-- Content -->
<div class="content">
    <div class="content__inner">
        <div class="content__inner__heading">
            <p>Chuyển tiền</p>
            <span> >&ensp; Momo&ensp;></span>
            <span>chuyển tiền</span>
        </div>
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__ant__card">
                    <div class="transfer__card__info">
                        <h2 class="transfer__card__info__heading">
                            Chuyển Tiền MoMo
                        </h2>
                        <div class="transfer__form row">
                            <form action="/api/momo/sendmoney" method="POST" class="col-lg-5 col-md-9">
                                <div class="form-group">
                                    <label for="account">Tài khoản MoMo</label>
                                    <select class="form-control" id="account" name="account">
                                        <option>Chọn danh sách MoMo</option>
                                        <?php
                                            $list = $soicoder->fetch_assoc("SELECT `id`, `phone`,`BALANCE` FROM `cron_momo` LIMIT 1000", 0);
                                            foreach ($list as $data) { ?>
                                        <option value= "<?=$data['phone'];?>"><?=$data['phone'];?> (<?=format_cash($data['BALANCE']);?>đ)</option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="phone">Số điện thoại</label>
                                    <input type="text" class="form-control" id="phone" name="phone" placeholder="Nhập SDT người nhận" />
                                    <button><a style="text-decoration: none; color:#fff;" href="javascript:;" onclick="checksdt(this)" id="checksdt">Kiểm tra</a></button>
                                    <!-- <button id="submit" name="submit" >Kiểm tra</button> -->
                                    <script>
                                        function checksdt() {
                                           $("#checksdt").html('<i class="fas fa-spinner fa-spin"></i>');
                                            var phone = $("#phone").val();
                                            var account = $("#account").val();
                                               $.ajax({
                                                   type: "POST",
                                                   url: "/api/momo/checkname",
                                                   data: {
                                                       phone,
                                                       account
                                                   },
                                                   dataType: "json",
                                                   success: function (res) {
                                                       if (res.success) {
                                                        //    alert(res.success);
                                                            $('#checkname').show();
                                                            $("#valuename").html(res.success);
                                                            $("#checksdt").html('Kiểm tra');
                                                       } else {
                                                           alert(res.success);
                                                           $("#checksdt").html('Kiểm tra');
                                                       }
                                                   },
                                                   error: function (err) {
                                                       console.log(err);
                                                   },
                                               });
                                        }
                                    </script>
                                </div>
                                <div class="form-group" id="checkname" style="display: none">
                                    <label>Tên Momo</label>
                                    <span class="form-control" id="valuename" name="name"></span>
                                </div>
                                <div class="form-group">
                                    <label for="value">Giá trị</label>
                                    <input type="text" class="form-control" name="amount" placeholder="Số tiền" />
                                </div>
                                <div class="form-group">
                                    <label for="content">Nội dung</label>
                                    <input type="text" class="form-control" name="content" placeholder="Nội dung" />
                                </div>
                                <button type="submit" class="transfer__btn">Chuyển tiền</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__ant__card">
                    <div class="momo__card__info">
                        <h2 class="transfer__card__info__heading">
                            Lịch Sử Chuyển Tiền MoMo
                        </h2>
                    </div>

                    

                    <div class="content__ant__card__filter">
                        <form class="form">
                            <div class="form__control">
                                <p>Show</p>
                                <select class="form__select">
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                </select>
                                <p>entries</p>
                            </div>
                            <div class="form__control">
                                <label for="search">Search</label>
                                <input type="text" class="form__control__input" id="search" />
                            </div>
                        </form>
                    </div>
                    <div class="content__ant__card__table table--responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th style="text-align: center">ID</th>
                                    <th style="text-align: center">MoMo Chuyển</th>
                                    <th style="text-align: center">Mã Giao Dịch</th>
                                    <th style="text-align: center">Số tiền</th>
                                    <th style="text-align: center">Nội Dung</th>
                                    <th style="text-align: center">Momo Nhận</th>
                                    <th style="text-align: center">Tên Người Nhận</th>
                                    <th style="text-align: center">Time</th>
                                    <th style="text-align: center">Trạng Thái</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $list = $soicoder->fetch_assoc("SELECT * FROM `chuyen_tien` ORDER BY id desc LIMIT 1000", 0);
                                foreach ($list as $data) { ?>
                                <tr>
                                    <td><?=$data['id'];?></td>
                                    <td><?=$data['ownerNumber'];?></td>
                                    <td style="text-align: center"><?=$data['tranId'];?></td>
                                    <td><?=format_cash($data['amount']);?>đ</td>
                                    
                                    <td style="text-align: center"><?=$data['comment'];?></td>
                                    <td style="text-align: center"><?=$data['partnerId'];?></td>
                                    <td style="text-align: center"><?=$data['partnerName'];?></td>
                                    <td style="text-align: center"><?=date('H:i:s d/m/Y', $data['time']);?></td>
                                    <td style="text-align: center"><pre><?=$data['message'];?></pre></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="paginator">
                        <ul class="pagination">
                            <li class="page-item disabled">
                                <a class="page-link" href="#">Previous</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#">1</a>
                            </li>

                            <li class="page-item">
                                <a class="page-link" href="#">Next</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>



    </div>
</div>
<!-- Modal -->
<!-- <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="#">
                    <h3>Nhập số điện thoại</h3>
                    <p>Dùng số điện thoại để đăng ký hoặc đăng nhập ví MoMo</p>
                    <input type="tel" placeholder="Nhập số điện thoại" />
                    <button>TIẾP TỤC</button>
                </form>
            </div>
        </div>
    </div>
</div> -->
<!-- Close Content -->
</div>
</div>
<script src="../assets/scripts/collapse.js"></script>
<script src="../assets/scripts/navbar.js"></script>

<!--<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>-->
<!--<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>