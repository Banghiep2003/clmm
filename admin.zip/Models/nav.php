<body>
    <div class="dashboard">
        <div class="navbar">
            <div class="navbar__content">
                    <a href="index.php"><img src="" /></a>
                </div>
                <div class="navbar__menu">
                    <h3>MENU</h3>
                    <ul class="navbar__menu__list">
                        <li class="navbar__menu__item hover">
                            <a class="navbar__menu__item__link active" href="/index.php">Tổng quan</a>
                        </li>
                        <div class="according">
                            <li class="navbar__menu__parent navbar__menu__item">
                                <a class="navbar__menu__item__link active">MoMo</a>
                            </li>
                            <ul class="navbar__menu__children">
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/momo/list.php" class="navbar__menu__children__item__link">Danh Sách</a>
                                </li>
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/momo/transfer.php" class="navbar__menu__children__item__link">Chuyển tiền</a>
                                </li>
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/momo/checkhis.php" class="navbar__menu__children__item__link">Check Mã Giao Dịch</a>
                                </li>
                            </ul>
                        </div>
                        <div class="according">
                            <li class="navbar__menu__parent navbar__menu__item">
                                <a class="navbar__menu__item__link active" href="#">Mini Game</a>
                            </li>
                            <ul class="navbar__menu__children">
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/service/report.php" class="navbar__menu__children__item__link">Thống kê</a>
                                </li>
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/service/history.php" class="navbar__menu__children__item__link">Lịch sử tổng</a>
                                </li>
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/service/history-pay.php" class="navbar__menu__children__item__link">Lịch sử bill thắng</a>
                                </li>
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/service/history-lose.php" class="navbar__menu__children__item__link">Lịch sử bill thua</a>
                                </li>
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/service/history-error.php" class="navbar__menu__children__item__link">Danh sách lỗi</a>
                                </li>
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/service/report-user.php" class="navbar__menu__children__item__link">Thống kê người dùng</a>
                                </li>
                                <!-- <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/service/logs.php" class="navbar__menu__children__item__link">Logs</a>
                                </li> -->
                            </ul>
                        </div>
                        <div class="according">
                            <li class="navbar__menu__parent navbar__menu__item">
                                <a class="navbar__menu__item__link active" href="#">Event</a>
                            </li>
                            <ul class="navbar__menu__children">
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/event/code.php" class="navbar__menu__children__item__link">Code Khuyến Mãi</a>
                                </li>
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/event/task.php" class="navbar__menu__children__item__link">Nhiệm vụ ngày</a>
                                </li>
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/event/top.php" class="navbar__menu__children__item__link">Top Tuần</a>
                                </li>
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/event/attendance.php" class="navbar__menu__children__item__link">Điểm Danh Nhận Quà</a>
                                </li>
                            </ul>
                        </div>
                        <div class="according">
                            <li class="navbar__menu__parent navbar__menu__item">
                                <a class="navbar__menu__item__link active" href="#">Cài Đặt</a>
                            </li>
                            <ul class="navbar__menu__children">
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/setting/setting.php" class="navbar__menu__children__item__link">Cài Đặt Chung</a>
                                </li>
                                <li class="navbar__menu__item hover navbar__menu__children__item">
                                    <a class="navbar__menu__item__link" href="/setting/changepass.php" class="navbar__menu__children__item__link">Đổi Mật Khẩu</a>
                                </li>
                            </ul>
                        </div>
                        <li class="navbar__menu__item hover">
                            <a class="navbar__menu__item__link active" href="/logout">Đăng Xuất</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="right">
            <header class="header">
                <div/></div>
                <div class="header__inner">
                    <div class="header__icon header__icon--xmark">
                        <i class="fa-solid fa-xmark"></i>
                    </div>
                    <div class="header__icon header__icon--bars">
                        <i class="fa-solid fa-bars"></i>
                    </div>

                    <div class="header__icon header__icon--user">
                        <a href="/logout" title="Đăng Suất"><i class="fa-solid fa-user"></i></a>
                    </div>
                </div>
            </header>