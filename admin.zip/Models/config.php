<?php
define('SERVERNAME','localhost');
define('USERNAME','tclmm5swin_ss1');
define('PASSWORD','tclmm5swin_ss1');
define('DATABASE','tclmm5swin_ss1');
?>