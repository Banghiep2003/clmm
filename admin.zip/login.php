<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" />

    <link rel="stylesheet" href="./assets/css/login.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title>Admin CLMM</title>
</head>

<body>
    <div class="login">
        <div/>
        </div>
        <div class="form__login">
            <form action="/api/auth/login" method="POST" class="form">
                <h1 class="heading">Đăng Nhập</h1>
                <div class="input__group mb-3">
                    <span class="icon user"><i class="fa-regular fa-user"></i></span>
                    <input type="text" name="username" class="form__control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" />
                </div>
                <div class="input__group mb-3">
                    <span class="icon lock"><i class="fa-solid fa-lock"></i></span>
                    <input type="password" name="password" class="form__control" placeholder="Password" aria-label="Password" aria-describedby="basic-addon2" />
                    <span class="icon eye"><i class="fa-regular fa-eye-slash"></i></span>
                </div>
                <button class="login__btn mb-3" name="submit" type="submit">Đăng nhập</button>
                <div class="login__pagination">
                    <a href="#">Quên mật khẩu</a>
                </div>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>