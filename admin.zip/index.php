<?php session_start(); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/head.php'); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/nav.php'); ?>
<!-- Content -->
<div class="content">
    <div class="content__inner">
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__card__body">
                    <h4>Lịch Sử Hoạt Động Code</h4>
                </div>
                <div class="content__card__body">
                    <p>Ngày Triển Khai Code: 20/07/2022</p>
                    <p>Ngày Hoàn Thành Code V0: 15/08/2022</p>
                    <p>Ngày Hoàn Thành Code V1: 25/08/2022 (update các lỗi vặt)</p>
                </div>
            </div>
        </div>
    </div>
    <div class="content__inner">
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__card__body">
                </div>
            </div>
        </div>
    </div>
    <div class="content__inner">
        <div class="content__ant content__card__border">
            <div class="content__card__body">
                <div class="content__card__body">
                    <h4>Lưu Ý</h4>
                </div>
                <div class="content__card__body">
                    <p>1. Nên Sài Cron 20s/1 lần</p>
                    <p>2. Link Cron Thanh Toán Của Bạn Là: <b>https://<?=$_SERVER['SERVER_NAME'];?>/momo/check (5-10s)</b></p>
                    <p>3. Link Cron Login Của Bạn Là: <b>https://<?=$_SERVER['SERVER_NAME'];?>/momo/login (2000s )</b></p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Close Content -->

</div>
</div>
<script src="./assets/scripts/collapse.js"></script>
<script src="./assets/scripts/navbar.js"></script>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>