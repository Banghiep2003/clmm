<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');
$phone = check_string($_POST['phone']);



// type
$check_type = isset($_POST['type']) ? $_POST['type'] : $_GET['type'];
$type = check_string($check_type);

// echo $type; die;
$get = $soicoder->fetch_assoc("SELECT `id`, `phone`, `DataJson` FROM `cron_momo` WHERE `phone` = '".$phone."' LIMIT 1", 1);
// print_r($_POST);
// die;

$data = json_decode($get['DataJson'], true);
// =================[ tách ]==============================
// CL
$CL = $data['CL'];
$CL_cmt_C = $CL['cmt_C'];
$CL_cmt_L = $CL['cmt_L'];
$CL_min = $CL['min'];
$CL_max = $CL['max'];
$CL_ratio = $CL['ratio'];
$CL_status = $CL['status'];
$CL_md_thua = $CL['md_thua'];
$CL_md_ht = $CL['md_ht'];
// CL2
$CL2 = $data['CL2'];
$CL2_cmt_C = $CL2['cmt_C'];
$CL2_cmt_L = $CL2['cmt_L'];
$CL2_min = $CL2['min'];
$CL2_max = $CL2['max'];
$CL2_ratio = $CL2['ratio'];
$CL2_status = $CL['status'];
$CL2_md_thua = $CL2['md_thua'];
$CL2_md_ht = $CL2['md_ht'];
// TX
$TX = $data['TX'];
$TX_cmt_T = $TX['cmt_T'];
$TX_cmt_X = $TX['cmt_X'];
$TX_min = $TX['min'];
$TX_max = $TX['max'];
$TX_ratio = $TX['ratio'];
$TX_status = $TX['status'];
$TX_md_thua = $TX['md_thua'];
$TX_md_ht = $TX['md_ht'];
// TX2
$TX2 = $data['TX2'];
$TX2_cmt_T = $TX2['cmt_T'];
$TX2_cmt_X = $TX2['cmt_X'];
$TX2_min = $TX2['min'];
$TX2_max = $TX2['max'];
$TX2_ratio = $TX2['ratio'];
$TX2_status = $TX2['status'];
$TX2_md_thua = $TX2['md_thua'];
$TX2_md_ht = $TX2['md_ht'];
// 1 phần 3
$_1P3 = $data['1P3'];
$_1P3_cmt_N0 = $_1P3['cmt_N0'];
$_1P3_cmt_N1 = $_1P3['cmt_N1'];
$_1P3_cmt_N2 = $_1P3['cmt_N2'];
$_1P3_cmt_N3 = $_1P3['cmt_N3'];
$_1P3_min = $_1P3['min'];
$_1P3_max = $_1P3['max'];
$_1P3_ratio_N0 = $_1P3['ratio_N0'];
$_1P3_ratio_N1 = $_1P3['ratio_N1'];
$_1P3_ratio_N2 = $_1P3['ratio_N2'];
$_1P3_ratio_N3 = $_1P3['ratio_N3'];
$_1P3_status = $_1P3['status'];
// G3
$G3 = $data['G3'];
$G3_cmt = $G3['cmt'];
$G3_min = $G3['min'];
$G3_max = $G3['max'];
$G3_rules_2 = $G3['rules_2'];
$G3_rules_3 = $G3['rules_3'];
$G3_ratio_2 = $G3['ratio_2'];
$G3_ratio_3 = $G3['ratio_3'];
$G3_status = $G3['status'];
// T3S
$T3S = $data['T3S'];
$T3S_cmt = $T3S['cmt'];
$T3S_min = $T3S['min'];
$T3S_max = $T3S['max'];
$T3S_rules_1 = $T3S['rules_1'];
$T3S_rules_2 = $T3S['rules_2'];
$T3S_rules_3 = $T3S['rules_3'];
$T3S_ratio_1 = $T3S['ratio_1'];
$T3S_ratio_2 = $T3S['ratio_2'];
$T3S_ratio_3 = $T3S['ratio_3'];
$T3S_status = $T3S['status'];
// H2S
$H2S = $data['H2S'];
$H2S_cmt = $H2S['cmt'];
$H2S_min = $H2S['min'];
$H2S_max = $H2S['max'];
$H2S_rules_1 = $H2S['rules_1'];
$H2S_rules_2 = $H2S['rules_2'];
$H2S_rules_3 = $H2S['rules_3'];
$H2S_rules_4 = $H2S['rules_4'];

$H2S_ratio_1 = $H2S['ratio_1'];
$H2S_ratio_2 = $H2S['ratio_2'];
$H2S_ratio_3 = $H2S['ratio_3'];
$H2S_ratio_4 = $H2S['ratio_4'];
$H2S_status = $H2S['status'];
// lô
$LO = $data['LO'];
$LO_cmt = $LO['cmt'];
$LO_min = $LO['min'];
$LO_max = $LO['max'];
$LO_rules = $LO['rules'];
$LO_ratio = $LO['ratio'];
$LO_status = $LO['status'];
if ($type == 'CL') {
    $CL_cmt_C = $_POST['cmt_C'];
    $CL_cmt_L = $_POST['cmt_L'];
    $CL_min = $_POST['min'];
    $CL_max = $_POST['max'];
    $CL_ratio = $_POST['ratio'];
    $CL_status = isset($_POST['status']) ? 'on' : 'off';
    $CL_md_thua = $_POST['md_thua'];
    $CL_md_ht = $_POST['md_ht'];
} else if ($type == 'CL2') {
    $CL2_cmt_C = $_POST['cmt_C'];
    $CL2_cmt_L = $_POST['cmt_L'];
    $CL2_min = $_POST['min'];
    $CL2_max = $_POST['max'];
    $CL2_ratio = $_POST['ratio'];
    $CL2_status = isset($_POST['status']) ? 'on' : 'off';
    $CL2_md_thua = $_POST['md_thua'];
    $CL2_md_ht = $_POST['md_ht'];
} else if ($type == 'TX')  {
    $TX_cmt_T = $_POST['cmt_T'];
    $TX_cmt_X = $_POST['cmt_X'];
    $TX_min = $_POST['min'];
    $TX_max = $_POST['max'];
    $TX_ratio = $_POST['ratio'];
    $TX_status = isset($_POST['status']) ? 'on' : 'off';
    $TX_md_thua = $_POST['md_thua'];
    $TX_md_ht = $_POST['md_ht'];
} else if ($type == 'TX2') {
    $TX2_cmt_T = $_POST['cmt_T'];
    $TX2_cmt_X = $_POST['cmt_X'];
    $TX2_min = $_POST['min'];
    $TX2_max = $_POST['max'];
    $TX2_ratio = $_POST['ratio'];
    $TX2_status = isset($_POST['status']) ? 'on' : 'off';
    $TX2_md_thua = $_POST['md_thua'];
    $TX2_md_ht = $_POST['md_ht'];
} else if ($type == '1P3') {
    $_1P3_cmt_N0 = $_POST['cmt_N0'];
    $_1P3_cmt_N1 = $_POST['cmt_N1'];
    $_1P3_cmt_N2 = $_POST['cmt_N2'];
    $_1P3_cmt_N3 = $_POST['cmt_N3'];
    $_1P3_min = $_POST['min'];
    $_1P3_max = $_POST['max'];
    $_1P3_ratio_N0 = $_POST['ratio_N0'];
    $_1P3_ratio_N1 = $_POST['ratio_N1'];
    $_1P3_ratio_N2 = $_POST['ratio_N2'];
    $_1P3_ratio_N3 = $_POST['ratio_N3'];
    $_1P3_status = isset($_POST['status']) ? 'on' : 'off';
} else if ($type == 'G3') {
    $G3_cmt = $_POST['cmt'];
    $G3_min = $_POST['min'];
    $G3_max = $_POST['max'];
    $G3_rules_2 = $_POST['rules_2'];
    $G3_rules_3 = $_POST['rules_3'];
    $G3_ratio_2 = $_POST['ratio_2'];
    $G3_ratio_3 = $_POST['ratio_3'];
    $G3_status = isset($_POST['status']) ? 'on' : 'off';
} else if ($type == 'T3S')  {
    $T3S_cmt = $_POST['cmt'];
    $T3S_min = $_POST['min'];
    $T3S_max = $_POST['max'];
    $T3S_rules_1 = $_POST['rules_1'];
    $T3S_rules_2 = $_POST['rules_2'];
    $T3S_rules_3 = $_POST['rules_3'];
    $T3S_ratio_1 = $_POST['ratio_1'];
    $T3S_ratio_2 = $_POST['ratio_2'];
    $T3S_ratio_3 = $_POST['ratio_3'];
    $T3S_status = isset($_POST['status']) ? 'on' : 'off';
} else if ($type == 'H2S') {
    $H2S_cmt = $_POST['cmt'];
    $H2S_min = $_POST['min'];
    $H2S_max = $_POST['max'];
    $H2S_rules_1 = $_POST['rules_1'];
    $H2S_rules_2 = $_POST['rules_2'];
    $H2S_rules_3 = $_POST['rules_3'];
    $H2S_rules_4 = $_POST['rules_4'];

    $H2S_ratio_1 = $_POST['ratio_1'];
    $H2S_ratio_2 = $_POST['ratio_2'];
    $H2S_ratio_3 = $_POST['ratio_3'];
    $H2S_ratio_4 = $_POST['ratio_4'];
    $H2S_status = isset($_POST['status']) ? 'on' : 'off';
} else if ($type == 'LO') {
    $LO_cmt = $_POST['cmt'];
    $LO_min = $_POST['min'];
    $LO_max = $_POST['max'];
    $LO_rules = $_POST['rules'];
    $LO_ratio = $_POST['ratio'];
    $LO_status = isset($_POST['status']) ? 'on' : 'off';
} else if ($type == 'sync') {
    $phone = $_GET['phone'];
    $get = $soicoder->fetch_assoc("SELECT `id`, `phone`, `DataJson` FROM `cron_momo` WHERE `phone` = '".$phone."' LIMIT 1", 1);
    $data = $get['DataJson'];
    $soicoder->update("cron_momo", array('DataJson' => $data), "1 ");
    echo "<script language='javascript'>alert('Đồng Bộ Hóa Thành Công');window.location='/setting/general.php?phone=".$phone."';</script>";
    die;
} else {
    echo "<script language='javascript'>alert('Lỗi Không Xác Định');window.location='/setting/general.php?phone=".$phone."';</script>";
}

// update
$data = array(
    "CL" => array(
        "cmt_C" => $CL_cmt_C,
        "cmt_L" => $CL_cmt_L,
        "min" => $CL_min,
        "max" => $CL_max,
        "ratio" => $CL_ratio,
        "status" => $CL_status,
        "md_thua" => $CL_md_thua,
        "md_ht" => $CL_md_ht
    ),
    "CL2" => array(
        "cmt_C" => $CL2_cmt_C,
        "cmt_L" => $CL2_cmt_L,
        "min" => $CL2_min,
        "max" => $CL2_max,
        "ratio" => $CL2_ratio,
        "status" => $CL2_status,
        "md_thua" => $CL2_md_thua,
        "md_ht" => $CL2_md_ht
    ),
    "TX" => array(
        "cmt_T" => $TX_cmt_T,
        "cmt_X" => $TX_cmt_X,
        "min" => $TX_min,
        "max" => $TX_max,
        "ratio" => $TX_ratio,
        "status" => $TX_status,
        "md_thua" => $TX_md_thua,
        "md_ht" => $TX_md_ht
    ),
    "TX2" => array(
        "cmt_T" => $TX2_cmt_T,
        "cmt_X" => $TX2_cmt_X,
        "min" => $TX2_min,
        "max" => $TX2_max,
        "ratio" => $TX2_ratio,
        "status" => $TX2_status,
        "md_thua" => $TX2_md_thua,
        "md_ht" => $TX2_md_ht
    ),
    "1P3" => array(
        "cmt_N0" => $_1P3_cmt_N0,
        "cmt_N1" => $_1P3_cmt_N1,
        "cmt_N2" => $_1P3_cmt_N2,
        "cmt_N3" => $_1P3_cmt_N3,
        "min" => $_1P3_min,
        "max" => $_1P3_max,
        "ratio_N0" => $_1P3_ratio_N0,
        "ratio_N1" => $_1P3_ratio_N1,
        "ratio_N2" => $_1P3_ratio_N2,
        "ratio_N3" => $_1P3_ratio_N3,
        "status" => $_1P3_status
    ),
    "G3" => array(
        "cmt" => $G3_cmt,
        "min" => $G3_min,
        "max" => $G3_max,
        "rules_2" => $G3_rules_2,
        "rules_3" => $G3_rules_3,
        "ratio_2" => $G3_ratio_2,
        "ratio_3" => $G3_ratio_3,
        "status" => $G3_status
    ),
    "T3S" => array(
        "cmt" => $T3S_cmt,
        "min" => $T3S_min,
        "max" => $T3S_max,
        "rules_1" => $T3S_rules_1,
        "rules_2" => $T3S_rules_2,
        "rules_3" => $T3S_rules_3,
        "ratio_1" => $T3S_ratio_1,
        "ratio_2" => $T3S_ratio_2,
        "ratio_3" => $T3S_ratio_3,
        "status" => $T3S_status
    ),
    "H2S" => array(
        "cmt" => $H2S_cmt,
        "min" => $H2S_min,
        "max" => $H2S_max,
        "rules_1" => $H2S_rules_1,
        "rules_2" => $H2S_rules_2,
        "rules_3" => $H2S_rules_3,
        "rules_4" => $H2S_rules_4,

        "ratio_1" => $H2S_ratio_1,
        "ratio_2" => $H2S_ratio_2,
        "ratio_3" => $H2S_ratio_3,
        "ratio_4" => $H2S_ratio_4,
        "status" => $H2S_status
    ),
    "LO" => array(
        "cmt" => $LO_cmt,
        "min" => $LO_min,
        "max" => $LO_max,
        "rules" => $LO_max,
        "ratio" => $LO_ratio,
        "status" => $LO_status
    )
);
// header("Content-type:text/javscript");
$soicoder->update("cron_momo", array('DataJson' => json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)), "`phone` = '$phone' ");
// 
echo "<script language='javascript'>alert('Cập Nhật Thành Công');window.location='/setting/general.php?phone=".$phone."';</script>";