<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');



$type = check_string($_POST['type']);
if ($type == 'regcode') {
    $code = check_string($_POST['code']);
    $password = check_string($_POST['password']);
    $momo_reward = check_string($_POST['momo_reward']);
    $money = check_string($_POST['money']);
    $limit = check_string($_POST['limit']);
    if (strlen($code) < 6) {
        echo "<script language='javascript'>alert('Code Phải Lớn Hơn 6 Kí Tự');window.location='/event/code.php';</script>";
        die;
    } else {
        $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$momo_reward."' LIMIT 1 " , 1);
        if (soicoder_enc($password) !== $loadDATA['password']) {
            echo "<script language='javascript'>alert('Mật Khẩu Không Chính Xác');window.location='/event/code.php';</script>";
            die;
        } else {
            $soicoder->insert('code' , array (
                'code' => $code,
                'momo_reward' => $momo_reward,
                'money' => $money,
                'limit_import' => $limit,
                'entered' => '0',
                'status' => 'on',
                'time' => time(),
            ));
            echo "<script language='javascript'>alert('Thêm Thành Công');window.location='/event/code.php';</script>";
            die;
        }
    }
}
