<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');
$phone = check_string($_POST['phone']);
$otp = check_string($_POST['otp']);
$password = check_string($_POST['password']);

// echo $phone; die;
if (strlen($phone) == 10) {
    $momo = new MomoV2($soicoder);
    $select = $soicoder->num_rows("SELECT * FROM `cron_momo` WHERE `phone` = '".$phone."' LIMIT 1 ");
    if ($select >= 1) {
        $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$phone."' LIMIT 1 " , 1) ;
        $xacminh = $momo->LoadData($loadDATA)->ImportOTP($otp);
        if ($xacminh['status'] == 'success') {
            $soicoder->update("cron_momo", array(
                'ohash' => $xacminh["ohash"],
                "setupKey" => $xacminh['setupKey'],
                "setupKeyDecrypt" => $xacminh['setupKeyDecrypt']
            ), "`phone` = '$phone' ");
            $login = $momo->LOGIN($password);
            if ($login['status'] == 'success') {
                $data = $soicoder->fetch_assoc("SELECT * FROM `default` WHERE `id` = 1", 1)['data'];
                $result = json_decode($login['data'], true);
                $BankVerify = ($result['momoMsg']['bankVerifyPersonalid'] == 'null') ? '1' : '2';
                $extra = $result["extra"];
                $soicoder->update("cron_momo", array(
                    'agent_id' => $result["momoMsg"]["agentId"],
                    'Name' => $result["momoMsg"]["name"],
                    'email' => $result["momoMsg"]["email"],
                    'password' => soicoder_enc($password),
                    'authorization' => soicoder_enc($extra["AUTH_TOKEN"]),
                    'BankVerify' => $BankVerify,
                    'BALANCE' => $extra["BALANCE"],
                    'refreshToken' => $extra["REFRESH_TOKEN"],
                    'sessionkey' => $extra["SESSION_KEY"],
                    'RSA_PUBLIC_KEY' => $extra["REQUEST_ENCRYPT_KEY"],
                    // 'TOKEN' => $extra["TOKEN"],
                    'status' => 'success',
                    'errorDesc' => 'Thành Công',
                    'TimeLogin' => time(),
                    'DataJson' => '{"CL":{"cmt_C":"C","cmt_L":"L","min":"1000","max":"1000000","ratio":"2.3","status":"off","md_thua":"0,9","md_ht":"0"},"CL2":{"cmt_C":"C2","cmt_L":"L2","min":"1000","max":"1000000","ratio":"1.9","status":"off","md_thua":"","md_ht":"0"},"TX":{"cmt_T":"T","cmt_X":"X","min":"1000","max":"1000000","ratio":"2.3","status":"off","md_thua":"0,9","md_ht":"0"},"TX2":{"cmt_T":"T2","cmt_X":"X2","min":"1000","max":"1000000","ratio":"1.9","status":"off","md_thua":"","md_ht":"0"},"1P3":{"cmt_N0":"N0","cmt_N1":"N1","cmt_N2":"N2","cmt_N3":"N3","min":"1000","max":"1000000","ratio_N0":"6","ratio_N1":"3","ratio_N2":"3","ratio_N3":"3","status":"off"},"G3":{"cmt":"G3","min":"1000","max":"1000000","rules_2":"69,66,99","rules_3":"123,234,456,678,789","ratio_2":"4","ratio_3":"6","status":"off"},"T3S":{"cmt":"S","min":"1000","max":"1000000","rules_1":"7,17,27","rules_2":"8,18","rules_3":"9,19","ratio_1":"3","ratio_2":"4","ratio_3":"5","status":"off"},"H2S":{"cmt":"H3","min":"1000","max":"1000000","rules_1":"3","rules_2":"5","rules_3":"7","rules_4":"9","ratio_1":"3","ratio_2":"5","ratio_3":"7","ratio_4":"9","status":"off"},"LO":{"cmt":"LO","min":"1000","max":"1000000","rules":"08,18,34,49","ratio":"4","status":"off"}}'
                    // $data
                ), "`phone` = '$phone' ");
                echo "<script language='javascript'>alert('Login Thành Công');window.location='/momo/list.php';</script>";
                die;
            } else {
                echo "<script language='javascript'>alert('".$login['message']."');window.location='/momo/list.php';</script>";
                die;
            }
        } else {
            // $soicoder->remove("cron_momo","`phone` = '$phone' ");
            $soicoder->update("cron_momo", array('status' => 'error','errorDesc' => $xacminh['message']), "`phone` = '$phone' ");
            echo "<script language='javascript'>alert('Otp Không Hợp Lệ Hoặc ".$xacminh['message']."');window.location='/momo/list.php';</script>";
            die;
        }
    } else {
        echo "<script language='javascript'>alert('Vui Lòng Gửi Otp Trước');window.location='/momo/list.php';</script>";
        die;
    }
} else {
    echo "<script language='javascript'>alert('Vui Lòng Nhập Số Điện Thoại');window.location='/momo/list.php';</script>";
}
