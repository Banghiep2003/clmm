<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');
$phone = check_string($_POST['phone']);
if (strlen($phone) == 10) {
    $momo = new MomoV2($soicoder);
    $select = $soicoder->num_rows("SELECT * FROM `cron_momo` WHERE `phone` = '".$phone."' LIMIT 1 ");
    
    if ($select >= 1) {
        $soicoder->query("UPDATE `cron_momo` SET
            `agent_id` = 'underfined',
            `sessionkey` = '',
            `authorization` = 'underfined' WHERE `phone` = '$phone' ");
    } else {
        $device = $soicoder->fetch_assoc("SELECT * FROM `device` ORDER BY RAND() LIMIT 1 ", 1);
        // $device = array(
        //     "device" => "Oppo realme X Lite",
        //     "hardware" => "RMX1851CN",
        //     "facture" => "Oppo",
        //     "MODELID" => "Oppo RMX1851",
        // );
        // print_r($device);
        // die;
        $data = $momo->getData();
        $soicoder->insert('cron_momo' , array (
                                            'phone' => $phone,
                                            'imei' => $data['imei'],
                                            'SECUREID' => $data['SECUREID'],
                                            'rkey' => $data['rkey'],
                                            'AAID' => $data['AAID'],
                                            'TOKEN' => $data['TOKEN'],
                                            'BALANCE' => '0',
                                            'device' => $device["device"],
                                            'hardware' => $device["hardware"],
                                            'facture' => $device["facture"],
                                            'status' => 'pending',
                                            'MODELID' => $device["MODELID"]
                                        ));
    }
    $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$phone."' LIMIT 1 " , 1) ;
    // print_r($loadDATA);
    $send = $momo->LoadData($loadDATA)->CHECK_USER_BE_MSG();
    $send = $momo->SendOTP();
    // print_r($send);
    // die;
    if ($send['status'] == 'success') {
        // $soicoder->update("cron_momo", array(
        //     'ohash' => $send["ohash"],
        //     'TOKEN' => $send["TOKEN"],
        //     'setupKey' => $send["setupKey"],
        //     'setupKeyDecrypt' => $send["setupKeyDecrypt"]
        // ), "`phone` = '$phone' ");
        $return = array(
            'status' => 'success',
            'veryotp' => 'soicoder',
            'message' => $send['message']
        );
        die(json_encode($return));
    } else {
        $soicoder->remove("cron_momo","`phone` = '$phone' ");
        $return = array(
            'status' => 'error',
            'message' => $send['message']
        );
        die(json_encode($return));
    }
} else {
    $return = array(
        'status' => 'error',
        'message' => 'Vui Lòng Nhập Số Điện Thoại'
    );
    die(json_encode($return));
}
