<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');
$phone = check_string($_POST['phone']); // số điện thoại nhận
$account = check_string($_POST['account']); // tài khoản momo chuyển


if(empty($_SESSION['username'])){
    echo "<script language='javascript'>alert('Vui Lòng Đăng Nhập');window.location='/login';</script>";
        // die;
    header('Location: /login');
    die;
}
if (strlen($account) !== 10) {
    $return = array(
        'status' => 'error',
        'message' => 'Vui Lòng Chọn Tài Khoản Chuyển Tiền'
    );
    die(json_encode($return));
} else if (strlen($phone) !== 10) {
    $return = array(
        'status' => 'error',
        'message' => 'Số Điện Thoại Không Đúng Định Dạng'
    );
    die(json_encode($return));
} else {
    $momo = new MomoV2($soicoder);
    $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$account."' LIMIT 1 " , 1);
    // print_r($loadDATA); die;
    $checkname = $momo->LoadData($loadDATA)->CheckName($phone);
    $return = array(
        'success' => $checkname['name'],
    );
    die(json_encode($return));
}




