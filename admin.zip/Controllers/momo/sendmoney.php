<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');
$phone = check_string($_POST['phone']); // số điện thoại nhận
$account = check_string($_POST['account']); // tài khoản momo chuyển
$amount = check_string($_POST['amount']); // số tiền chuyển
$content = check_string($_POST['content']); // nội dung chuyển
// echo 
if(empty($_SESSION['username'])){
    echo "<script language='javascript'>alert('Vui Lòng Đăng Nhập');window.location='/login';</script>";
        // die;
    header('Location: /login');
    die;
}
if (strlen($account) !== 10) {
    $return = array(
        'status' => 'error',
        'message' => 'Vui Lòng Chọn Tài Khoản Chuyển Tiền'
    );
    echo "<script language='javascript'>alert('".$return['message']."');window.location='/momo/transfer.php';</script>";
    die;
} else if (strlen($phone) !== 10) {
    $return = array(
        'status' => 'error',
        'message' => 'Số Điện Thoại Không Đúng Định Dạng'
    );
    echo "<script language='javascript'>alert('".$return['message']."');window.location='/momo/transfer.php';</script>";
    die;
} else {
    $momo = new MomoV2($soicoder);
    $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$account."' LIMIT 1 " , 1);
    // print_r($loadDATA); die;
        $send = $momo->LoadData($loadDATA)->SendMoney($phone,$amount,$content);
        // print_r($send);
        // die;
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        if ($send['status'] == 'success') {
            $trandID = $send['tranDList']['tranId'];
            $BALANCE = $send['tranDList']['balance'];
            $soicoder->update("cron_momo", array(
                'BALANCE' =>  $BALANCE
            ), " `phone` = '".$account."' ");
            $soicoder->insert('chuyen_tien' , array (
                'type_gd' => 'sendmoney',
                'momo_id' => $send['tranDList']['ID'],
                'tranId' => $send['tranDList']['tranId'],
                'partnerId' => $send['tranDList']['partnerId'],
                'partnerName' => $send['tranDList']['partnerName'],
                'amount' => $amount,
                'comment' => $content,
                'time' => time(),
                'date_time' => date('d/m/Y'),
                'status' => 'success',
                'message' => 'Chuyển Tiền Thành Công',
                'balance' => $BALANCE,
                'ownerNumber' => $send['tranDList']['ownerNumber'],
                'ownerName' => $send['tranDList']['ownerName'],
                'data' => json_encode($send['tranDList']),
                'type' => 'momo'
            ));
            $return = array(
                "status" => "success",
                "code"   => 200,
                "message" => "Chuyển Tiền Thành Công, MGD: ".$trandID.", Số Dư: ".$BALANCE,
            );
            echo "<script language='javascript'>alert('".$return['message']."');window.location='/momo/transfer.php';</script>";
            die;
        } else {
            echo "<script language='javascript'>alert('".$send['message']."');window.location='/momo/transfer.php';</script>";
            die;
        }
    }
