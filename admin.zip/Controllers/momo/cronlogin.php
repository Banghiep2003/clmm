<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');
date_default_timezone_set('Asia/Ho_Chi_Minh');

// cài đặt chung
$setting = $soicoder->fetch_assoc("SELECT * FROM `settings` ", 1);
// check bảo trì
if ($setting['status'] == 'off') {
    die('Web Đang Bảo Trì');
}


$list = $soicoder->fetch_assoc("SELECT `id`, `phone` FROM `cron_momo` LIMIT 1000", 0);
// print_r($list); die;
foreach ($list as $data) {
    $account = $data['phone'];
    $momo = new MomoV2($soicoder);
    $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$account."' LIMIT 1 " , 1);
      $result = $momo->LoadData($loadDATA)->GENERATE_TOKEN_AUTH_MSG();
        // print_r($result); die;
        $extra = $result["extra"];
        // print_r($extra); die;
        if(!in_array('AUTH_TOKEN' , $extra) && !isset($extra['AUTH_TOKEN'])){
            // echo "KKK"; die;
            $result_login = $momo->LoadData($loadDATA)->USER_LOGIN_MSG();
            // print_r($result_login);
            // die;
            if (!empty($result_login["errorCode"])) {
                $return = array(
                    "status" => "error",
                    "code" => $result_login["errorCode"],
                    "message" => $result_login["errorDesc"],
                );
                $soicoder->update("cron_momo", array(
                    'errorDesc' =>  $return["message"],
                    'status' => 'wait_login'
                ), " `phone` = '".$account."' ");
                echo "[".$account.",".$result_login["errorDesc"]."]";
            } else if (is_null($result_login)) {
                $return = array(
                    "status" => "error",
                    "code" => -5,
                    "message" => "Hết thời gian truy cập vui lòng đăng nhập lại");
                
            }
        } else {
            $authorization = $extra["AUTH_TOKEN"];
            $soicoder->update("cron_momo", array(
                'authorization' => soicoder_enc($extra["AUTH_TOKEN"]),
                'RSA_PUBLIC_KEY' => $extra["REQUEST_ENCRYPT_KEY"],
                'sessionkey' => $extra["SESSION_KEY"],
                'errorDesc' => 'Thành Công',
                // 'BALANCE' => $BALANCE,
                'status' => 'success',
                'TimeLogin'  => time()
            ), " `phone` = '" .$account. "' ");
            
        }
        echo "[".$account.",Lấy Lại Token Thành Công]";
    }
 