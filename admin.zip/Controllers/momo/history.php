<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');
$account = check_string($_GET['account']); // tài khoản momo 
$time = check_string($_GET['time']); // thời gian (tính bằng giờ)


// $list = $soicoder->fetch_assoc("SELECT `id`, `tranId`,`amount_play`,`comment`,`phone`,`amount_game`,`game`,`result_number`, `status`, `result_text`, `time` FROM `lich_su_choi` WHERE (status = 'wait') OR (status = 'wait_auto') OR (status = 'wrong') ORDER BY id desc LIMIT 1000", 0);
                            
                            
// $today = $soicoder->fetch_assoc("SELECT DISTINCT `phone` FROM `lich_su_choi` " , 0);
// $list = $soicoder->fetch_assoc("SELECT * FROM `lich_su_choi` WHERE `result` = 'win' ORDER BY id desc LIMIT 10", 1);
                                    

// print_r($list);
// die;



if (isset($account)) {
    $momo = new MomoV2($soicoder);
    $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$account."' LIMIT 1 " , 1) ;
    if (isset($loadDATA['phone'])) {
        $result = $momo->LoadData($loadDATA)->CheckHisNewv3_tran(5, 20);
        // CheckHistCmt('27386036870');
        // CheckHisNewv3_tran(5, 20);
        header("Content-type:text/javscript");
        echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    } else {
        $return = array(
            'status' => 'error',
            'message' => 'SĐT Không Tồn Tại Trên Hệ Thống'
        );
        die(json_encode($return));
    }
    
    

} else {
    $return = array(
        'status' => 'error',
        'message' => 'Vui Lòng Nhập SĐT'
    );
    die(json_encode($return));
}