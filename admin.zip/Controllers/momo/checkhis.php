<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');
$account = check_string($_POST['account']); // tài khoản momo 
$tranId = check_string($_POST['tranId']); // mã giao dịch
// die;
if (isset($_POST['account'])) {
    $momo = new MomoV2($soicoder);
    $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$account."' LIMIT 1 " , 1) ;
    if (isset($loadDATA['phone'])) {
        $check_full = $momo->LoadData($loadDATA)->CheckHistCmt($tranId);
        // print_r($check_full); die;
        // CheckHisNewv3_tran(5, 20);
        if(empty($check_full["momoMsg"]['sourceId']) or empty($check_full["momoMsg"]['io'])) {
            // echo "Lỗi K Tồn Tại";
            echo "<script language='javascript'>alert('Mã Giao Dịch Không Xác Định');window.location='/momo/checkhis.php';</script>";
            die;
        } else {
            $id = $check_full["momoMsg"]["id"];
            $partnerId = $check_full["momoMsg"]["sourceId"];  // số momo
            $serviceData = json_decode($check_full['momoMsg']['serviceData'], true);
            $comment = empty($serviceData['COMMENT_VALUE']) ? "NULL" : $serviceData['COMMENT_VALUE']; // nội dung
            $status = $check_full["momoMsg"]["status"];
            $partnerName = empty($check_full["momoMsg"]["sourceName"]) ? "" : $check_full["momoMsg"]['sourceName'];  // tên
            $amount = empty($check_full["momoMsg"]["totalAmount"]) ? 0 : $check_full["momoMsg"]["totalAmount"];  // số tiền
            $desc = empty($check_full["momoMsg"]["desc"]) ? "" : $check_full["momoMsg"]["desc"];
            $millisecond = empty($check_full["momoMsg"]["lastUpdate"]) ? 0 : $check_full["momoMsg"]['lastUpdate']; // time

            $check = $soicoder->num_rows("SELECT * FROM `lich_su_choi` WHERE `tranId` = '".$tranId."' LIMIT 1 ");
            if ($check !== 0)  {
                $data = $soicoder->fetch_assoc("SELECT * FROM `lich_su_choi` WHERE `tranId` = '".$tranId."' LIMIT 1 ", 1);
                // print_r($data);
                $status = $data['result_text'].' | '.$data['status'];
            }
            $_SESSION['check_his'] = array(
                "id" => $id,
                "tranId" => $tranId,
                "partnerId" => $partnerId,
                "comment" => $comment,
                "status" => $status,
                "partnerName" => $partnerName,
                "amount" => $amount,
                "desc" => $desc,
                "millisecond" => $millisecond
            );
            echo "<script language='javascript'>window.location='/momo/checkhis.php';</script>";
            die;
        }
    } else {
        echo "<script language='javascript'>alert('SĐT Không Tồn Tại Trên Hệ Thống');window.location='/momo/checkhis.php';</script>";
        die;
    }
} else {
    echo "<script language='javascript'>alert('Vui Lòng Nhập SĐT');window.location='/momo/checkhis.php';</script>";
    die;
}
?>