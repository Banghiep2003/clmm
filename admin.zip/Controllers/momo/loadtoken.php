<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');
// $account = check_string($_GET['account']); // tài khoản momo 
$list = $soicoder->fetch_assoc("SELECT `id`, `phone` FROM `cron_momo` LIMIT 1000", 0);
// print_r($list); die;
foreach ($list as $data) {
    $account = $data['phone'];
    $momo = new MomoV2($soicoder);
    $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$account."' LIMIT 1 " , 1) ;
    if ($loadDATA['TimeLogin'] < time() - 0) {
        $result = $momo->LoadData($loadDATA)->GENERATE_TOKEN_AUTH_MSG();
        // print_r($result); die;
        $extra = $result["extra"];
        // print_r($extra); die;
        if(!in_array('AUTH_TOKEN' , $extra) && !isset($extra['AUTH_TOKEN'])){
            // echo "KKK"; die;
            $result_login = $momo->LoadData($loadDATA)->USER_LOGIN_MSG();
            // print_r($result_login);
            // die;
            if (!empty($result_login["errorCode"])) {
                $return = array(
                    "status" => "error",
                    "code" => $result_login["errorCode"],
                    "message" => $result_login["errorDesc"],
                );
                $soicoder->update("cron_momo", array(
                    'errorDesc' =>  $return["message"],
                    'status' => 'wait_login'
                ), " `phone` = '".$account."' ");
                // echo (json_encode($return));
            } else if (is_null($result_login)) {
                $return = array(
                    "status" => "error",
                    "code" => -5,
                    "message" => "Hết thời gian truy cập vui lòng đăng nhập lại",
                );
                $soicoder->update("cron_momo", array(
                    'errorDesc' =>  $return["message"],
                    'status' => 'wait_login'
                ), " `phone` = '".$account."' ");
                // echo (json_encode($return));
            } else {
                $extra_login = $result_login["extra"];
                $BankVerify = ($result_login['momoMsg']['bankVerifyPersonalid'] == 'null') ? '1' : '2';
                $partnerCode = $result_login['momoMsg']['bankCode'] ?: '';
                $authorization = $extra_login["AUTH_TOKEN"];
                $soicoder->update("cron_momo", array(
                    'authorization' => soicoder_enc($extra_login["AUTH_TOKEN"]),
                    'try' => '0',
                    'BankVerify' => $BankVerify,
                    'agent_id' => $result_login["momoMsg"]["agentId"],
                    'RSA_PUBLIC_KEY' => $extra_login["REQUEST_ENCRYPT_KEY"],
                    'refreshToken' => $extra_login["REFRESH_TOKEN"],
                    'sessionkey' => $extra_login["SESSION_KEY"],
                    'partnerCode' => $partnerCode,
                    'errorDesc' => $result_login["errorCode"],
                    // 'BALANCE' => $BALANCE,
                    'status' => 'success',
                    'errorDesc' => 'Thành Công',
                    'TimeLogin' => time()
                ), " `phone` = '".$account."' ");
                $type = "LOGIN";
                $return = array(
                    'status' => 'success',
                    'type' => $type,
                    'authorization' => $authorization,
                    'message' => "Get Token Thành Công"
                );
            }
        } else {
            $authorization = $extra["AUTH_TOKEN"];
            // $check_BALANCE = $momo->LoadData($loadDATA)->CheckHisNewv3_tran(24, 5);
            // $BALANCE = empty($check_BALANCE['TranList'][0]['postBalance']) ? '0' : $check_BALANCE['TranList'][0]['postBalance'];
            $soicoder->update("cron_momo", array(
                'authorization' => soicoder_enc($extra["AUTH_TOKEN"]),
                'RSA_PUBLIC_KEY' => $extra["REQUEST_ENCRYPT_KEY"],
                'sessionkey' => $extra["SESSION_KEY"],
                'errorDesc' => 'Thành Công',
                // 'BALANCE' => $BALANCE,
                'status' => 'success',
                'TimeLogin'  => time()
            ), " `phone` = '" .$account. "' ");
            $type = "NOLOGIN";
            $return = array(
                'status' => 'success',
                'type' => $type,
                'authorization' => $authorization,
                'message' => "Get Token Thành Công"
            );
        }
        // echo (json_encode($return));
    } else {
        $return = array(
            'status' => 'error',
            'message' => 'Hạn Chế Get Lại Token Nhé'
        );
    }
    // check số dư
    $check_BALANCE = $momo->LoadData($loadDATA)->CheckHisNewv3_tran(5, 20);
    // print_r($check_BALANCE); 
    $BALANCE = empty($check_BALANCE['TranList'][0]['postBalance']) ? '0' : $check_BALANCE['TranList'][0]['postBalance'];
    $soicoder->update("cron_momo", array(
        'BALANCE' => $BALANCE,
    ), " `phone` = '" .$account. "' ");
}

echo "<script language='javascript'>alert('Cập Nhật Số Dư Thành Công');window.location='/momo/list.php';</script>";
die;
