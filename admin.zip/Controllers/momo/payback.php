<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');
$id = check_string($_GET['id']); // số điện thoại nhận

error_reporting(E_ALL);
// check login
if(empty($_SESSION['username'])){
    echo "<script language='javascript'>alert('Vui Lòng Đăng Nhập');window.location='/login';</script>";
        // die;
    header('Location: /login');
    die;
}

// check tt chưa/rồi
$check = $soicoder->num_rows("SELECT * FROM `lich_su_choi` WHERE `id` = '".$id."' AND `status` = 'done'");
echo $check;
if ($check == '0')  {
    $data = $soicoder->fetch_assoc("SELECT * FROM `lich_su_choi` WHERE `id` = '".$id."'", 1);
    // print_r($data); die;
    if ($data['result'] !== 'win') {
        echo "<script language='javascript'>alert('Win CC Đâu Mà Trả Tiền');window.location='/service/history-error.php';</script>";
    }
    $account = $data['phone_nhan'];
    $tranId = $data['tranId'];
    $phone = change_phone($data['phone']);
    $amount = $data['result_number'];
    $content = $data['msg_send'];
    
    $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$account."' LIMIT 1 " , 1);
    // print_r($loadDATA); 
    // echo $phone.'|'.$amount.'|'.$content;
    // die;
    $momo = new MomoV2($soicoder);
    $send = $momo->LoadData($loadDATA)->SendMoney($phone,$amount,$content);
    if ($send['status'] == 'success') {
        $trandID = $send['tranDList']['tranId'];
        $BALANCE = $send['tranDList']['balance'];
        $return = "Thanh Toán Thành Công, MGD: ".$trandID.", Số Dư: ".$BALANCE;
        $soicoder->update("lich_su_choi", array(
            'status' => 'done',
            'result_text' => 'Đã Thanh Toán Tay/Auto'
        ), " `id` = '".$id."' ");
        echo "<script language='javascript'>alert('".$return."');window.location='/service/history-error.php';</script>";
        die;
    } else {
        echo "<script language='javascript'>alert('".$send['message']."');window.location='/service/history-error.php';</script>";
        die;
    }
    echo $data['phone_nhan'];
} else {
    echo "<script language='javascript'>alert('Đơn Này Đã Được Trả Thưởng');window.location='/service/history-error.php';</script>";
    die;
}