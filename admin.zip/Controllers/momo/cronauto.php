<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');
date_default_timezone_set('Asia/Ho_Chi_Minh');

// cài đặt chung
$setting = $soicoder->fetch_assoc("SELECT * FROM `settings` ", 1);
// check bảo trì
if ($setting['status'] == 'off') {
    die('Web Đang Bảo Trì');
}


$type_check = 1; // 1 là check bằng noti, 2 là check bằng LSGD
$limit = $setting['limit_trans']; // số giao dịch cần check
$msg_send = $setting['content']; // nội dung khi trả thưởng

$list = $soicoder->fetch_assoc("SELECT * FROM `cron_momo` WHERE `status` = 'success' LIMIT 1000", 0);

foreach ($list as $data) {
    $phone = $data['phone'];
    $momo = new MomoV2($soicoder);
    $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$phone."' AND `try` = 'on' LIMIT 1 " , 1);
    // check số thành công
    if ($data['errorDesc'] !== 'Thành Công') {
        continue;
    }
    // check cron
    
    $check = $soicoder->update("cron_momo", array(
        'share_fund' => time()
    ), " `phone` = '".$phone."' ");
    if (!$check ) {
        echo "Update Thất Bại";
    }
    
    if ($loadDATA['share_fund'] > time() - 3) {
        echo "[".$phone.",Hạn Chế Cron]";
        continue;
    }
    // check lịch sử giao dịch
    if ($type_check == 1) {
        $result = $momo->LoadData($loadDATA)->CheckHisNewv3_tran(5, $limit);
    } else {
        $result = $momo->LoadData($loadDATA)->CheckHisNew(5);
    }
    
   
    
    

    // print_r($result); 
    if ($result['status'] == 'success') {
        if (count($list) == 0) {
            continue;
        } else {
             // cập nhập số dư
            $BALANCE = empty($result['TranList'][0]['postBalance']) ? '0' : $result['TranList'][0]['postBalance'];
            $soicoder->update("cron_momo", array(
                'BALANCE' => $BALANCE,
            ), " `phone` = '" .$phone. "' ");
    
    
            // check từng cái
            for($i = 0; $i < count($result['TranList']); $i++) {
                $id = $result["TranList"][$i]["id"]; // ID
                $tranId = $result["TranList"][$i]["transId"]; // mã giao dịch
                $io = $result["TranList"][$i]["io"]; // check nhận/chuyển
                if ($io == -1) {
                    continue; // bỏ qua giao dịch chuyển đi
                }
                // check đã tồn tại hay chưa
                $check = $soicoder->num_rows("SELECT * FROM `lich_su_choi` WHERE `phone_nhan` = '".$phone."' AND `id_momo` = '".$id."' LIMIT 1 ");
                if ($check == 0) {
                    $check_full = $momo->CheckHistCmt($tranId);
                    // print_r($check_full);
                    if(empty($check_full["momoMsg"]['sourceId']) or empty($check_full["momoMsg"]['io'])) {
                        continue;
                    } else {
                        // print_r($check_full);
                    
                        $partnerId = $check_full["momoMsg"]["sourceId"];  // số momo
                        if ($partnerId == 'fifs_fastredeem') {
                            continue;
                        }
                        if ($check_full["momoMsg"]["io"] == -1) {
                            continue;
                        }
                        
                        echo $tranId.'[new],';
                        $serviceData = json_decode($check_full['momoMsg']['serviceData'], true);
                        $config = json_decode($loadDATA['DataJson'], true);
                        
                        
                        $CL = $config['CL'];
                        $CL2 = $config['CL2'];
                        $TX = $config['TX'];
                        $TX2 = $config['TX2']; 
                        $_1P3 = $config['1P3'];
                        $G3 = $config['G3'];
                        $T3S = $config['T3S'];
                        $H2S = $config['H2S'];
                        $LO = $config['LO'];
                        
                        $check_cmt = array (
                            $CL['cmt_C'] => 'CL',
                            $CL['cmt_L'] => 'CL',
                            $CL2['cmt_C'] => 'CL2',
                            $CL2['cmt_L'] => 'CL2',
                            $TX['cmt_T'] => 'TX',
                            $TX['cmt_X'] => 'TX',
                            $TX2['cmt_T'] => 'TX2',
                            $TX2['cmt_X'] => 'TX2',
                            $_1P3['cmt_N0'] => '1P3',
                            $_1P3['cmt_N1'] => '1P3',
                            $_1P3['cmt_N2'] => '1P3',
                            $_1P3['cmt_N3'] => '1P3',
                            $G3['cmt'] => 'G3',
                            $T3S['cmt'] => 'T3S',
                            $H2S['cmt'] => 'H2S',
                            $LO['cmt'] => 'LO'
                        );
                        
                        // header("Content-type:text/javscript");
                        // echo json_encode($check_cmt, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                        $comment = empty($serviceData['COMMENT_VALUE']) ? "NULL" : strtoupper($serviceData['COMMENT_VALUE']); // nội dung
                        $status = $check_full["momoMsg"]["status"];
                        $partnerName = empty($check_full["momoMsg"]["sourceName"]) ? "" : $check_full["momoMsg"]['sourceName'];  // tên
                        $amount = empty($check_full["momoMsg"]["totalAmount"]) ? 0 : $check_full["momoMsg"]["totalAmount"];  // số tiền
                        $desc = empty($check_full["momoMsg"]["desc"]) ? "" : $check_full["momoMsg"]["desc"];
                        $millisecond = empty($check_full["momoMsg"]["lastUpdate"]) ? 0 : $check_full["momoMsg"]['lastUpdate']; // time
                        // check game
                        if ($comment == $CL['cmt_C'] || $comment == $CL['cmt_L']) {
                            $game = 'CL';
                        } else if ($comment == $CL2['cmt_C'] || $comment == $CL2['cmt_L']) {
                            $game = 'CL2';
                        } else if ($comment == $TX['cmt_T'] || $comment == $TX['cmt_X']) {
                            $game = 'TX';
                        } else if ($comment == $TX2['cmt_T'] || $comment == $TX2['cmt_X']) {
                            $game = 'TX2';
                        } else if ($comment == $_1P3['cmt_N0'] || $comment == $_1P3['cmt_N1'] || $comment == $_1P3['cmt_N2'] || $comment == $_1P3['cmt_N3']) {
                            $game = '1P3';
                        } else if ($comment == $G3['cmt']) {
                            $game = 'G3';
                        } else if ($comment == $T3S['cmt']) {
                            $game = 'T3S';
                        } else if ($comment == $H2S['cmt']) {
                            $game = 'H2S';
                        } else if ($comment == $LO['cmt']) {
                            $game = 'LO';
                        } else {
                            $game = 'NULL';
                        }
                        // if (in_array($comment, $check_cmt) || strpos($comment, json_encode($check_cmt)) !== false)  {
                        //     $game = $check_cmt[$comment];
                        // } else {
                        //     $game = 'NULL';
                        // }
                        
                        echo "[".$tranId.",".$game."]";
                        $soicoder->insert('lich_su_choi' , array (
                            'phone' => $partnerId,
                            'phone_nhan' => $phone,
                            'tranId' => $tranId,
                            'partnerName' => $partnerName,
                            'id_momo' => $id,
                            'amount_play' => $amount,
                            'amount_game' => '0',
                            'comment' => $comment,
                            'game' => $game,
                            'ma_game' => $game,
                            'result' => 'undefined',
                            'result_text' => 'success',
                            'msg_send' => 'undefined',
                            'type_gd' => 'momo',
                            'status' => 'undefined',
                            'result_number' => 'unpaid',
                            'time_tran' => date('d/m/Y'),
                            'time' => time()
                        ));
                        $soicoder->update("cron_momo", array(
                            'receive_day' => $loadDATA['receive_day'] + $amount,
                            'receive_mon' => $loadDATA['receive_mon'] + $amount,
                        ), " `phone` = '".$phone."' ");
                        // die;
                    }
                    
                // test khi chưa fix
                // $tranId = $result['TranList'][$i]['tranId'];  // mã giao dịch
                // $id = $result['TranList'][$i]['ID']; // ID
                // $partnerId = $result['TranList'][$i]['patnerID'];  // số momo
                // $partnerName = $result['TranList'][$i]['partnerName'];  // tên
                // $comment = $result['TranList'][$i]['comment']; // nội dung
                // $amount = $result['TranList'][$i]['amount'];  // số tiền
                // $millisecond  = $result['TranList'][$i]['millisecond'];  // time




                // echo "SELECT * FROM `lich_su_choi` WHERE `id_momo` = '".$id."' AND `tranId` = '".$tranId."' LIMIT 1 ";
                // $check = $soicoder->num_rows("SELECT * FROM `lich_su_choi` WHERE `id_momo` = '".$id."' AND `tranId` = '".$tranId."' LIMIT 1 ");
                // print_r($check); die;
                // print_r($result['TranList'][$i]);
                // if ($check == 0)  {
                    // echo "CHECK";
                    $end1c = substr($tranId ,-1);  // 1 số cuối
                    $end2c = substr($tranId ,-2);  // 2 số cuối
                    $end3c = substr($tranId ,-3);  // 3 số cuối
                    $endkc = substr($end2c , 0, 1); // số kề cuối
                    $endk2c = substr($end3c , 0, 1); // số thứ 3 kể từ cuối
                    // cấu hình
                    $config = json_decode($loadDATA['DataJson'], true);
                    $CL = $config['CL'];
                    $CL2 = $config['CL2'];
                    $TX = $config['TX'];
                    $TX2 = $config['TX2']; 
                    $_1P3 = $config['1P3'];
                    $G3 = $config['G3'];
                    $T3S = $config['T3S'];
                    $H2S = $config['H2S'];
                    $LO = $config['LO'];
// =========================================[ CHECK GAME ]==================================================
                    // check CL
                    if ($CL['status'] == 'on') {
                        if ($amount >= $CL['min'] && $amount <= $CL['max']) {
                            $expel = explode(',', $CL['md_thua']);
                            if ($end1c % 2 == 0 && !in_array($end1c, $expel) && $comment == $CL['cmt_C']) {
                                $money = $CL['ratio']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $CL['ratio'],
                                        'game' => 'CL',
                                        'ma_game' => 'CL',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    // $soicoder->update("cron_momo", array(
                                    //     'errorDesc' =>  $send["message"],
                                    //     'status' => 'wait_login'
                                    // ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $CL['ratio'],
                                        'game' => 'CL',
                                        'ma_game' => 'CL',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN CL";
                                continue;
                                
                                // die;
                            }
                            if ($end1c % 2 == 1 && !in_array($end1c, $expel) && $comment == $CL['cmt_L']) {
                                $money = $CL['ratio']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                // print_r($send);
                                // die;
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $CL['ratio'],
                                        'game' => 'CL',
                                        'ma_game' => 'CL',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $CL['ratio'],
                                        'game' => 'CL',
                                        'ma_game' => 'CL',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN CL";
                                continue;
                                
                                // die;
                            }
                        } else  {
                            $soicoder->update("lich_su_choi", array(
                                        'status' => 'wrong'
                            ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                        }
                    }

                    // check CL2
                    if ($CL2['status'] == 'on') {
                        if ($amount >= $CL2['min'] && $amount <= $CL2['max']) {
                            $expel = explode(',', $CL2['md_thua']);
                            if ($end1c % 2 == 0 && !in_array($end1c, $expel) && $comment == $CL2['cmt_C']) {
                                // echo "KKK"; die;
                                $money = $CL2['ratio']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                // print_r($send);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
    
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $CL2['ratio'],
                                        'game' => 'CL2',
                                        'ma_game' => 'CL2',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $CL2['ratio'],
                                        'game' => 'CL2',
                                        'ma_game' => 'CL2',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN CL2";
                                continue;
                                
                                // die;
                            }
                            if ($end1c % 2 == 1 && !in_array($end1c, $expel) && $comment == $CL2['cmt_L']) {
                                $money = $CL2['ratio']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
    
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $CL2['ratio'],
                                        'game' => 'CL2',
                                        'ma_game' => 'CL2',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $CL2['ratio'],
                                        'game' => 'CL2',
                                        'ma_game' => 'CL2',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN CL2";
                                continue;
                                
                                // die;
                            }
                        } else {
                            $soicoder->update("lich_su_choi", array(
                                        'status' => 'wrong'
                            ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                        }
                    }

                    // check TX
                    if ($TX['status'] == 'on') {
                        if ($amount >= $TX['min'] && $amount <= $TX['max']) {
                            $expel = explode(',', $TX['md_thua']);
                            if ($end1c >= 5 && !in_array($end1c, $expel) && $comment == $TX['cmt_T']) {
                                // echo "KKK"; die;
                                $money = $TX['ratio']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                // print_r($send);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $TX['ratio'],
                                        'game' => 'TX',
                                        'ma_game' => 'TX',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $TX['ratio'],
                                        'game' => 'TX',
                                        'ma_game' => 'TX',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN TX";
                                continue;
                                
                                // die;
                            }
                            if ($end1c <= 4 && !in_array($end1c, $expel) && $comment == $TX['cmt_X']) {
                                $money = $TX['ratio']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $TX['ratio'],
                                        'game' => 'TX',
                                        'ma_game' => 'TX',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $TX['ratio'],
                                        'game' => 'TX',
                                        'ma_game' => 'TX',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN TX";
                                continue;
                                
                                // die;
                            }
                        } else {
                            $soicoder->update("lich_su_choi", array(
                                        'status' => 'wrong'
                            ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                        }
                    }
                    // check TX2
                    if ($TX2['status'] == 'on') {
                        if ($amount >= $TX2['min'] && $amount <= $TX2['max']) {
                            $expel = explode(',', $TX2['md_thua']);
                            if ($end1c >= 5 && !in_array($end1c, $expel) && $comment == $TX2['cmt_T']) {
                                // echo "KKK"; die;
                                $money = $TX2['ratio']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                // print_r($send);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $TX2['ratio'],
                                        'game' => 'TX2',
                                        'ma_game' => 'TX2',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $TX2['ratio'],
                                        'game' => 'TX2',
                                        'ma_game' => 'TX2',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN TX2";
                                continue;
                                
                                // die;
                            }
                            if ($end1c <= 4 && !in_array($end1c, $expel) && $comment == $TX2['cmt_X']) {
                                $money = $TX2['ratio']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $TX2['ratio'],
                                        'game' => 'TX2',
                                        'ma_game' => 'TX2',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $TX2['ratio'],
                                        'game' => 'TX2',
                                        'ma_game' => 'TX2',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN TX2";
                                continue;
                                
                                // die;
                            }
                        } else {
                            $soicoder->update("lich_su_choi", array(
                                        'status' => 'wrong'
                            ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                        }
                    }

                    // check một phần 3
                    if ($_1P3['status'] == 'on') {
                        if ($amount >= $_1P3['min'] && $amount <= $_1P3['max']) {
                            // N0
                            if ($end1c == 0 && $comment == $_1P3['cmt_N0']) {
                                $money = $_1P3['ratio_N0']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $_1P3['ratio_N0'],
                                        'game' => '1P3',
                                        'ma_game' => '1P3',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $_1P3['ratio_N0'],
                                        'game' => '1P3',
                                        'ma_game' => '1P3',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN 1P3";
                                continue;
                                
                            }
                            // N1
                            if (in_array($end1c, ["1", "2", "3"]) && $comment == $_1P3['cmt_N1']) {
                                $money = $_1P3['ratio_N1']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $_1P3['ratio_N1'],
                                        'game' => '1P3',
                                        'ma_game' => '1P3',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $_1P3['ratio_N1'],
                                        'game' => '1P3',
                                        'ma_game' => '1P3',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN 1P3";
                                continue;
                                
                            }
                            // N2
                            if (in_array($end1c, ["4", "5", "6"]) && $comment == $_1P3['cmt_N2']) {
                                $money = $_1P3['ratio_N2']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $_1P3['ratio_N2'],
                                        'game' => '1P3',
                                        'ma_game' => '1P3',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $_1P3['ratio_N2'],
                                        'game' => '1P3',
                                        'ma_game' => '1P3',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN 1P3";
                                continue;
                                
                            }
                            // N3
                            if (in_array($end1c, ["7", "8", "9"]) && $comment == $_1P3['cmt_N3']) {
                                $money = $_1P3['ratio_N3']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $_1P3['ratio_N3'],
                                        'game' => '1P3',
                                        'ma_game' => '1P3',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $_1P3['ratio_N3'],
                                        'game' => '1P3',
                                        'ma_game' => '1P3',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN 1P3";
                                continue;
                                
                            }
                        } else {
                            $soicoder->update("lich_su_choi", array(
                                        'status' => 'wrong'
                            ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                        }
                    }
                    // check G3
                    if ($G3['status'] == 'on') {
                        if ($amount >= $G3['min'] && $amount <= $G3['max']) {
                            $lis_rules_2 = explode(',', $G3['rules_2']);
                            $lis_rules_3 = explode(',', $G3['rules_3']);
                            if (in_array($end2c, $lis_rules_2) && $comment == $G3['cmt']) {
                                $money = $G3['ratio_2']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $G3['ratio_2'],
                                        'game' => 'G3',
                                        'ma_game' => 'G3',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $G3['ratio_2'],
                                        'game' => 'G3',
                                        'ma_game' => 'G3',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN G3";
                                continue;
                                
                            }
                            if (in_array($end3c, $lis_rules_3) && $comment == $G3['cmt']) {
                                $money = $G3['ratio_3']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $G3['ratio_3'],
                                        'game' => 'G3',
                                        'ma_game' => 'G3',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $G3['ratio_3'],
                                        'game' => 'G3',
                                        'ma_game' => 'G3',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN G3";
                                continue;
                                
                            }
                        } else {
                            $soicoder->update("lich_su_choi", array(
                                        'status' => 'wrong'
                            ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                        }
                    }

                    // check tổng 3 số
                    if ($T3S['status'] == 'on') {
                        if ($amount >= $T3S['min'] && $amount <= $T3S['max']) {
                            $lis_rules_1 = explode(',', $T3S['rules_1']);
                            $lis_rules_2 = explode(',', $T3S['rules_2']);
                            $lis_rules_3 = explode(',', $T3S['rules_3']);
                            $tong = $end1c + $endkc + $endk2c;
                            if (in_array($tong, $lis_rules_1) && $comment == $T3S['cmt']) {
                                $money = $T3S['ratio_1']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $T3S['ratio_1'],
                                        'game' => 'T3S',
                                        'ma_game' => 'T3S',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $T3S['ratio_1'],
                                        'game' => 'T3S',
                                        'ma_game' => 'T3S',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN T3S";
                                continue;
                                
    
                            }
    
                            if (in_array($end2c, $lis_rules_2) && $comment == $T3S['cmt']) {
                                $money = $T3S['ratio_2']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $T3S['ratio_2'],
                                        'game' => 'T3S',
                                        'ma_game' => 'T3S',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $T3S['ratio_2'],
                                        'game' => 'T3S',
                                        'ma_game' => 'T3S',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN T3S";
                                continue;
                                
    
                            }
    
                            if (in_array($end2c, $lis_rules_3) && $comment == $T3S['cmt']) {
                                $money = $T3S['ratio_3']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $T3S['ratio_3'],
                                        'game' => 'T3S',
                                        'ma_game' => 'T3S',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $T3S['ratio_3'],
                                        'game' => 'T3S',
                                        'ma_game' => 'T3S',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN T3S";
                                continue;
                                
    
                            }
                        } else {
                            $soicoder->update("lich_su_choi", array(
                                        'status' => 'wrong'
                            ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                        }
                    }

                    // check hiệu 2 số
                    if ($H2S['status'] == 'on') {
                        if ($amount >= $H2S['min'] && $amount <= $H2S['max']) {
                            $hieu = $endkc - $end1c;
                            if ($hieu == $H2S['rules_1'] && $comment == $H2S['cmt']) {
                                $money = $H2S['ratio_1']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $H2S['ratio_1'],
                                        'game' => 'H2S',
                                        'ma_game' => 'H2S',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $T3S['ratio_1'],
                                        'game' => 'H2S',
                                        'ma_game' => 'H2S',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN H2S";
                                continue;
                                
                            }
    
                            if ($hieu == $H2S['rules_2'] && $comment == $H2S['cmt']) {
                                $money = $H2S['ratio_2']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $H2S['ratio_2'],
                                        'game' => 'H2S',
                                        'ma_game' => 'H2S',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $T3S['ratio_2'],
                                        'game' => 'H2S',
                                        'ma_game' => 'H2S',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN H2S";
                                continue;
                                
                            }
                            if ($hieu == $H2S['rules_3'] && $comment == $H2S['cmt']) {
                                $money = $H2S['ratio_3']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $H2S['rules_3'],
                                        'game' => 'H2S',
                                        'ma_game' => 'H2S',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $H2S['rules_3'],
                                        'game' => 'H2S',
                                        'ma_game' => 'H2S',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN H2S";
                                continue;
                                
                            }
    
                            if ($hieu == $H2S['rules_4'] && $comment == $H2S['cmt']) {
                                $money = $H2S['ratio_4']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $H2S['ratio_4'],
                                        'game' => 'H2S',
                                        'ma_game' => 'H2S',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $H2S['ratio_4'],
                                        'game' => 'H2S',
                                        'ma_game' => 'H2S',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                echo $partnerId." WIN H2S";
                                continue;
                                
                            }
                        } else {
                            $soicoder->update("lich_su_choi", array(
                                        'status' => 'wrong'
                            ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                        }
                    }
                    // LÔ
                    if ($LO['status'] == 'on') {
                        if ($amount >= $LO['min'] && $amount <= $LO['max']) {
                            $lis_rules = explode(',', $LO['rules']);
                            if (in_array($end2c, $lis_rules) && $comment == $LO['cmt']) {
                                $money = $LO['ratio']*$amount;
                                $content = $msg_send." | ".$tranId." | TT";
                                $send = $momo->LoadData($loadDATA)->SendMoney($partnerId,$money,$content);
                                if ($send['status'] == 'success') {
                                    $BALANCE = $send['tranDList']['balance'];
                                    $soicoder->update("cron_momo", array(
                                        'BALANCE' =>  $BALANCE,
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money
                                    ), " `phone` = '".$phone."' ");
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $LO['ratio'],
                                        'game' => 'LO',
                                        'ma_game' => 'LO',
                                        'result' => 'win',
                                        'msg_send' => $content,
                                        'status' => 'done',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                } else {
                                    $soicoder->update("cron_momo", array(
                                        'today_gd' => $loadDATA['today_gd'] + 1,
                                        'ex_day' => $loadDATA['ex_day'] + $money,
                                        'receive_day' => $loadDATA['receive_day'] + $money,
                                        'ex_mon' => $loadDATA['ex_mon'] + $money,
                                        'receive_mon' => $loadDATA['receive_mon'] + $money,
                                    ), " `phone` = '".$phone."' ");
    
                                    $soicoder->update("lich_su_choi", array(
                                        'amount_game' => $LO['ratio'],
                                        'game' => 'LO',
                                        'ma_game' => 'LO',
                                        'result' => 'win',
                                        'result_text' => $send["message"],
                                        'msg_send' => $content,
                                        'status' => 'wait',
                                        'result_number' => $money
                                    ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                                }
                                
                                echo $partnerId." WIN LO";
                                continue;
                            }
                        } else {
                            $soicoder->update("lich_su_choi", array(
                                        'status' => 'wrong'
                            ), " `id_momo` = '".$id."' AND `tranId` = '".$tranId."' ");
                        }
                    }






                }
            }
        }
    
    }
}
echo "Không Có Giao Dịch Nào Win";