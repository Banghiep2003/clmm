<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/session.php');
$session = new Session();
$session->start();
$session->destroy();
header("Location: /login");