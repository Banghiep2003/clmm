<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
    />

    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
    />

    <link rel="stylesheet" href="../assets/css/style.css" />
    <title>Lite Mac</title>
  </head>
  <body>
    <div class="dashboard">
      <div class="navbar">
        <div class="navbar__content">
          <div class="navbar__logo">
            <a href="../index.html"><img src="../assets/img/logo.png" /></a>
          </div>
          <div class="navbar__menu">
            <h3>MENU</h3>
            <ul class="navbar__menu__list">
              <li class="navbar__menu__item hover">
                <a class="navbar__menu__item__link active" href="../index.html"
                  >Tổng quan</a
                >
              </li>
              <div class="according">
                <li class="navbar__menu__parent navbar__menu__item">
                  <a class="navbar__menu__item__link">MoMo</a>
                </li>
                <ul class="navbar__menu__children">
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="../momo/list.html"
                      class="navbar__menu__children__item__link"
                      >Danh Sách</a
                    >
                  </li>
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="../momo/transfer.html"
                      class="navbar__menu__children__item__link"
                      >Chuyển tiền</a
                    >
                  </li>
                </ul>
              </div>
              <div class="according">
                <li class="navbar__menu__parent navbar__menu__item">
                  <a class="navbar__menu__item__link" href="#">Mini Game</a>
                </li>
                <ul class="navbar__menu__children">
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="../service/report.html"
                      class="navbar__menu__children__item__link"
                      >Thống kê</a
                    >
                  </li>
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="../service/min-game.html"
                      class="navbar__menu__children__item__link"
                      >Danh sách</a
                    >
                  </li>
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="../service/history.html"
                      class="navbar__menu__children__item__link"
                      >Lịch sử</a
                    >
                  </li>
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="../service/history-pay.html"
                      class="navbar__menu__children__item__link"
                      >Lịch sử trả tiền</a
                    >
                  </li>
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="../service/history-black.html"
                      class="navbar__menu__children__item__link"
                      >Danh sách đen</a
                    >
                  </li>
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="../service/history-error.html"
                      class="navbar__menu__children__item__link"
                      >Danh sách lỗi</a
                    >
                  </li>
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="../service/report-user.html"
                      class="navbar__menu__children__item__link"
                      >Thống kê người dùng</a
                    >
                  </li>
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="../service/logs.html"
                      class="navbar__menu__children__item__link"
                      >Logs</a
                    >
                  </li>
                </ul>
              </div>
              <div class="according">
                <li class="navbar__menu__parent navbar__menu__item">
                  <a class="navbar__menu__item__link" href="#">Lịch sử event</a>
                </li>
                <ul class="navbar__menu__children">
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="./gift.html"
                      class="navbar__menu__children__item__link"
                      >Hũ</a
                    >
                  </li>
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="./bonus.html"
                      class="navbar__menu__children__item__link"
                      >Bonus</a
                    >
                  </li>
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="./task.html"
                      class="navbar__menu__children__item__link"
                      >Nhiệm vụ ngày</a
                    >
                  </li>
                  <li
                    class="navbar__menu__item hover navbar__menu__children__item"
                  >
                    <a
                      class="navbar__menu__item__link"
                      href="./top.html"
                      class="navbar__menu__children__item__link"
                      >Top</a
                    >
                  </li>
                </ul>
              </div>
            </ul>
          </div>
        </div>
      </div>
      <div class="right">
        <header class="header">
          <div class="header__logo"><img src="../assets/img/logo.png" /></div>
          <div class="header__inner">
            <div class="header__icon header__icon--xmark">
              <i class="fa-solid fa-xmark"></i>
            </div>
            <div class="header__icon header__icon--bars">
              <i class="fa-solid fa-bars"></i>
            </div>

            <div class="header__icon header__icon--user">
              <i class="fa-solid fa-user"></i>
            </div>
          </div>
        </header>
        <!-- Content -->
        <div class="content">
          <div class="content__inner">
            <div class="content__inner__heading">
              <p>Lịch sử Bonus</p>
              <span> >&ensp; MiniGame &ensp;></span>
              <span>Lịch sử Bonus</span>
            </div>
            <div class="content__ant content__card__border">
              <div class="content__card__body">
                <div class="content__ant__card">
                  <div class="content__ant__card__filter">
                    <form class="form">
                      <div class="form__control">
                        <p>Show</p>
                        <select class="form__select">
                          <option>1</option>
                          <option>2</option>
                          <option>3</option>
                          <option>4</option>
                        </select>
                        <p>entries</p>
                      </div>
                      <div class="form__control">
                        <label for="search">Search</label>
                        <input
                          type="text"
                          class="form__control__input"
                          id="search"
                        />
                      </div>
                    </form>
                  </div>
                  <div class="content__ant__card__table table-responsive">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th style="text-align: center">ID</th>
                          <th style="text-align: center">Mã giao dịch</th>
                          <th style="text-align: center">Số tiền</th>
                          <th style="text-align: center">Comment</th>
                          <th style="text-align: center">Số điện thoại</th>
                          <th style="text-align: center">WIN</th>
                          <th style="text-align: center">Actions</th>
                          <th style="text-align: center">Thời gian</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>...</td>
                          <td>...</td>
                          <td>...</td>
                          <td>...</td>
                          <td>...</td>
                          <td>...</td>
                          <td>...</td>
                          <td>...</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div class="paginator">
                    <ul class="pagination">
                      <li class="page-item disabled">
                        <a class="page-link" href="#">Previous</a>
                      </li>
                      <li class="page-item">
                        <a class="page-link" href="#">1</a>
                      </li>

                      <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Close Content -->
      </div>
    </div>
    <script src="../assets/scripts/collapse.js"></script>
    <script src="../assets/scripts/navbar.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
