<?php session_start(); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/head.php'); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/nav.php'); ?>

        <!-- Content -->
        <div class="content">
          <div class="content__inner">
            <div class="content__inner__heading">
              <p>Logs</p>
              <span> >&ensp; MiniGame &ensp;></span>
              <span>Logs</span>
            </div>
          </div>
          <div
            class="log__content"
            style="background-color: #000; height: 50px; padding: 0 10px"
          >
            <p style="color: #fff; line-height: 50px">
              [2022-07-23 00:05:01] local.EMERGENCY: Thực hiện refund
            </p>
          </div>
        </div>
        <!-- Close Content -->
      </div>
    </div>
    <script src="../assets/scripts/collapse.js"></script>
    <script src="../assets/scripts/navbar.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
