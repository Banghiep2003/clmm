<?php session_start(); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/head.php'); ?>
<?php
// date_default_timezone_set('UTC');
date_default_timezone_set('Asia/Ho_Chi_Minh');
// echo date('d/m/Y H:i:s');
// mktime($hour, $minute, $second, $month, $day , $year);
// $deviant = mktime((0 - date('h')), date('i'), date('s'), date('m'), date('d'), date('Y'));

$deviant_today = strtotime(date('Y-m-d').' 00:00:00');
$deviant_today1t = strtotime(date('Y-m-d').' 00:00:00') - 86400;
// $deviant = (time() % 86400);


// echo (date('Y-m-d H:i:s', $deviant)); die;


$action = $_GET['action'];
if (isset($action) && $action !== 'ALL'){
//   $today = $soicoder->fetch_assoc("SELECT SUM(`amount_play`),SUM(`result_number`) FROM `lich_su_choi` WHERE (time_tran = '".date('d/n/Y')."') AND (game ='".$action."') AND (status <> 'wrong')" , 1);
    // hôm nay
    $nhan_today = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE (time >= '".$deviant_today."') AND (game = '".$action."') AND (status <> 'wrong')", 1);
    $tru_today = $soicoder->fetch_assoc("SELECT SUM(`result_number`) FROM `lich_su_choi` WHERE (result_number >= 0) AND (time >= '".$deviant_today."') AND (game = '".$action."') AND (status <> 'wrong')", 1);
    // ngày hôm qua
    $nhan_today1t = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE (time >= '".$deviant_today1t."') AND (time <= '".$deviant_today."') AND (game = '".$action."') AND (status <> 'wrong')" , 1);
    $tru_today1t = $soicoder->fetch_assoc("SELECT SUM(`result_number`) FROM `lich_su_choi` WHERE (result_number >= 0) AND (time >= '".$deviant_today1t."') AND (time <= '".$deviant_today."') AND (game = '".$action."') AND (status <> 'wrong')" , 1);
  
    // $today1t = $soicoder->fetch_assoc("SELECT SUM(`amount_play`),SUM(`result_number`) FROM `lich_su_choi` WHERE (time_tran = '".date('d/m/Y', time() - 86400)."') AND (game='".$action."') AND (status <> 'wrong')" , 1);
    $month = $soicoder->fetch_assoc("SELECT SUM(`amount_play`),SUM(`result_number`) FROM `lich_su_choi` WHERE (time >= '".(time() - 2600640)."') AND (game ='".$action."') AND (status <> 'wrong')" , 1);
} else{
    // hôm nay
    $nhan_today = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE (time >= '".$deviant_today."') AND (game <> 'NULL') AND (status <> 'wrong')", 1);
    $tru_today = $soicoder->fetch_assoc("SELECT SUM(`result_number`) FROM `lich_su_choi` WHERE (result_number >= 0) AND (time >= '".$deviant_today."') AND (game <> 'NULL') AND (status <> 'wrong')", 1);
    // ngày hôm qua
    $nhan_today1t = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE (time >= '".$deviant_today1t."') AND (time <= '".$deviant_today."') AND (game <> 'NULL') AND (status <> 'wrong')" , 1);
    $tru_today1t = $soicoder->fetch_assoc("SELECT SUM(`result_number`) FROM `lich_su_choi` WHERE (result_number >= 0) AND (time >= '".$deviant_today1t."') AND (time <= '".$deviant_today."') AND (game <> 'NULL') AND (status <> 'wrong')" , 1);
    // tháng này
    $month = $soicoder->fetch_assoc("SELECT SUM(`amount_play`),SUM(`result_number`) FROM `lich_su_choi` WHERE (time >= '".(time() - 2600640)."') AND (game <> 'NULL') AND (status <> 'wrong')" , 1);
}

$list = $soicoder->fetch_assoc("SELECT DISTINCT `phone` FROM `lich_su_choi` WHERE `time_tran` >= '".date('d/m/Y')."' " , 0);
?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/nav.php'); ?>
<!-- Content -->
<div class="content">
    <div class="content__inner">
        <div class="content__inner__heading">
            <p>Thống Kê</p>
            <span> >&ensp; MiniGame&ensp;></span>
            <span>Thống Kê</span>
        </div>
        <div class="report__filter">
            <button class="btn btn-success">
              <a style="text-decoration: none; color:#333;" href="?action=CL">Chẵn lẻ</a>
            </button>
            <button class="btn btn-success">
              <a style="text-decoration: none; color:#333;" href="?action=CL2">Chẵn lẻ 2</a>
            </button>
            <button class="btn" style="background: rgb(252, 66, 97)">
              <a style="text-decoration: none; color:#333;" href="?action=TX">Tài xỉu</a>
            </button>
            <button class="btn" style="background: rgb(252, 66, 97)">
              <a style="text-decoration: none; color:#333;" href="?action=TX2">Tài xỉu 2</a>
            </button>
            <button class="btn" style="background: rgb(0, 209, 192)">
                <a style="text-decoration: none; color:#333;" href="?action=G3">Gấp 3</a>
            </button>
            <button class="btn" style="background: rgb(0, 209, 192)">
                <a style="text-decoration: none; color:#333;" href="?action=T3S">Tổng 3 số</a>
            </button>
            <button class="btn" style="background: rgb(226, 180, 40)">
                <a style="text-decoration: none; color:#333;" href="?action=1P3">1 phần 3</a>
            </button>
            <button class="btn" style="background: rgb(226, 180, 40)">
                <a style="text-decoration: none; color:#333;" href="?action=H2S">Hiệu 2 Số</a>
            </button>
            <button class="btn" style="background: rgb(0, 209, 192)">
                <a style="text-decoration: none; color:#333;" href="?action=LO">Lô</a>
            </button>
            <button class="btn" style="background: rgb(51, 119, 255)">
                <a style="text-decoration: none; color:#333;" href="?action=XSMB">XSMB</a>
            </button>
            <button class="btn" style="background: rgb(51, 119, 255)">
                <a style="text-decoration: none; color:#333;" href="?action=XIEN">Xiên</a>
            </button>
            <!-- <button class="btn" style="background: rgb(133, 61, 237)">
                Minigame
            </button> -->
            <button class="btn" style="background: rgb(252, 66, 90)">
                <a style="text-decoration: none; color:#333;" href="?action=ALL">Tất cả</a>
            </button>
        </div>
        <div class="content__report">
            <div class="content__card__body" style="padding: 30px">
                <h5><?=date('d/n/Y');?></h5>
                <h6>Tổng Nhận: <?=format_cash($nhan_today['SUM(`amount_play`)']);?>đ</h6>
                <h6>Tổng Trừ: <?=format_cash($tru_today['SUM(`result_number`)']);?>đ</h6>
                <h6>Danh Thu: <?=format_cash($nhan_today['SUM(`amount_play`)'] - $tru_today['SUM(`result_number`)']);?>đ</h6>
            </div>
        </div>

        <div class="content__report">
            <div class="content__card__body" style="padding: 30px">
                <h5><?=date('d/m/Y', time() - 86400);?></h5>
                <h6>Tổng Nhận: <?=format_cash($nhan_today1t['SUM(`amount_play`)']);?>đ</h6>
                <h6>Tổng Trừ: <?=format_cash($tru_today1t['SUM(`result_number`)']);?>đ</h6>
                <h6>Danh Thu: <?=format_cash($nhan_today1t['SUM(`amount_play`)'] - $tru_today1t['SUM(`result_number`)']);?>đ</h6>
            </div>
        </div>

        <div class="content__report">
            <div class="content__card__body" style="padding: 30px">
                <h5>Tháng Hiện Tại</h5>
                <h6>Tổng Nhận: <?=format_cash($month['SUM(`amount_play`)']);?>đ</h6>
                <h6>Tổng Trừ: <?=format_cash($month['SUM(`result_number`)']);?>đ</h6>
                <h6>Danh Thu: <?=format_cash($month['SUM(`amount_play`)'] - $month['SUM(`result_number`)']);?>đ</h6>
            </div>
        </div>
        <!-- COntent -->
    </div>
    
    
    
    <div class="content__ant content__card__border">
              <div class="content__card__body">
                  <h6>Danh Sách Thống Kê Theo Ngày</h6>
                <div class="content__ant__card">
                  <div class="content__ant__card__filter">
                    <form class="form">
                      <div class="form__control">
                        <p>Show</p>
                        <select class="form__select">
                          <option>1</option>
                          <option>2</option>
                          <option>3</option>
                          <option>4</option>
                        </select>
                        <p>entries</p>
                      </div>
                      
                    </form>
                  </div>
                  <div class="content__ant__card__table table-responsive">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th style="text-align: center">ID</th>
                          <th style="text-align: center">Số điện thoại</th>
                          <th style="text-align: center">Tên người chơi</th>
                          <th style="text-align: center">Số tiền Chơi</th>
                          <th style="text-align: center">Số Tiền Thắng (đã trả thưởng)</th>
                          <th style="text-align: center">Doanh Thu (web thu về)</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $i = 1;
                        foreach ($list as $data) {
                          $phone = $data['phone'];
                          $month = $soicoder->fetch_assoc("SELECT SUM(`amount_play`),SUM(`result_number`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone` =  '".$phone."' ORDER BY amount_play desc" , 1);
                          $data_phone_play = $soicoder->fetch_assoc("SELECT `partnerName` FROM `lich_su_choi` WHERE `phone` =  '".$phone."' LIMIT 1" , 1);
                          ?>
                        <tr>
                          <td style="text-align: center"><?=$i++;?></td>
                          <td style="text-align: center"><?=$phone;?></td>
                          <td style="text-align: center"><?=$data_phone_play['partnerName'];?></td>
                          <td style="text-align: center"><?=format_cash($month['SUM(`amount_play`)']);?>đ</td>
                          <td style="text-align: center"><?=format_cash($month['SUM(`result_number`)']);?>đ</td>
                          <td style="text-align: center"><?=format_cash($month['SUM(`amount_play`)'] - $month['SUM(`result_number`)']);?>đ</td>
                        </tr>
                      </tbody>
                      <?php } ?>
                    </table>
                  </div>
                  <div class="paginator">
                    <ul class="pagination">
                      <li class="page-item disabled">
                        <a class="page-link" href="#">Previous</a>
                      </li>
                      <li class="page-item">
                        <a class="page-link" href="#">1</a>
                      </li>

                      <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            
            
            
</div>
<!-- Close Content -->
</div>
</div>
<script src="../assets/scripts/collapse.js"></script>
<script src="../assets/scripts/navbar.js"></script>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>