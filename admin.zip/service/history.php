<?php session_start(); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/head.php'); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/nav.php'); ?>
<?php
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $soicoder->remove("lich_su_choi"," 1 ");
    echo '<script type="text/javascript">alert("Xóa Thành Công");setTimeout(function(){ location.href = "/service/history.php" },500);</script>';
    die;
}
?>
        <!-- Content -->
        <div class="content">
          <div class="content__inner">
            <div class="content__inner__heading">
              <p>Lịch sử</p>
              <span> >&ensp; MiniGame &ensp;></span>
              <span>Lịch sử</span>
            </div>
            <div class="content__ant content__card__border">
              <div class="content__card__body">
                <div class="content__ant__card">
                  <div class="content__ant__card__filter">
                    <form class="form">
                      <div class="form__control">
                        <p>Show</p>
                        <select class="form__select">
                          <option>1</option>
                          <option>2</option>
                          <option>3</option>
                          <option>4</option>
                        </select>
                        <p>entries</p>
                      </div>
                      <div class="form__control">
                        <label for="search">Search</label>
                        <input
                          type="text"
                          class="form__control__input"
                          id="search"
                        />
                      </div>
                    </form>
                  </div>
                  <div class="content__ant__card__table table-responsive">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th style="text-align: center">ID</th>
                          <th style="text-align: center">Mã giao dịch</th>
                          <th style="text-align: center">Số Điện Thoại Chuyển</th>
                          <th style="text-align: center">Số tiền</th>
                          <th style="text-align: center">Comment</th>
                          <th style="text-align: center">Số điện thoại Nhận</th>
                          <th style="text-align: center">WIN</th>
                          <th style="text-align: center">Status</th>
                          <th style="text-align: center">Thời gian</th>
                        </tr>
                    </thead>
                        <?php
                            $data = $soicoder->fetch_assoc("SELECT * FROM `default` WHERE `id` = 1", 1)['data'];
                            $config_all = json_decode($data, true);

                            $list = $soicoder->fetch_assoc("SELECT `id`, `tranId`,`phone`,`amount_play`,`comment`,`phone_nhan`,`game`,`amount_game`,`result_text`,`status`,`time` FROM `lich_su_choi` ORDER BY time desc LIMIT 1000", 0);
                            if (count($list) ==  0) {
                                echo '<tr><center>Không Tìm Thấy Dữ Liệu</center></tr>';
                            } else {
                                echo '<tbody>';
                            foreach ($list as $data) { ?>
                                <tr>
                                  <td style="text-align: center"><b><?=$data['id'];?></b></td>
                                  <td style="text-align: center"><?=$data['tranId'];?></td>
                                  <td style="text-align: center"><?=$data['phone'];?></td>
                                  <td style="text-align: center"><?=format_cash($data['amount_play']);?>đ</td>
                                  <td style="text-align: center"><?=$data['comment'];?></td>
                                  <td style="text-align: center"><?=$data['phone_nhan'];?></td>
                                  <td style="text-align: center">x<?=$data['amount_game'];?></td>
                                  <td style="text-align: center"><?php if ($data['status'] == 'done') { echo '<span class="badge light badge-success">Đã Trả Thưởng</span>'; } else if ($data['status'] == 'wrong') { echo '<span class="badge light badge-warning">Sai Min Max</span>'; } else if ($data['status'] == 'wait_auto') { echo '<span class="badge light badge-dark">Đợi Thanh Toán Vào Hôm Sau</span>'; } else if ($data['game'] == 'NULL') { echo '<span class="badge light badge-info">Sai Nội Dung</span>'; } else if ($data['result_text'] !== 'success') { echo '<span class="badge light badge-danger">Lỗi</span>';} else { echo '<span class="badge light badge-danger">Thua</span>'; } ?></td>
                                  <td style="text-align: center"><?=date('H:i:s d/m/Y', $data['time']);?></td>
                                </tr>
                            </tbody>
                      <?php }} ?>
                    </table>
                  </div>
                  <div class="paginator">
                    <ul class="pagination">
                      <li class="page-item disabled">
                        <a class="page-link" href="#">Previous</a>
                      </li>
                      <li class="page-item">
                        <a class="page-link" href="#">1</a>
                      </li>

                      <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Close Content -->
      </div>
    </div>
    <script src="../assets/scripts/collapse.js"></script>
    <script src="../assets/scripts/navbar.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
