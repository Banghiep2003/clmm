<?php session_start(); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/head.php'); ?>
<?php require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/Models/nav.php'); ?>
<?php
$action = $_GET['action'];
if (isset($action) && $action !== ''){
  $list = array(
    0 => array('phone' => $action)
  );
} else{
  $list = $soicoder->fetch_assoc("SELECT DISTINCT `phone` FROM `lich_su_choi` " , 0);
}
?>
        <!-- Content -->
        <div class="content">
          <div class="content__inner">
            <div class="content__inner__heading">
              <p>Thống kê người dùng</p>
              <span> >&ensp; MiniGame &ensp;></span>
              <span>Thống kê người dùng</span>
            </div>
            <div class="content__ant content__card__border">
              <div class="content__card__body">
                <div class="content__ant__card">
                  <div class="content__ant__card__filter">
                    <form class="form">
                      <div class="form__control">
                        <p>Show</p>
                        <select class="form__select">
                          <option>1</option>
                          <option>2</option>
                          <option>3</option>
                          <option>4</option>
                        </select>
                        <p>entries</p>
                      </div>
                      <div class="form__control">
                        <!-- Search -->
                        <div class="report__user__form">
                          <div class="row">
                            <div class="form__control__item">
                              <input id="phone" placeholder="Nhập số điện thoại" />
                            </div>
                            <div class="form__control">
                              <button><a style="text-decoration: none; color:#333;" href="javascript:;" onclick="checksdt(this)" id="checksdt">Kiểm tra</a></button>
                            </div>
                            <script>
                                function checksdt() {
                                  $("#checksdt").html('<i class="fas fa-spinner fa-spin"></i>');
                                  var phone = $("#phone").val();
                                  window.location='/service/report-user.php?action=' + phone;
                                }
                            </script>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                  <div class="content__ant__card__table table-responsive">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th style="text-align: center">ID</th>
                          <th style="text-align: center">Số điện thoại</th>
                          <th style="text-align: center">Số tiền Chơi</th>
                          <th style="text-align: center">Số Tiền Nhận</th>
                          <th style="text-align: center">Doanh Thu</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $i = 1;
                        foreach ($list as $data) {
                          $phone = $data['phone'];
                          $month = $soicoder->fetch_assoc("SELECT SUM(`amount_play`),SUM(`result_number`) FROM `lich_su_choi` WHERE `amount_play` >= 0 AND `result_number` >= 0 AND `time` >= '".(time() - 2600640)."' AND `phone` =  '".$phone."' ORDER BY amount_play desc" , 1);
                          
                          ?>
                        <tr>
                          <td style="text-align: center"><?=$i++;?></td>
                          <td style="text-align: center"><?=$phone;?></td>
                          <td style="text-align: center"><?=format_cash($month['SUM(`amount_play`)']);?>đ</td>
                          <td style="text-align: center"><?=format_cash($month['SUM(`result_number`)']);?>đ</td>
                          <td style="text-align: center"><?=format_cash($month['SUM(`amount_play`)'] - $month['SUM(`result_number`)']);?>đ</td>
                        </tr>
                      </tbody>
                      <?php } ?>
                    </table>
                  </div>
                  <div class="paginator">
                    <ul class="pagination">
                      <li class="page-item disabled">
                        <a class="page-link" href="#">Previous</a>
                      </li>
                      <li class="page-item">
                        <a class="page-link" href="#">1</a>
                      </li>

                      <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Close Content -->
      </div>
    </div>
    <script src="../assets/scripts/collapse.js"></script>
    <script src="../assets/scripts/navbar.js"></script>

    <!-- <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
