
<html class="no-js" lang="vi">

<head>
    <title><?= ucfirst($_SERVER['SERVER_NAME']); ?> Hệ thống chẵn lẻ MoMo tự động Giao Dịch 24/7 | Trang chủ</title>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
    <meta content="<?= ucfirst($_SERVER['SERVER_NAME']); ?> Hệ thống chẵn lẻ MoMo tự động Giao Dịch 24/7 | Trang chủ" name="title">
    <meta content="<?= $setting['description']; ?>" name="description">
    <meta content="<?= $setting['keywoed']; ?>" name="keywords">
    <meta content="/" property="og:url">
    <meta content="article" property="og:type">
    <meta content="<?= ucfirst($_SERVER['SERVER_NAME']); ?> Hệ thống chẵn lẻ MoMo tự động Giao Dịch 24/7 | Trang chủ" property="og:title">
    <meta content="<?= $setting['description']; ?>" property="og:description">
    <meta content="<?= $setting['logo']; ?>" property="og:image">
    <link href="https://i.imgur.com/y4TM1vy.jpg" rel="apple-touch-icon">
    <link href="https://i.imgur.com/y4TM1vy.jpg" rel="shortcut icon" type="image/x-icon">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.css" rel="stylesheet">
    <link href="css2/bootstrapv.min.css" rel="stylesheet">
    <link href="css2/bootstrap-social.css" rel="stylesheet">
    <link href="css2/style3.css?ver=28" rel="stylesheet">
    <link href="css2/custom.1.css?ver=28" rel="stylesheet">
    <link href="css2/wheel.css?ver=<?=time();?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://sieumomo.com/dist/simple-notify.min.css">
    <style>
        .aa:hover,
        .aa:focus {
            background: #ad4105;
            border-radius: 5px
        }

        .coffer-box {
            display: block;
            position: fixed;
            bottom: 90px;
            right: 15px;
            width: 15%;
            z-index: 1000;
            cursor: pointer;
            /*background: #ad410569;*/
            border-radius: 10px;
            text-align: center;
            padding: 15px;
        }

        @media (max-width: 767px) {
            .coffer-box {
                background: unset;
                width: 50%;
                bottom: 20px;
            }
        }

        .mb-0 {
            margin-bottom: 0;
        }

        .mt-100 {
            margin-top: 100px;
        }

        .mainbar {
            padding: 0px !important;
        }

        .panel-heading {
            background-color: #2fa316 !important;
            border-color: #2fa316 !important;
        }
        .panel-headings {
            background-color: #f2dede !important;
            border-color: #f2dede !important;
        }

        .panel-primary {
            /*background-color: #000000 !important;*/
            border-color: #17a2b8 !important;
        }

        .navbar {
            background-color: #1d8300  !important;

        }

        .navbar .navbar-collapse {
            background-color: #000000 !important;
        }

        .table .bg-primary {
            background-color: #2fa316 !important;
        }

        .footer {
            background-color: #2fa316 !important;
        }

        .mainbar {
            background-color: #2fa316 !important;
        }
        .mainbar {
         background-image: url(https://vanmay.net/frontend/images/bg-head.png); 
         background-size: cover; 
         background-repeat: no-repeat; 
    }
    </style>
    <style>
        .swal2-popup.swal2-toast {
            box-sizing: border-box;
            grid-column: 1/4 !important;
            grid-row: 1/4 !important;
            grid-template-columns: 1fr 99fr 1fr;
            padding: 1em;
            overflow-y: hidden;
            background: #fff;
            box-shadow: 0 0 1px hsla(0deg, 0%, 0%, .075), 0 1px 2px hsla(0deg, 0%, 0%, .075), 1px 2px 4px hsla(0deg, 0%, 0%, .075), 1px 3px 8px hsla(0deg, 0%, 0%, .075), 2px 4px 16px hsla(0deg, 0%, 0%, .075);
            pointer-events: all
        }

        .swal2-popup.swal2-toast>* {
            grid-column: 2
        }

        .swal2-popup.swal2-toast .swal2-title {
            margin: .5em 1em;
            padding: 0;
            font-size: 1em;
            text-align: initial
        }

        .swal2-popup.swal2-toast .swal2-loading {
            justify-content: center
        }

        .swal2-popup.swal2-toast .swal2-input {
            height: 2em;
            margin: .5em;
            font-size: 1em
        }

        .swal2-popup.swal2-toast .swal2-validation-message {
            font-size: 1em
        }

        .swal2-popup.swal2-toast .swal2-footer {
            margin: .5em 0 0;
            padding: .5em 0 0;
            font-size: .8em
        }

        .swal2-popup.swal2-toast .swal2-close {
            grid-column: 3/3;
            grid-row: 1/99;
            align-self: center;
            width: .8em;
            height: .8em;
            margin: 0;
            font-size: 2em
        }

        .swal2-popup.swal2-toast .swal2-html-container {
            margin: .5em 1em;
            padding: 0;
            font-size: 1em;
            text-align: initial
        }

        .swal2-popup.swal2-toast .swal2-html-container:empty {
            padding: 0
        }

        .swal2-popup.swal2-toast .swal2-loader {
            grid-column: 1;
            grid-row: 1/99;
            align-self: center;
            width: 2em;
            height: 2em;
            margin: .25em
        }

        .swal2-popup.swal2-toast .swal2-icon {
            grid-column: 1;
            grid-row: 1/99;
            align-self: center;
            width: 2em;
            min-width: 2em;
            height: 2em;
            margin: 0 .5em 0 0
        }

        .swal2-popup.swal2-toast .swal2-icon .swal2-icon-content {
            display: flex;
            align-items: center;
            font-size: 1.8em;
            font-weight: 700
        }

        .swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring {
            width: 2em;
            height: 2em
        }

        .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line] {
            top: .875em;
            width: 1.375em
        }

        .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left] {
            left: .3125em
        }

        .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right] {
            right: .3125em
        }

        .swal2-popup.swal2-toast .swal2-actions {
            justify-content: flex-start;
            height: auto;
            margin: 0;
            margin-top: .5em;
            padding: 0 .5em
        }

        .swal2-popup.swal2-toast .swal2-styled {
            margin: .25em .5em;
            padding: .4em .6em;
            font-size: 1em
        }

        .swal2-popup.swal2-toast .swal2-success {
            border-color: #a5dc86
        }

        .swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line] {
            position: absolute;
            width: 1.6em;
            height: 3em;
            transform: rotate(45deg);
            border-radius: 50%
        }

        .swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left] {
            top: -.8em;
            left: -.5em;
            transform: rotate(-45deg);
            transform-origin: 2em 2em;
            border-radius: 4em 0 0 4em
        }

        .swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right] {
            top: -.25em;
            left: .9375em;
            transform-origin: 0 1.5em;
            border-radius: 0 4em 4em 0
        }

        .swal2-popup.swal2-toast .swal2-success .swal2-success-ring {
            width: 2em;
            height: 2em
        }

        .swal2-popup.swal2-toast .swal2-success .swal2-success-fix {
            top: 0;
            left: .4375em;
            width: .4375em;
            height: 2.6875em
        }

        .swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line] {
            height: .3125em
        }

        .swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=tip] {
            top: 1.125em;
            left: .1875em;
            width: .75em
        }

        .swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=long] {
            top: .9375em;
            right: .1875em;
            width: 1.375em
        }

        .swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip {
            -webkit-animation: swal2-toast-animate-success-line-tip .75s;
            animation: swal2-toast-animate-success-line-tip .75s
        }

        .swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long {
            -webkit-animation: swal2-toast-animate-success-line-long .75s;
            animation: swal2-toast-animate-success-line-long .75s
        }

        .swal2-popup.swal2-toast.swal2-show {
            -webkit-animation: swal2-toast-show .5s;
            animation: swal2-toast-show .5s
        }

        .swal2-popup.swal2-toast.swal2-hide {
            -webkit-animation: swal2-toast-hide .1s forwards;
            animation: swal2-toast-hide .1s forwards
        }

        .swal2-container {
            display: grid;
            position: fixed;
            z-index: 1060;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            box-sizing: border-box;
            grid-template-areas: "top-start     top            top-end""center-start  center         center-end""bottom-start  bottom-center  bottom-end";
            grid-template-rows: minmax(-webkit-min-content, auto) minmax(-webkit-min-content, auto) minmax(-webkit-min-content, auto);
            grid-template-rows: minmax(min-content, auto) minmax(min-content, auto) minmax(min-content, auto);
            height: 100%;
            padding: .625em;
            overflow-x: hidden;
            transition: background-color .1s;
            -webkit-overflow-scrolling: touch
        }

        .swal2-container.swal2-backdrop-show,
        .swal2-container.swal2-noanimation {
            background: rgba(0, 0, 0, .4)
        }

        .swal2-container.swal2-backdrop-hide {
            background: 0 0 !important
        }

        .swal2-container.swal2-bottom-start,
        .swal2-container.swal2-center-start,
        .swal2-container.swal2-top-start {
            grid-template-columns: minmax(0, 1fr) auto auto
        }

        .swal2-container.swal2-bottom,
        .swal2-container.swal2-center,
        .swal2-container.swal2-top {
            grid-template-columns: auto minmax(0, 1fr) auto
        }

        .swal2-container.swal2-bottom-end,
        .swal2-container.swal2-center-end,
        .swal2-container.swal2-top-end {
            grid-template-columns: auto auto minmax(0, 1fr)
        }

        .swal2-container.swal2-top-start>.swal2-popup {
            align-self: start
        }

        .swal2-container.swal2-top>.swal2-popup {
            grid-column: 2;
            align-self: start;
            justify-self: center
        }

        .swal2-container.swal2-top-end>.swal2-popup,
        .swal2-container.swal2-top-right>.swal2-popup {
            grid-column: 3;
            align-self: start;
            justify-self: end
        }

        .swal2-container.swal2-center-left>.swal2-popup,
        .swal2-container.swal2-center-start>.swal2-popup {
            grid-row: 2;
            align-self: center
        }

        .swal2-container.swal2-center>.swal2-popup {
            grid-column: 2;
            grid-row: 2;
            align-self: center;
            justify-self: center
        }

        .swal2-container.swal2-center-end>.swal2-popup,
        .swal2-container.swal2-center-right>.swal2-popup {
            grid-column: 3;
            grid-row: 2;
            align-self: center;
            justify-self: end
        }

        .swal2-container.swal2-bottom-left>.swal2-popup,
        .swal2-container.swal2-bottom-start>.swal2-popup {
            grid-column: 1;
            grid-row: 3;
            align-self: end
        }

        .swal2-container.swal2-bottom>.swal2-popup {
            grid-column: 2;
            grid-row: 3;
            justify-self: center;
            align-self: end
        }

        .swal2-container.swal2-bottom-end>.swal2-popup,
        .swal2-container.swal2-bottom-right>.swal2-popup {
            grid-column: 3;
            grid-row: 3;
            align-self: end;
            justify-self: end
        }

        .swal2-container.swal2-grow-fullscreen>.swal2-popup,
        .swal2-container.swal2-grow-row>.swal2-popup {
            grid-column: 1/4;
            width: 100%
        }

        .swal2-container.swal2-grow-column>.swal2-popup,
        .swal2-container.swal2-grow-fullscreen>.swal2-popup {
            grid-row: 1/4;
            align-self: stretch
        }

        .swal2-container.swal2-no-transition {
            transition: none !important
        }

        .swal2-popup {
            display: none;
            position: relative;
            box-sizing: border-box;
            grid-template-columns: minmax(0, 100%);
            width: 32em;
            max-width: 100%;
            padding: 0 0 1.25em;
            border: none;
            border-radius: 5px;
            background: #fff;
            color: #545454;
            font-family: inherit;
            font-size: 1rem
        }

        .swal2-popup:focus {
            outline: 0
        }

        .swal2-popup.swal2-loading {
            overflow-y: hidden
        }

        .swal2-title {
            position: relative;
            max-width: 100%;
            margin: 0;
            padding: .8em 1em 0;
            color: inherit;
            font-size: 1.875em;
            font-weight: 600;
            text-align: center;
            text-transform: none;
            word-wrap: break-word
        }

        .swal2-actions {
            display: flex;
            z-index: 1;
            box-sizing: border-box;
            flex-wrap: wrap;
            align-items: center;
            justify-content: center;
            width: auto;
            margin: 1.25em auto 0;
            padding: 0
        }

        .swal2-actions:not(.swal2-loading) .swal2-styled[disabled] {
            opacity: .4
        }

        .swal2-actions:not(.swal2-loading) .swal2-styled:hover {
            background-image: linear-gradient(rgba(0, 0, 0, .1), rgba(0, 0, 0, .1))
        }

        .swal2-actions:not(.swal2-loading) .swal2-styled:active {
            background-image: linear-gradient(rgba(0, 0, 0, .2), rgba(0, 0, 0, .2))
        }

        .swal2-loader {
            display: none;
            align-items: center;
            justify-content: center;
            width: 2.2em;
            height: 2.2em;
            margin: 0 1.875em;
            -webkit-animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
            animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
            border-width: .25em;
            border-style: solid;
            border-radius: 100%;
            border-color: #2778c4 transparent #2778c4 transparent
        }

        .swal2-styled {
            margin: .3125em;
            padding: .625em 1.1em;
            transition: box-shadow .1s;
            box-shadow: 0 0 0 3px transparent;
            font-weight: 500
        }

        .swal2-styled:not([disabled]) {
            cursor: pointer
        }

        .swal2-styled.swal2-confirm {
            border: 0;
            border-radius: .25em;
            background: initial;
            background-color: #7066e0;
            color: #fff;
            font-size: 1em
        }

        .swal2-styled.swal2-confirm:focus {
            box-shadow: 0 0 0 3px rgba(112, 102, 224, .5)
        }

        .swal2-styled.swal2-deny {
            border: 0;
            border-radius: .25em;
            background: initial;
            background-color: #dc3741;
            color: #fff;
            font-size: 1em
        }

        .swal2-styled.swal2-deny:focus {
            box-shadow: 0 0 0 3px rgba(220, 55, 65, .5)
        }

        .swal2-styled.swal2-cancel {
            border: 0;
            border-radius: .25em;
            background: initial;
            background-color: #6e7881;
            color: #fff;
            font-size: 1em
        }

        .swal2-styled.swal2-cancel:focus {
            box-shadow: 0 0 0 3px rgba(110, 120, 129, .5)
        }

        .swal2-styled.swal2-default-outline:focus {
            box-shadow: 0 0 0 3px rgba(100, 150, 200, .5)
        }

        .swal2-styled:focus {
            outline: 0
        }

        .swal2-styled::-moz-focus-inner {
            border: 0
        }

        .swal2-footer {
            justify-content: center;
            margin: 1em 0 0;
            padding: 1em 1em 0;
            border-top: 1px solid #eee;
            color: inherit;
            font-size: 1em
        }

        .swal2-timer-progress-bar-container {
            position: absolute;
            right: 0;
            bottom: 0;
            left: 0;
            grid-column: auto !important;
            overflow: hidden;
            border-bottom-right-radius: 5px;
            border-bottom-left-radius: 5px
        }

        .swal2-timer-progress-bar {
            width: 100%;
            height: .25em;
            background: rgba(0, 0, 0, .2)
        }

        .swal2-image {
            max-width: 100%;
            margin: 2em auto 1em
        }

        .swal2-close {
            z-index: 2;
            align-items: center;
            justify-content: center;
            width: 1.2em;
            height: 1.2em;
            margin-top: 0;
            margin-right: 0;
            margin-bottom: -1.2em;
            padding: 0;
            overflow: hidden;
            transition: color .1s, box-shadow .1s;
            border: none;
            border-radius: 5px;
            background: 0 0;
            color: #ccc;
            font-family: serif;
            font-family: monospace;
            font-size: 2.5em;
            cursor: pointer;
            justify-self: end
        }

        .swal2-close:hover {
            transform: none;
            background: 0 0;
            color: #f27474
        }

        .swal2-close:focus {
            outline: 0;
            box-shadow: inset 0 0 0 3px rgba(100, 150, 200, .5)
        }

        .swal2-close::-moz-focus-inner {
            border: 0
        }

        .swal2-html-container {
            z-index: 1;
            justify-content: center;
            margin: 1em 1.6em .3em;
            padding: 0;
            overflow: auto;
            color: inherit;
            font-size: 1.125em;
            font-weight: 400;
            line-height: normal;
            text-align: center;
            word-wrap: break-word;
            word-break: break-word
        }

        .swal2-checkbox,
        .swal2-file,
        .swal2-input,
        .swal2-radio,
        .swal2-select,
        .swal2-textarea {
            margin: 1em 2em 3px
        }

        .swal2-file,
        .swal2-input,
        .swal2-textarea {
            box-sizing: border-box;
            width: auto;
            transition: border-color .1s, box-shadow .1s;
            border: 1px solid #d9d9d9;
            border-radius: .1875em;
            background: 0 0;
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .06), 0 0 0 3px transparent;
            color: inherit;
            font-size: 1.125em
        }

        .swal2-file.swal2-inputerror,
        .swal2-input.swal2-inputerror,
        .swal2-textarea.swal2-inputerror {
            border-color: #f27474 !important;
            box-shadow: 0 0 2px #f27474 !important
        }

        .swal2-file:focus,
        .swal2-input:focus,
        .swal2-textarea:focus {
            border: 1px solid #b4dbed;
            outline: 0;
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .06), 0 0 0 3px rgba(100, 150, 200, .5)
        }

        .swal2-file::-moz-placeholder,
        .swal2-input::-moz-placeholder,
        .swal2-textarea::-moz-placeholder {
            color: #ccc
        }

        .swal2-file::placeholder,
        .swal2-input::placeholder,
        .swal2-textarea::placeholder {
            color: #ccc
        }

        .swal2-range {
            margin: 1em 2em 3px;
            background: #fff
        }

        .swal2-range input {
            width: 80%
        }

        .swal2-range output {
            width: 20%;
            color: inherit;
            font-weight: 600;
            text-align: center
        }

        .swal2-range input,
        .swal2-range output {
            height: 2.625em;
            padding: 0;
            font-size: 1.125em;
            line-height: 2.625em
        }

        .swal2-input {
            height: 2.625em;
            padding: 0 .75em
        }

        .swal2-file {
            width: 75%;
            margin-right: auto;
            margin-left: auto;
            background: 0 0;
            font-size: 1.125em
        }

        .swal2-textarea {
            height: 6.75em;
            padding: .75em
        }

        .swal2-select {
            min-width: 50%;
            max-width: 100%;
            padding: .375em .625em;
            background: 0 0;
            color: inherit;
            font-size: 1.125em
        }

        .swal2-checkbox,
        .swal2-radio {
            align-items: center;
            justify-content: center;
            background: #fff;
            color: inherit
        }

        .swal2-checkbox label,
        .swal2-radio label {
            margin: 0 .6em;
            font-size: 1.125em
        }

        .swal2-checkbox input,
        .swal2-radio input {
            flex-shrink: 0;
            margin: 0 .4em
        }

        .swal2-input-label {
            display: flex;
            justify-content: center;
            margin: 1em auto 0
        }

        .swal2-validation-message {
            align-items: center;
            justify-content: center;
            margin: 1em 0 0;
            padding: .625em;
            overflow: hidden;
            background: #f0f0f0;
            color: #666;
            font-size: 1em;
            font-weight: 300
        }

        .swal2-validation-message::before {
            content: "!";
            display: inline-block;
            width: 1.5em;
            min-width: 1.5em;
            height: 1.5em;
            margin: 0 .625em;
            border-radius: 50%;
            background-color: #f27474;
            color: #fff;
            font-weight: 600;
            line-height: 1.5em;
            text-align: center
        }

        .swal2-icon {
            position: relative;
            box-sizing: content-box;
            justify-content: center;
            width: 5em;
            height: 5em;
            margin: 2.5em auto .6em;
            border: .25em solid transparent;
            border-radius: 50%;
            border-color: #000;
            font-family: inherit;
            line-height: 5em;
            cursor: default;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none
        }

        .swal2-icon .swal2-icon-content {
            display: flex;
            align-items: center;
            font-size: 3.75em
        }

        .swal2-icon.swal2-error {
            border-color: #f27474;
            color: #f27474
        }

        .swal2-icon.swal2-error .swal2-x-mark {
            position: relative;
            flex-grow: 1
        }

        .swal2-icon.swal2-error [class^=swal2-x-mark-line] {
            display: block;
            position: absolute;
            top: 2.3125em;
            width: 2.9375em;
            height: .3125em;
            border-radius: .125em;
            background-color: #f27474
        }

        .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left] {
            left: 1.0625em;
            transform: rotate(45deg)
        }

        .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right] {
            right: 1em;
            transform: rotate(-45deg)
        }

        .swal2-icon.swal2-error.swal2-icon-show {
            -webkit-animation: swal2-animate-error-icon .5s;
            animation: swal2-animate-error-icon .5s
        }

        .swal2-icon.swal2-error.swal2-icon-show .swal2-x-mark {
            -webkit-animation: swal2-animate-error-x-mark .5s;
            animation: swal2-animate-error-x-mark .5s
        }

        .swal2-icon.swal2-warning {
            border-color: #facea8;
            color: #f8bb86
        }

        .swal2-icon.swal2-warning.swal2-icon-show {
            -webkit-animation: swal2-animate-error-icon .5s;
            animation: swal2-animate-error-icon .5s
        }

        .swal2-icon.swal2-warning.swal2-icon-show .swal2-icon-content {
            -webkit-animation: swal2-animate-i-mark .5s;
            animation: swal2-animate-i-mark .5s
        }

        .swal2-icon.swal2-info {
            border-color: #9de0f6;
            color: #3fc3ee
        }

        .swal2-icon.swal2-info.swal2-icon-show {
            -webkit-animation: swal2-animate-error-icon .5s;
            animation: swal2-animate-error-icon .5s
        }

        .swal2-icon.swal2-info.swal2-icon-show .swal2-icon-content {
            -webkit-animation: swal2-animate-i-mark .8s;
            animation: swal2-animate-i-mark .8s
        }

        .swal2-icon.swal2-question {
            border-color: #c9dae1;
            color: #87adbd
        }

        .swal2-icon.swal2-question.swal2-icon-show {
            -webkit-animation: swal2-animate-error-icon .5s;
            animation: swal2-animate-error-icon .5s
        }

        .swal2-icon.swal2-question.swal2-icon-show .swal2-icon-content {
            -webkit-animation: swal2-animate-question-mark .8s;
            animation: swal2-animate-question-mark .8s
        }

        .swal2-icon.swal2-success {
            border-color: #a5dc86;
            color: #a5dc86
        }

        .swal2-icon.swal2-success [class^=swal2-success-circular-line] {
            position: absolute;
            width: 3.75em;
            height: 7.5em;
            transform: rotate(45deg);
            border-radius: 50%
        }

        .swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=left] {
            top: -.4375em;
            left: -2.0635em;
            transform: rotate(-45deg);
            transform-origin: 3.75em 3.75em;
            border-radius: 7.5em 0 0 7.5em
        }

        .swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=right] {
            top: -.6875em;
            left: 1.875em;
            transform: rotate(-45deg);
            transform-origin: 0 3.75em;
            border-radius: 0 7.5em 7.5em 0
        }

        .swal2-icon.swal2-success .swal2-success-ring {
            position: absolute;
            z-index: 2;
            top: -.25em;
            left: -.25em;
            box-sizing: content-box;
            width: 100%;
            height: 100%;
            border: .25em solid rgba(165, 220, 134, .3);
            border-radius: 50%
        }

        .swal2-icon.swal2-success .swal2-success-fix {
            position: absolute;
            z-index: 1;
            top: .5em;
            left: 1.625em;
            width: .4375em;
            height: 5.625em;
            transform: rotate(-45deg)
        }

        .swal2-icon.swal2-success [class^=swal2-success-line] {
            display: block;
            position: absolute;
            z-index: 2;
            height: .3125em;
            border-radius: .125em;
            background-color: #a5dc86
        }

        .swal2-icon.swal2-success [class^=swal2-success-line][class$=tip] {
            top: 2.875em;
            left: .8125em;
            width: 1.5625em;
            transform: rotate(45deg)
        }

        .swal2-icon.swal2-success [class^=swal2-success-line][class$=long] {
            top: 2.375em;
            right: .5em;
            width: 2.9375em;
            transform: rotate(-45deg)
        }

        .swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-tip {
            -webkit-animation: swal2-animate-success-line-tip .75s;
            animation: swal2-animate-success-line-tip .75s
        }

        .swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-long {
            -webkit-animation: swal2-animate-success-line-long .75s;
            animation: swal2-animate-success-line-long .75s
        }

        .swal2-icon.swal2-success.swal2-icon-show .swal2-success-circular-line-right {
            -webkit-animation: swal2-rotate-success-circular-line 4.25s ease-in;
            animation: swal2-rotate-success-circular-line 4.25s ease-in
        }

        .swal2-progress-steps {
            flex-wrap: wrap;
            align-items: center;
            max-width: 100%;
            margin: 1.25em auto;
            padding: 0;
            background: 0 0;
            font-weight: 600
        }

        .swal2-progress-steps li {
            display: inline-block;
            position: relative
        }

        .swal2-progress-steps .swal2-progress-step {
            z-index: 20;
            flex-shrink: 0;
            width: 2em;
            height: 2em;
            border-radius: 2em;
            background: #2778c4;
            color: #fff;
            line-height: 2em;
            text-align: center
        }

        .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step {
            background: #2778c4
        }

        .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step {
            background: #add8e6;
            color: #fff
        }

        .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line {
            background: #add8e6
        }

        .swal2-progress-steps .swal2-progress-step-line {
            z-index: 10;
            flex-shrink: 0;
            width: 2.5em;
            height: .4em;
            margin: 0 -1px;
            background: #2778c4
        }

        [class^=swal2] {
            -webkit-tap-highlight-color: transparent
        }

        .swal2-show {
            -webkit-animation: swal2-show .3s;
            animation: swal2-show .3s
        }

        .swal2-hide {
            -webkit-animation: swal2-hide .15s forwards;
            animation: swal2-hide .15s forwards
        }

        .swal2-noanimation {
            transition: none
        }

        .swal2-scrollbar-measure {
            position: absolute;
            top: -9999px;
            width: 50px;
            height: 50px;
            overflow: scroll
        }

        .swal2-rtl .swal2-close {
            margin-right: initial;
            margin-left: 0
        }

        .swal2-rtl .swal2-timer-progress-bar {
            right: 0;
            left: auto
        }

        .leave-russia-now-and-apply-your-skills-to-the-world {
            display: flex;
            position: fixed;
            z-index: 1939;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 25px 0 20px;
            background: #20232a;
            color: #fff;
            text-align: center
        }

        .leave-russia-now-and-apply-your-skills-to-the-world div {
            max-width: 560px;
            margin: 10px;
            line-height: 146%
        }

        .leave-russia-now-and-apply-your-skills-to-the-world iframe {
            max-width: 100%;
            max-height: 55.5555555556vmin;
            margin: 16px auto
        }

        .leave-russia-now-and-apply-your-skills-to-the-world strong {
            border-bottom: 2px dashed #fff
        }

        .leave-russia-now-and-apply-your-skills-to-the-world button {
            display: flex;
            position: fixed;
            z-index: 1940;
            top: 0;
            right: 0;
            align-items: center;
            justify-content: center;
            width: 48px;
            height: 48px;
            margin-right: 10px;
            margin-bottom: -10px;
            border: none;
            background: 0 0;
            color: #aaa;
            font-size: 48px;
            font-weight: 700;
            cursor: pointer
        }

        .leave-russia-now-and-apply-your-skills-to-the-world button:hover {
            color: #fff
        }

        @-webkit-keyframes swal2-toast-show {
            0% {
                transform: translateY(-.625em) rotateZ(2deg)
            }

            33% {
                transform: translateY(0) rotateZ(-2deg)
            }

            66% {
                transform: translateY(.3125em) rotateZ(2deg)
            }

            100% {
                transform: translateY(0) rotateZ(0)
            }
        }

        @keyframes swal2-toast-show {
            0% {
                transform: translateY(-.625em) rotateZ(2deg)
            }

            33% {
                transform: translateY(0) rotateZ(-2deg)
            }

            66% {
                transform: translateY(.3125em) rotateZ(2deg)
            }

            100% {
                transform: translateY(0) rotateZ(0)
            }
        }

        @-webkit-keyframes swal2-toast-hide {
            100% {
                transform: rotateZ(1deg);
                opacity: 0
            }
        }

        @keyframes swal2-toast-hide {
            100% {
                transform: rotateZ(1deg);
                opacity: 0
            }
        }

        @-webkit-keyframes swal2-toast-animate-success-line-tip {
            0% {
                top: .5625em;
                left: .0625em;
                width: 0
            }

            54% {
                top: .125em;
                left: .125em;
                width: 0
            }

            70% {
                top: .625em;
                left: -.25em;
                width: 1.625em
            }

            84% {
                top: 1.0625em;
                left: .75em;
                width: .5em
            }

            100% {
                top: 1.125em;
                left: .1875em;
                width: .75em
            }
        }

        @keyframes swal2-toast-animate-success-line-tip {
            0% {
                top: .5625em;
                left: .0625em;
                width: 0
            }

            54% {
                top: .125em;
                left: .125em;
                width: 0
            }

            70% {
                top: .625em;
                left: -.25em;
                width: 1.625em
            }

            84% {
                top: 1.0625em;
                left: .75em;
                width: .5em
            }

            100% {
                top: 1.125em;
                left: .1875em;
                width: .75em
            }
        }

        @-webkit-keyframes swal2-toast-animate-success-line-long {
            0% {
                top: 1.625em;
                right: 1.375em;
                width: 0
            }

            65% {
                top: 1.25em;
                right: .9375em;
                width: 0
            }

            84% {
                top: .9375em;
                right: 0;
                width: 1.125em
            }

            100% {
                top: .9375em;
                right: .1875em;
                width: 1.375em
            }
        }

        @keyframes swal2-toast-animate-success-line-long {
            0% {
                top: 1.625em;
                right: 1.375em;
                width: 0
            }

            65% {
                top: 1.25em;
                right: .9375em;
                width: 0
            }

            84% {
                top: .9375em;
                right: 0;
                width: 1.125em
            }

            100% {
                top: .9375em;
                right: .1875em;
                width: 1.375em
            }
        }

        @-webkit-keyframes swal2-show {
            0% {
                transform: scale(.7)
            }

            45% {
                transform: scale(1.05)
            }

            80% {
                transform: scale(.95)
            }

            100% {
                transform: scale(1)
            }
        }

        @keyframes swal2-show {
            0% {
                transform: scale(.7)
            }

            45% {
                transform: scale(1.05)
            }

            80% {
                transform: scale(.95)
            }

            100% {
                transform: scale(1)
            }
        }

        @-webkit-keyframes swal2-hide {
            0% {
                transform: scale(1);
                opacity: 1
            }

            100% {
                transform: scale(.5);
                opacity: 0
            }
        }

        @keyframes swal2-hide {
            0% {
                transform: scale(1);
                opacity: 1
            }

            100% {
                transform: scale(.5);
                opacity: 0
            }
        }

        @-webkit-keyframes swal2-animate-success-line-tip {
            0% {
                top: 1.1875em;
                left: .0625em;
                width: 0
            }

            54% {
                top: 1.0625em;
                left: .125em;
                width: 0
            }

            70% {
                top: 2.1875em;
                left: -.375em;
                width: 3.125em
            }

            84% {
                top: 3em;
                left: 1.3125em;
                width: 1.0625em
            }

            100% {
                top: 2.8125em;
                left: .8125em;
                width: 1.5625em
            }
        }

        @keyframes swal2-animate-success-line-tip {
            0% {
                top: 1.1875em;
                left: .0625em;
                width: 0
            }

            54% {
                top: 1.0625em;
                left: .125em;
                width: 0
            }

            70% {
                top: 2.1875em;
                left: -.375em;
                width: 3.125em
            }

            84% {
                top: 3em;
                left: 1.3125em;
                width: 1.0625em
            }

            100% {
                top: 2.8125em;
                left: .8125em;
                width: 1.5625em
            }
        }

        @-webkit-keyframes swal2-animate-success-line-long {
            0% {
                top: 3.375em;
                right: 2.875em;
                width: 0
            }

            65% {
                top: 3.375em;
                right: 2.875em;
                width: 0
            }

            84% {
                top: 2.1875em;
                right: 0;
                width: 3.4375em
            }

            100% {
                top: 2.375em;
                right: .5em;
                width: 2.9375em
            }
        }

        @keyframes swal2-animate-success-line-long {
            0% {
                top: 3.375em;
                right: 2.875em;
                width: 0
            }

            65% {
                top: 3.375em;
                right: 2.875em;
                width: 0
            }

            84% {
                top: 2.1875em;
                right: 0;
                width: 3.4375em
            }

            100% {
                top: 2.375em;
                right: .5em;
                width: 2.9375em
            }
        }

        @-webkit-keyframes swal2-rotate-success-circular-line {
            0% {
                transform: rotate(-45deg)
            }

            5% {
                transform: rotate(-45deg)
            }

            12% {
                transform: rotate(-405deg)
            }

            100% {
                transform: rotate(-405deg)
            }
        }

        @keyframes swal2-rotate-success-circular-line {
            0% {
                transform: rotate(-45deg)
            }

            5% {
                transform: rotate(-45deg)
            }

            12% {
                transform: rotate(-405deg)
            }

            100% {
                transform: rotate(-405deg)
            }
        }

        @-webkit-keyframes swal2-animate-error-x-mark {
            0% {
                margin-top: 1.625em;
                transform: scale(.4);
                opacity: 0
            }

            50% {
                margin-top: 1.625em;
                transform: scale(.4);
                opacity: 0
            }

            80% {
                margin-top: -.375em;
                transform: scale(1.15)
            }

            100% {
                margin-top: 0;
                transform: scale(1);
                opacity: 1
            }
        }

        @keyframes swal2-animate-error-x-mark {
            0% {
                margin-top: 1.625em;
                transform: scale(.4);
                opacity: 0
            }

            50% {
                margin-top: 1.625em;
                transform: scale(.4);
                opacity: 0
            }

            80% {
                margin-top: -.375em;
                transform: scale(1.15)
            }

            100% {
                margin-top: 0;
                transform: scale(1);
                opacity: 1
            }
        }

        @-webkit-keyframes swal2-animate-error-icon {
            0% {
                transform: rotateX(100deg);
                opacity: 0
            }

            100% {
                transform: rotateX(0);
                opacity: 1
            }
        }

        @keyframes swal2-animate-error-icon {
            0% {
                transform: rotateX(100deg);
                opacity: 0
            }

            100% {
                transform: rotateX(0);
                opacity: 1
            }
        }

        @-webkit-keyframes swal2-rotate-loading {
            0% {
                transform: rotate(0)
            }

            100% {
                transform: rotate(360deg)
            }
        }

        @keyframes swal2-rotate-loading {
            0% {
                transform: rotate(0)
            }

            100% {
                transform: rotate(360deg)
            }
        }

        @-webkit-keyframes swal2-animate-question-mark {
            0% {
                transform: rotateY(-360deg)
            }

            100% {
                transform: rotateY(0)
            }
        }

        @keyframes swal2-animate-question-mark {
            0% {
                transform: rotateY(-360deg)
            }

            100% {
                transform: rotateY(0)
            }
        }

        @-webkit-keyframes swal2-animate-i-mark {
            0% {
                transform: rotateZ(45deg);
                opacity: 0
            }

            25% {
                transform: rotateZ(-25deg);
                opacity: .4
            }

            50% {
                transform: rotateZ(15deg);
                opacity: .8
            }

            75% {
                transform: rotateZ(-5deg);
                opacity: 1
            }

            100% {
                transform: rotateX(0);
                opacity: 1
            }
        }

        @keyframes swal2-animate-i-mark {
            0% {
                transform: rotateZ(45deg);
                opacity: 0
            }

            25% {
                transform: rotateZ(-25deg);
                opacity: .4
            }

            50% {
                transform: rotateZ(15deg);
                opacity: .8
            }

            75% {
                transform: rotateZ(-5deg);
                opacity: 1
            }

            100% {
                transform: rotateX(0);
                opacity: 1
            }
        }

        body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) {
            overflow: hidden
        }

        body.swal2-height-auto {
            height: auto !important
        }

        body.swal2-no-backdrop .swal2-container {
            background-color: transparent !important;
            pointer-events: none
        }

        body.swal2-no-backdrop .swal2-container .swal2-popup {
            pointer-events: all
        }

        body.swal2-no-backdrop .swal2-container .swal2-modal {
            box-shadow: 0 0 10px rgba(0, 0, 0, .4)
        }

        @media print {
            body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) {
                overflow-y: scroll !important
            }

            body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown)>[aria-hidden=true] {
                display: none
            }

            body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) .swal2-container {
                position: static !important
            }
        }

        body.swal2-toast-shown .swal2-container {
            box-sizing: border-box;
            width: 360px;
            max-width: 100%;
            background-color: transparent;
            pointer-events: none
        }

        body.swal2-toast-shown .swal2-container.swal2-top {
            top: 0;
            right: auto;
            bottom: auto;
            left: 50%;
            transform: translateX(-50%)
        }

        body.swal2-toast-shown .swal2-container.swal2-top-end,
        body.swal2-toast-shown .swal2-container.swal2-top-right {
            top: 0;
            right: 0;
            bottom: auto;
            left: auto
        }

        body.swal2-toast-shown .swal2-container.swal2-top-left,
        body.swal2-toast-shown .swal2-container.swal2-top-start {
            top: 0;
            right: auto;
            bottom: auto;
            left: 0
        }

        body.swal2-toast-shown .swal2-container.swal2-center-left,
        body.swal2-toast-shown .swal2-container.swal2-center-start {
            top: 50%;
            right: auto;
            bottom: auto;
            left: 0;
            transform: translateY(-50%)
        }

        body.swal2-toast-shown .swal2-container.swal2-center {
            top: 50%;
            right: auto;
            bottom: auto;
            left: 50%;
            transform: translate(-50%, -50%)
        }

        body.swal2-toast-shown .swal2-container.swal2-center-end,
        body.swal2-toast-shown .swal2-container.swal2-center-right {
            top: 50%;
            right: 0;
            bottom: auto;
            left: auto;
            transform: translateY(-50%)
        }

        body.swal2-toast-shown .swal2-container.swal2-bottom-left,
        body.swal2-toast-shown .swal2-container.swal2-bottom-start {
            top: auto;
            right: auto;
            bottom: 0;
            left: 0
        }

        body.swal2-toast-shown .swal2-container.swal2-bottom {
            top: auto;
            right: auto;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%)
        }

        body.swal2-toast-shown .swal2-container.swal2-bottom-end,
        body.swal2-toast-shown .swal2-container.swal2-bottom-right {
            top: auto;
            right: 0;
            bottom: 0;
            left: auto
        }
    </style>
    <style type="text/css" data-fbcssmodules="css:fb.css.base css:fb.css.dialog css:fb.css.iframewidget css:fb.css.customer_chat_plugin_iframe">
        .fb_hidden {
            position: absolute;
            top: -10000px;
            z-index: 10001
        }

        .fb_reposition {
            overflow: hidden;
            position: relative
        }

        .fb_invisible {
            display: none
        }

        .fb_reset {
            background: none;
            border: 0;
            border-spacing: 0;
            color: #000;
            cursor: auto;
            direction: ltr;
            font-family: "lucida grande", tahoma, verdana, arial, sans-serif;
            font-size: 11px;
            font-style: normal;
            font-variant: normal;
            font-weight: normal;
            letter-spacing: normal;
            line-height: 1;
            margin: 0;
            overflow: visible;
            padding: 0;
            text-align: left;
            text-decoration: none;
            text-indent: 0;
            text-shadow: none;
            text-transform: none;
            visibility: visible;
            white-space: normal;
            word-spacing: normal
        }

        .fb_reset>div {
            overflow: hidden
        }

        @keyframes fb_transform {
            from {
                opacity: 0;
                transform: scale(.95)
            }

            to {
                opacity: 1;
                transform: scale(1)
            }
        }

        .fb_animate {
            animation: fb_transform .3s forwards
        }

        .fb_hidden {
            position: absolute;
            top: -10000px;
            z-index: 10001
        }

        .fb_reposition {
            overflow: hidden;
            position: relative
        }

        .fb_invisible {
            display: none
        }

        .fb_reset {
            background: none;
            border: 0;
            border-spacing: 0;
            color: #000;
            cursor: auto;
            direction: ltr;
            font-family: "lucida grande", tahoma, verdana, arial, sans-serif;
            font-size: 11px;
            font-style: normal;
            font-variant: normal;
            font-weight: normal;
            letter-spacing: normal;
            line-height: 1;
            margin: 0;
            overflow: visible;
            padding: 0;
            text-align: left;
            text-decoration: none;
            text-indent: 0;
            text-shadow: none;
            text-transform: none;
            visibility: visible;
            white-space: normal;
            word-spacing: normal
        }

        .fb_reset>div {
            overflow: hidden
        }

        @keyframes fb_transform {
            from {
                opacity: 0;
                transform: scale(.95)
            }

            to {
                opacity: 1;
                transform: scale(1)
            }
        }

        .fb_animate {
            animation: fb_transform .3s forwards
        }

        .fb_dialog {
            background: rgba(82, 82, 82, .7);
            position: absolute;
            top: -10000px;
            z-index: 10001
        }

        .fb_dialog_advanced {
            border-radius: 8px;
            padding: 10px
        }

        .fb_dialog_content {
            background: #fff;
            color: #373737
        }

        .fb_dialog_close_icon {
            background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;
            cursor: pointer;
            display: block;
            height: 15px;
            position: absolute;
            right: 18px;
            top: 17px;
            width: 15px
        }

        .fb_dialog_mobile .fb_dialog_close_icon {
            left: 5px;
            right: auto;
            top: 5px
        }

        .fb_dialog_padding {
            background-color: transparent;
            position: absolute;
            width: 1px;
            z-index: -1
        }

        .fb_dialog_close_icon:hover {
            background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent
        }

        .fb_dialog_close_icon:active {
            background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent
        }

        .fb_dialog_iframe {
            line-height: 0
        }

        .fb_dialog_content .dialog_title {
            background: #6d84b4;
            border: 1px solid #365899;
            color: #fff;
            font-size: 14px;
            font-weight: bold;
            margin: 0
        }

        .fb_dialog_content .dialog_title>span {
            background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;
            float: left;
            padding: 5px 0 7px 26px
        }

        body.fb_hidden {
            height: 100%;
            left: 0;
            margin: 0;
            overflow: visible;
            position: absolute;
            top: -10000px;
            transform: none;
            width: 100%
        }

        .fb_dialog.fb_dialog_mobile.loading {
            background: url(https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;
            min-height: 100%;
            min-width: 100%;
            overflow: hidden;
            position: absolute;
            top: 0;
            z-index: 10001
        }

        .fb_dialog.fb_dialog_mobile.loading.centered {
            background: none;
            height: auto;
            min-height: initial;
            min-width: initial;
            width: auto
        }

        .fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner {
            width: 100%
        }

        .fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content {
            background: none
        }

        .loading.centered #fb_dialog_loader_close {
            clear: both;
            color: #fff;
            display: block;
            font-size: 18px;
            padding-top: 20px
        }

        #fb-root #fb_dialog_ipad_overlay {
            background: rgba(0, 0, 0, .4);
            bottom: 0;
            left: 0;
            min-height: 100%;
            position: absolute;
            right: 0;
            top: 0;
            width: 100%;
            z-index: 10000
        }

        #fb-root #fb_dialog_ipad_overlay.hidden {
            display: none
        }

        .fb_dialog.fb_dialog_mobile.loading iframe {
            visibility: hidden
        }

        .fb_dialog_mobile .fb_dialog_iframe {
            position: sticky;
            top: 0
        }

        .fb_dialog_content .dialog_header {
            background: linear-gradient(from(#738aba), to(#2c4987));
            border-bottom: 1px solid;
            border-color: #043b87;
            box-shadow: white 0 1px 1px -1px inset;
            color: #fff;
            font: bold 14px Helvetica, sans-serif;
            text-overflow: ellipsis;
            text-shadow: rgba(0, 30, 84, .296875) 0 -1px 0;
            vertical-align: middle;
            white-space: nowrap
        }

        .fb_dialog_content .dialog_header table {
            height: 43px;
            width: 100%
        }

        .fb_dialog_content .dialog_header td.header_left {
            font-size: 12px;
            padding-left: 5px;
            vertical-align: middle;
            width: 60px
        }

        .fb_dialog_content .dialog_header td.header_right {
            font-size: 12px;
            padding-right: 5px;
            vertical-align: middle;
            width: 60px
        }

        .fb_dialog_content .touchable_button {
            background: linear-gradient(from(#4267B2), to(#2a4887));
            background-clip: padding-box;
            border: 1px solid #29487d;
            border-radius: 3px;
            display: inline-block;
            line-height: 18px;
            margin-top: 3px;
            max-width: 85px;
            padding: 4px 12px;
            position: relative
        }

        .fb_dialog_content .dialog_header .touchable_button input {
            background: none;
            border: none;
            color: #fff;
            font: bold 12px Helvetica, sans-serif;
            margin: 2px -12px;
            padding: 2px 6px 3px 6px;
            text-shadow: rgba(0, 30, 84, .296875) 0 -1px 0
        }

        .fb_dialog_content .dialog_header .header_center {
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            line-height: 18px;
            text-align: center;
            vertical-align: middle
        }

        .fb_dialog_content .dialog_content {
            background: url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;
            border: 1px solid #4a4a4a;
            border-bottom: 0;
            border-top: 0;
            height: 150px
        }

        .fb_dialog_content .dialog_footer {
            background: #f5f6f7;
            border: 1px solid #4a4a4a;
            border-top-color: #ccc;
            height: 40px
        }

        #fb_dialog_loader_close {
            float: left
        }

        .fb_dialog.fb_dialog_mobile .fb_dialog_close_icon {
            visibility: hidden
        }

        #fb_dialog_loader_spinner {
            animation: rotateSpinner 1.2s linear infinite;
            background-color: transparent;
            background-image: url(https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);
            background-position: 50% 50%;
            background-repeat: no-repeat;
            height: 24px;
            width: 24px
        }

        @keyframes rotateSpinner {
            0% {
                transform: rotate(0deg)
            }

            100% {
                transform: rotate(360deg)
            }
        }

        .fb_iframe_widget {
            display: inline-block;
            position: relative
        }

        .fb_iframe_widget span {
            display: inline-block;
            position: relative;
            text-align: justify
        }

        .fb_iframe_widget iframe {
            position: absolute
        }

        .fb_iframe_widget_fluid_desktop,
        .fb_iframe_widget_fluid_desktop span,
        .fb_iframe_widget_fluid_desktop iframe {
            max-width: 100%
        }

        .fb_iframe_widget_fluid_desktop iframe {
            min-width: 220px;
            position: relative
        }

        .fb_iframe_widget_lift {
            z-index: 1
        }

        .fb_iframe_widget_fluid {
            display: inline
        }

        .fb_iframe_widget_fluid span {
            width: 100%
        }

        .fb_mpn_mobile_landing_page_slide_out {
            animation-duration: 200ms;
            animation-name: fb_mpn_landing_page_slide_out;
            transition-timing-function: ease-in
        }

        .fb_mpn_mobile_landing_page_slide_out_from_left {
            animation-duration: 200ms;
            animation-name: fb_mpn_landing_page_slide_out_from_left;
            transition-timing-function: ease-in
        }

        .fb_mpn_mobile_landing_page_slide_up {
            animation-duration: 500ms;
            animation-name: fb_mpn_landing_page_slide_up;
            transition-timing-function: ease-in
        }

        .fb_mpn_mobile_bounce_in {
            animation-duration: 300ms;
            animation-name: fb_mpn_bounce_in;
            transition-timing-function: ease-in
        }

        .fb_mpn_mobile_bounce_out {
            animation-duration: 300ms;
            animation-name: fb_mpn_bounce_out;
            transition-timing-function: ease-in
        }

        .fb_mpn_mobile_bounce_out_v2 {
            animation-duration: 300ms;
            animation-name: fb_mpn_fade_out;
            transition-timing-function: ease-in
        }

        .fb_customer_chat_bounce_in_v2 {
            animation-duration: 300ms;
            animation-name: fb_bounce_in_v2;
            transition-timing-function: ease-in
        }

        .fb_customer_chat_bounce_in_from_left {
            animation-duration: 300ms;
            animation-name: fb_bounce_in_from_left;
            transition-timing-function: ease-in
        }

        .fb_customer_chat_bounce_out_v2 {
            animation-duration: 300ms;
            animation-name: fb_bounce_out_v2;
            transition-timing-function: ease-in
        }

        .fb_customer_chat_bounce_out_from_left {
            animation-duration: 300ms;
            animation-name: fb_bounce_out_from_left;
            transition-timing-function: ease-in
        }

        .fb_invisible_flow {
            display: inherit;
            height: 0;
            overflow-x: hidden;
            width: 0
        }

        @keyframes fb_mpn_landing_page_slide_out {
            0% {
                margin: 0 12px;
                width: 100% - 24px
            }

            60% {
                border-radius: 18px
            }

            100% {
                border-radius: 50%;
                margin: 0 24px;
                width: 60px
            }
        }

        @keyframes fb_mpn_landing_page_slide_out_from_left {
            0% {
                left: 12px;
                width: 100% - 24px
            }

            60% {
                border-radius: 18px
            }

            100% {
                border-radius: 50%;
                left: 12px;
                width: 60px
            }
        }

        @keyframes fb_mpn_landing_page_slide_up {
            0% {
                bottom: 0;
                opacity: 0
            }

            100% {
                bottom: 24px;
                opacity: 1
            }
        }

        @keyframes fb_mpn_bounce_in {
            0% {
                opacity: .5;
                top: 100%
            }

            100% {
                opacity: 1;
                top: 0
            }
        }

        @keyframes fb_mpn_fade_out {
            0% {
                bottom: 30px;
                opacity: 1
            }

            100% {
                bottom: 0;
                opacity: 0
            }
        }

        @keyframes fb_mpn_bounce_out {
            0% {
                opacity: 1;
                top: 0
            }

            100% {
                opacity: .5;
                top: 100%
            }
        }

        @keyframes fb_bounce_in_v2 {
            0% {
                opacity: 0;
                transform: scale(0, 0);
                transform-origin: bottom right
            }

            50% {
                transform: scale(1.03, 1.03);
                transform-origin: bottom right
            }

            100% {
                opacity: 1;
                transform: scale(1, 1);
                transform-origin: bottom right
            }
        }

        @keyframes fb_bounce_in_from_left {
            0% {
                opacity: 0;
                transform: scale(0, 0);
                transform-origin: bottom left
            }

            50% {
                transform: scale(1.03, 1.03);
                transform-origin: bottom left
            }

            100% {
                opacity: 1;
                transform: scale(1, 1);
                transform-origin: bottom left
            }
        }

        @keyframes fb_bounce_out_v2 {
            0% {
                opacity: 1;
                transform: scale(1, 1);
                transform-origin: bottom right
            }

            100% {
                opacity: 0;
                transform: scale(0, 0);
                transform-origin: bottom right
            }
        }

        @keyframes fb_bounce_out_from_left {
            0% {
                opacity: 1;
                transform: scale(1, 1);
                transform-origin: bottom left
            }

            100% {
                opacity: 0;
                transform: scale(0, 0);
                transform-origin: bottom left
            }
        }

        @keyframes slideInFromBottom {
            0% {
                opacity: .1;
                transform: translateY(100%)
            }

            100% {
                opacity: 1;
                transform: translateY(0)
            }
        }

        @keyframes slideInFromBottomDelay {
            0% {
                opacity: 0;
                transform: translateY(100%)
            }

            97% {
                opacity: 0;
                transform: translateY(100%)
            }

            100% {
                opacity: 1;
                transform: translateY(0)
            }
        }
        
        .btn-primary {
            color: #000;
            background-color: #ffffff;
            border-color: #ccc
        }
        .btn-primarsy {
           color: #fff;
    background-color: #5bc0de;
    border-color: #46b8da
        }
    </style>
</head>

<body style="" class="">
    <input type="hidden" name="main_session">
    <div class="mainbar" style="height: 200px;">
        <div class="navbar">
            <div class="container">
                <a href="/" class="text-left">
                    <div class="">
                        <img src="<?= $setting['logo']; ?>" height="59px" alt="Logo">
                        <marquee width="100%" behavior="scroll" style="display: block;
position: fixed;
bottom: 70 px;
left: 15 px;
z-index: 1000;
cursor: pointer;
width: 100%;">
                            <font color="white" style="text-shadow: 0 0 0.2em #ff0000, 0 0 0.2em #ff0000,  0 0 0.2em #ff0000"><b>Hiện
                                    nay có rất nhiều website giả mạo , fake <?= ucfirst($_SERVER['SERVER_NAME']); ?> ,.... Tất cả các web đều giả
                                    mạo các bạn không nên chơi thử mà chỉ chơi tại đây tránh mất tiền oan !!!</b></font>
                        </marquee>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="content">
            <div class="content-container">
                <div class="py-5" style="min-height: 80px !important;">
                    <div class="output" id="output">
                        <h3 class="cursor">
                            Chẵn lẻ MoMo Tự Động </h3>
                        <h4>
                            Uy Tín - Nhanh Gọn - Tự Động 24/7 ! </h4>
                    </div>
                </div>
                <div class="text-center mt-5">
                    <button class="btn btn-default mt-1 btn-info" data-game="chanle">
                        Chẵn Lẻ
                    </button>
                    <button class="btn btn-default btn-primary mt-1" data-game="chanle2">
                        Chẵn Lẻ 2
                    </button>
                    <button class="btn btn-default btn-primary mt-1" data-game="taixiu">
                        Tài Xỉu
                    </button>
                    <button class="btn btn-default btn-primary mt-1" data-game="taixiu2">
                        Tài Xỉu 2
                    </button>
                    <button class="btn btn-default btn-primary mt-1" data-game="x3">
                        1 Phần 3
                    </button>
                    <button class="btn btn-default btn-primary mt-1" data-game="gap3">
                        Gấp 3
                    </button>
                    <button class="btn btn-default btn-primary mt-1 hidden" data-game="tong3so">
                        Tổng 3 Số
                    </button>
                    <button class="btn btn-default btn-primary mt-1" data-game="hieu2so">
                        H3
                    </button>
                 <!-- <button class="btn btn-default btn-primary mt-1" data-game="lo"> 
                        Lô-->
                    </button> 
                </div>
               <div class="text-center mt-5">
                    <div class="btn-group btn-group-lg" role="group" aria-label="...">
                        <button style="display:block; border-color: #ccc;" class="btn btn-default" data-minigame="day_mission">
                        Nhiệm Vụ Ngày 
                        <b style="
                           top: 33px; position: absolute;
                           /* left: 1%; */
                           /* margin: auto; */
                           margin-left: auto;
                           margin-right: auto;
                           left: 0;
                           right: 0;
                           text-align: center;
                           font-size: 9px;"><font color="red">(New)</font></b>
                        </button>
                       <button style="display:block; border-color: #ccc;" class="btn btn-default" data-minigame="giftcode">
                        Mã quà tặng
                        <b style="
                           top: 33px; position: absolute;
                           /* left: 1%; */
                           /* margin: auto; */
                           margin-left: auto;
                           margin-right: auto;
                           left: 0;
                           right: 0;
                           text-align: center;
                           font-size: 9px;"><font color="red">(HOT)</font></b>
                        </button>
                     </div>
                <div class="row justify-content-md-center box-cl">
                    <div class="col-md-6 mt-3 cl">
                        <div class="panel panel-primary">
                            <div class="panel-heading text-center">
                                Cách chơi
                            </div>
                            <div class="play-rules">
                                <!-- Chẵn lẻ 2 -->
                                <div class="panel-body game" style="padding-top: 10px; padding-bottom: 20px;" game-tab="chanle2">
                                    <p>- <b>Chẵn lẻ 2</b> là một game tính kết quả bằng <b> 1 số cuối mã giao dịch</b>.
                                    </p>
                                    <p>-Cách chơi vô cùng đơn giản :</p>
                                    <p>- Chuyển tiền vào một trong các tài khoản:</p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center mb-0">
                                            <thead>
                                                <tr>
                                                    <th class="text-center text-white bg-primary">Số điện thoại</th>
                                                    <th class="text-center text-white bg-primary">Tối thiểu</th>
                                                    <th class="text-center text-white bg-primary">Tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="result-table-10" role="alert">
                                                <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['CL2']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                                        <tr>
                                                            <td id="mm_<?= $data['phone']; ?>">
                                                                <b id="mln">
                                                                    <?= $data['phone']; ?> <b style="position: absolute;
top: 17px;
/* left: 1%; */
/* margin: auto; */
margin-left: auto;
margin-right: auto;
left: 0;
right: 0;
text-align: center;
font-size: 9px;"><font color="green"><?=format_cash($sum_chuyentien);?></font>/<font color="6861b1">30M</font>|<font color="green"><?=format_cash($sum_gd);?></font>/<font color="6861b1">150</font>
                                                                    </b>
                                                                </b>
                                                                <span class="label label-success text-uppercase" onclick="DUNGA.coppy('<?= $data['phone']; ?>', '<?= $config_phone['CL2']['min']; ?>', '<?= $config_phone['CL2']['max']; ?>')"><i class="fa fa-clipboard" aria-hidden="true"></i></span>
                                                            </td>
                                                            <td><?= format_cash($config_phone['CL2']['min']); ?> VNĐ</td>
                                                            <td><?= format_cash($config_phone['CL2']['max']); ?> VNĐ</td>
                                                        </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- <div class="text-center font-weight-bold">
                                        <b>Làm mới sau <span class="text-danger coundown-time">9</span> s</b>
                                    </div> -->
                                    <p class="mt-3">
                                        - Nội dung chuyển: <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-chan"></span><span class="fa-stack-1x text-white"><?= $config['CL2']['cmt_C']; ?></span></span> hoặc
                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-le"></span><span class="fa-stack-1x text-white"><?= $config['CL2']['cmt_L']; ?></span></span> (nếu đuôi mã giao dịch
                                        có các số sau)
                                    </p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr>
                                                    <th class="text-center text-white bg-primary">Nội dung</th>
                                                    <th class="text-center text-white bg-primary">1 Số cuối</th>
                                                    <th class="text-center text-white bg-primary">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="" id="result-table" role="alert">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-chan"> </span>
                                                            <span class="fa-stack-1x text-white comment-chan"><?= $config['CL2']['cmt_C']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_C = ["0", "2", "4", "6", "8"];
                                                        $expel = explode(',', $config['CL2']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_C); $i++) {
                                                            $rules = $list_C[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                                <span class="fa-stack">
                                                                    <span class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"> </span>
                                                                    <span class="fa-stack-1x text-white comment-chan"><?= $rules; ?></span>
                                                                </span>
                                                        <?php
                                                            }
                                                        } ?>
                                                    </td>
                                                    <td><b>x<?= $config['CL2']['ratio']; ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-le">
                                                            </span><span class="fa-stack-1x text-white comment-le"><?= $config['CL2']['cmt_L']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_C = ["1", "3", "5", "7", "9"];
                                                        $expel = explode(',', $config['CL2']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_C); $i++) {
                                                            $rules = $list_C[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                                <span class="fa-stack">
                                                                    <span class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"> </span>
                                                                    <span class="fa-stack-1x text-white comment-le"><?= $rules; ?></span>
                                                                </span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td><b>x<?= $config['CL2']['ratio']; ?></b></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    - Tiền thắng sẽ = <b>Tiền cược*<?= $config['CL2']['ratio']; ?></b><br> <b>- Lưu ý : Mức cược mỗi số khác nhau,
                                        nếu chuyển sai hạn mức hoặc sai nội dung vui lòng không than hoàn tiền.</b>
                                </div>

                                <!-- Chẵn lẻ -->
                                <div class="panel-body game active" style="padding-top: 10px; padding-bottom: 20px;" game-tab="chanle">
                                    <p>- <b>Chẵn lẻ</b> là một game tính kết quả bằng <b> 1 số cuối mã giao dịch</b>.
                                    </p>
                                    <p>-Cách chơi vô cùng đơn giản :</p>
                                    <p>- Chuyển tiền vào một trong các tài khoản:</p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center mb-0">
                                            <thead>
                                                <tr>
                                                    <th class="text-center text-white bg-primary">Số điện thoại</th>
                                                    <th class="text-center text-white bg-primary">Tối thiểu</th>
                                                    <th class="text-center text-white bg-primary">Tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="result-table-10" role="alert">
                                                <?php
                                                $list = $soicoder->fetch_assoc("SELECT `id`,`phone`, `DataJson`, `receive_day`, `today_gd`  FROM `cron_momo` WHERE `pay` = 'on' LIMIT 1000", 0);
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['CL']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                                        <tr>
                                                            <td id="mm_<?= $data['phone']; ?>">
                                                                <b id="mln">
                                                                    <?= $data['phone']; ?> <b style="position: absolute;
top: 17px;
/* left: 1%; */
/* margin: auto; */
margin-left: auto;
margin-right: auto;
left: 0;
right: 0;
text-align: center;
font-size: 9px;"><font color="green"><?=format_cash($sum_chuyentien);?></font>/<font color="6861b1">30M</font>|<font color="green"><?=format_cash($sum_gd);?></font>/<font color="6861b1">150</font>
                                                                    </b>
                                                                </b>
                                                                <span class="label label-success text-uppercase" onclick="DUNGA.coppy('<?= $data['phone']; ?>', '<?= $config_phone['CL']['min']; ?>', '<?= $config_phone['CL']['max']; ?>')"><i class="fa fa-clipboard" aria-hidden="true"></i></span>
                                                            </td>
                                                            <td><?= format_cash($config_phone['CL']['min']); ?> VNĐ</td>
                                                            <td><?= format_cash($config_phone['CL']['max']); ?> VNĐ</td>
                                                        </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- <div class="text-center font-weight-bold">
                                        <b>Làm mới sau <span class="text-danger coundown-time">9</span> s</b>
                                    </div> -->
                                    <p class="mt-3">
                                        - Nội dung chuyển: <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-chan"></span><span class="fa-stack-1x text-white"><?= $config['CL']['cmt_C']; ?></span></span> hoặc
                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-le"></span><span class="fa-stack-1x text-white"><?= $config['CL']['cmt_L']; ?></span></span> (nếu đuôi mã giao dịch có
                                        các số sau)
                                    </p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr>
                                                    <th class="text-center text-white bg-primary">Nội dung</th>
                                                    <th class="text-center text-white bg-primary">1 Số cuối</th>
                                                    <th class="text-center text-white bg-primary">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="" id="result-table" role="alert">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-chan"> </span>
                                                            <span class="fa-stack-1x text-white comment-chan"><?= $config['CL']['cmt_C']; ?></span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_C = ["0", "2", "4", "6", "8"];
                                                        $expel = explode(',', $config['CL']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_C); $i++) {
                                                            $rules = $list_C[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                                <span class="fa-stack">
                                                                    <span class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"> </span>
                                                                    <span class="fa-stack-1x text-white comment-chan"><?= $rules; ?></span>
                                                                </span>

                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td><b>x<?= $config['CL']['ratio']; ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-le">
                                                            </span><span class="fa-stack-1x text-white comment-le"><?= $config['CL']['cmt_L']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_C = ["1", "3", "5", "7", "9"];
                                                        $expel = explode(',', $config['CL']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_C); $i++) {
                                                            $rules = $list_C[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                                <span class="fa-stack">
                                                                    <span class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"> </span>
                                                                    <span class="fa-stack-1x text-white comment-le"><?= $rules; ?></span>
                                                                </span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td><b>x<?= $config['CL']['ratio']; ?></b></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    - Tiền thắng sẽ = <b>Tiền cược*<?= $config['CL']['ratio']; ?></b><br> <b>- Lưu ý : Mức cược mỗi số khác nhau,
                                        nếu chuyển sai hạn mức hoặc sai nội dung vui lòng không than hoàn tiền.</b>
                                </div>



                                <!-- Tài xỉu 2 -->
                                <div class="panel-body game" style="padding-top: 10px; padding-bottom: 20px;" game-tab="taixiu2">
                                    <p>- <b>Tài Xỉu 2</b> là một game tính kết quả bằng <b> 1 số cuối mã giao dịch</b>.
                                    </p>
                                    <p>-Cách chơi vô cùng đơn giản :</p>
                                    <p>- Chuyển tiền vào một trong các tài khoản:</p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center mb-0">
                                            <thead>
                                                <tr>
                                                    <th class="text-center text-white bg-primary">Số điện thoại</th>
                                                    <th class="text-center text-white bg-primary">Tối thiểu</th>
                                                    <th class="text-center text-white bg-primary">Tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="result-table-10" role="alert">
                                                <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['TX2']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                                       <tr>
                                                            <td id="mm_<?= $data['phone']; ?>">
                                                                <b id="mln">
                                                                    <?= $data['phone']; ?> <b style="position: absolute;
top: 17px;
/* left: 1%; */
/* margin: auto; */
margin-left: auto;
margin-right: auto;
left: 0;
right: 0;
text-align: center;
font-size: 9px;"><font color="green"><?=format_cash($sum_chuyentien);?></font>/<font color="6861b1">30M</font>|<font color="green"><?=format_cash($sum_gd);?></font>/<font color="6861b1">150</font>
                                                                    </b>
                                                                </b>
                                                                    </b>
                                                                </b>
                                                                <span class="label label-success text-uppercase" onclick="DUNGA.coppy('<?= $data['phone']; ?>', '<?= $config_phone['TX2']['min']; ?>', '<?= $config_phone['TX2']['min']; ?>')"><i class="fa fa-clipboard" aria-hidden="true"></i></span>
                                                            </td>
                                                            <td><?= format_cash($config_phone['TX2']['min']); ?> VNĐ</td>
                                                            <td><?= format_cash($config_phone['TX2']['max']); ?> VNĐ</td>
                                                        </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- <div class="text-center font-weight-bold">
                                        <b>Làm mới sau <span class="text-danger coundown-time">9</span> s</b>
                                    </div> -->
                                    <p class="mt-3">
                                        - Nội dung chuyển: <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-tai"></span><span class="fa-stack-1x text-white"><?= $config['TX2']['cmt_T']; ?></span></span> hoặc
                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-xiu"></span><span class="fa-stack-1x text-white"><?= $config['TX2']['cmt_X']; ?></span></span> (nếu đuôi mã giao dịch
                                        có các số sau)
                                    </p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr>
                                                    <th class="text-center text-white bg-primary">Nội dung</th>
                                                    <th class="text-center text-white bg-primary">1 Số cuối</th>
                                                    <th class="text-center text-white bg-primary">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="" id="result-table" role="alert">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-tai"> </span>
                                                            <span class="fa-stack-1x text-white comment-tai"><?= $config['TX2']['cmt_T']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_T = ["5", "6", "7", "8", "9"];
                                                        $expel = explode(',', $config['TX2']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_T); $i++) {
                                                            $rules = $list_T[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                                <span class="fa-stack">
                                                                    <span class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"> </span>
                                                                    <span class="fa-stack-1x text-white comment-tai"><?= $rules; ?></span>
                                                                </span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td><b>x<?= $config['TX2']['ratio']; ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-xiu">
                                                            </span><span class="fa-stack-1x text-white comment-xiu"><?= $config['TX2']['cmt_X']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_X = ["0", "1", "2", "3", "4"];
                                                        $expel = explode(',', $config['TX2']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_X); $i++) {
                                                            $rules = $list_X[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                                <span class="fa-stack">
                                                                    <span class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"> </span>
                                                                    <span class="fa-stack-1x text-white comment-xiu"><?= $rules; ?></span>
                                                                </span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td><b>x<?= $config['TX2']['ratio']; ?></b></td>
                                                </tr>
                                            </tbody>
                                        </table>x<?= $config['TX2']['ratio']; ?>
                                    </div>
                                    - Tiền thắng sẽ = <b>Tiền cược*<?= $config['TX2']['ratio']; ?></b><br> <b>- Lưu ý : Mức cược mỗi số khác nhau,
                                        nếu chuyển sai hạn mức hoặc sai nội dung vui lòng không than hoàn tiền.</b>
                                </div>


                                <!-- Tài xỉu -->
                                <div class="panel-body game" style="padding-top: 10px; padding-bottom: 20px;" game-tab="taixiu">
                                    <p>- <b>Tài Xỉu</b> là một game tính kết quả bằng <b> 1 số cuối mã giao dịch</b>.
                                    </p>
                                    <p>-Cách chơi vô cùng đơn giản :</p>
                                    <p>- Chuyển tiền vào một trong các tài khoản:</p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center mb-0">
                                            <thead>
                                                <tr>
                                                    <th class="text-center text-white bg-primary">Số điện thoại</th>
                                                    <th class="text-center text-white bg-primary">Tối thiểu</th>
                                                    <th class="text-center text-white bg-primary">Tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="result-table-10" role="alert">
                                                <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['TX']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                                        <tr>
                                                            <td id="mm_<?= $data['phone']; ?>">
                                                                <b id="mln">
                                                                    <?= $data['phone']; ?> <b style="position: absolute;
top: 17px;
/* left: 1%; */
/* margin: auto; */
margin-left: auto;
margin-right: auto;
left: 0;
right: 0;
text-align: center;
font-size: 9px;"><font color="green"><?=format_cash($sum_chuyentien);?></font>/<font color="6861b1">30M</font>|<font color="green"><?=format_cash($sum_gd);?></font>/<font color="6861b1">150</font>
                                                                    </b>
                                                                </b>
                                                                <span class="label label-success text-uppercase" onclick="DUNGA.coppy('<?= $data['phone']; ?>', '<?= $config_phone['TX']['min']; ?>', '<?= $config_phone['TX']['max']; ?>')"><i class="fa fa-clipboard" aria-hidden="true"></i></span>
                                                            </td>
                                                            <td><?= format_cash($config_phone['TX']['min']); ?> VNĐ</td>
                                                            <td><?= format_cash($config_phone['TX']['max']); ?> VNĐ</td>
                                                        </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- <div class="text-center font-weight-bold">
                                        <b>Làm mới sau <span class="text-danger coundown-time">9</span> s</b>
                                    </div> -->
                                    <p class="mt-3">
                                        - Nội dung chuyển: <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-tai"></span><span class="fa-stack-1x text-white"><?= $config['TX']['cmt_T']; ?></span></span> hoặc
                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-xiu"></span><span class="fa-stack-1x text-white"><?= $config['TX']['cmt_X']; ?></span></span> (nếu đuôi mã giao dịch có
                                        các số sau)
                                    </p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr>
                                                    <th class="text-center text-white bg-primary">Nội dung</th>
                                                    <th class="text-center text-white bg-primary">1 Số cuối</th>
                                                    <th class="text-center text-white bg-primary">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="" id="result-table" role="alert">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-tai"> </span>
                                                            <span class="fa-stack-1x text-white comment-tai"><?= $config['TX']['cmt_T']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_T = ["5", "6", "7", "8", "9"];
                                                        $expel = explode(',', $config['TX']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_T); $i++) {
                                                            $rules = $list_T[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                                <span class="fa-stack">
                                                                    <span class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"> </span>
                                                                    <span class="fa-stack-1x text-white comment-tai"><?= $rules; ?></span>
                                                                </span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td><b>x<?= $config['TX']['ratio']; ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-xiu">
                                                            </span><span class="fa-stack-1x text-white comment-xiu"><?= $config['TX']['cmt_X']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_X = ["0", "1", "2", "3", "4"];
                                                        $expel = explode(',', $config['TX']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_X); $i++) {
                                                            $rules = $list_X[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                                <span class="fa-stack">
                                                                    <span class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"> </span>
                                                                    <span class="fa-stack-1x text-white comment-xiu"><?= $rules; ?></span>
                                                                </span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td><b>x<?= $config['TX']['ratio']; ?></b></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    - Tiền thắng sẽ = <b>Tiền cược*<?= $config['TX']['ratio']; ?></b><br> <b>- Lưu ý : Mức cược mỗi số khác nhau,
                                        nếu chuyển sai hạn mức hoặc sai nội dung vui lòng không than hoàn tiền.</b>
                                </div>



                                <!-- 1 phần 3 -->
                                <div class="panel-body game" style="padding-top: 10px; padding-bottom: 20px;" game-tab="x3">
                                    <p>- <b>1 phần 3</b> là một game tính kết quả bằng <b> 1 số cuối mã giao dịch</b>.
                                    </p>
                                    <p>- Cách chơi vô cùng đơn giản:</p>
                                    <p>- Chuyển tiền vào một trong các tài khoản:</p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center mb-0">
                                            <thead>
                                                <tr>
                                                    <th class="text-center text-white bg-primary">Số điện thoại</th>
                                                    <th class="text-center text-white bg-primary">Tối thiểu</th>
                                                    <th class="text-center text-white bg-primary">Tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="result-table-10" role="alert">
                                                <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['1P3']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>

                                                        <tr>
                                                            <td id="mm_<?= $data['phone']; ?>">
                                                                <b id="mln">
                                                                    <?= $data['phone']; ?> <b style="position: absolute;
top: 17px;
/* left: 1%; */
/* margin: auto; */
margin-left: auto;
margin-right: auto;
left: 0;
right: 0;
text-align: center;
font-size: 9px;"><font color="green"><?=format_cash($sum_chuyentien);?></font>/<font color="6861b1">30M</font>|<font color="green"><?=format_cash($sum_gd);?></font>/<font color="6861b1">150</font>
                                                                    </b>
                                                                </b>
                                                                <span class="label label-success text-uppercase" onclick="DUNGA.coppy('<?= $data['phone']; ?>', '<?= $config_phone['1P3']['min']; ?>', '<?= $config_phone['1P3']['max']; ?>')"><i class="fa fa-clipboard" aria-hidden="true"></i></span>
                                                            </td>
                                                            <td><?= format_cash($config_phone['1P3']['min']); ?> VNĐ</td>
                                                            <td><?= format_cash($config_phone['1P3']['max']); ?> VNĐ</td>
                                                        </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- <div class="text-center font-weight-bold">
                                        <b>Làm mới sau <span class="text-danger coundown-time">9</span> s</b>
                                    </div> -->
                                    <p class="mt-3">
                                        - Nội dung chuyển: <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-chan"></span><span class="fa-stack-1x text-white comment-n1"><?= $config['1P3']['cmt_N1']; ?></span></span> hoặc
                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-le">
                                            </span><span class="fa-stack-1x text-white comment-n2"><?= $config['1P3']['cmt_N2']; ?></span></span> hoặc
                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-tai">
                                            </span><span class="fa-stack-1x text-white comment-n3"><?= $config['1P3']['cmt_N3']; ?></span></span> hoặc
                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-xiu">
                                            </span><span class="fa-stack-1x text-white comment-n0"><?= $config['1P3']['cmt_N0']; ?></span></span> (nếu đuôi mã giao dịch có các số sau)
                                    </p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr class="bg-primary" role="row">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">1 Số cuối</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="" id="result-table" role="alert">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-chan">
                                                            </span><span class="fa-stack-1x text-white" id=""><?= $config['1P3']['cmt_N1']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                                            <span class="fa-stack-1x text-white comment-chan">1</span>
                                                        </span>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                                            <span class="fa-stack-1x text-white comment-chan">2</span>
                                                        </span>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-3"></span>
                                                            <span class="fa-stack-1x text-white comment-chan">3</span>
                                                        </span>
                                                    </td>
                                                    <td><b>x<?= $config['1P3']['ratio_N1']; ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-le">
                                                            </span><span class="fa-stack-1x text-white" id=""><?= $config['1P3']['cmt_N2']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                                            <span class="fa-stack-1x text-white comment-chan">4</span>
                                                        </span>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-3"></span>
                                                            <span class="fa-stack-1x text-white comment-chan">5</span>
                                                        </span>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-4"></span>
                                                            <span class="fa-stack-1x text-white comment-chan">6</span>
                                                        </span>
                                                        <!-- <code>4</code> - <code>5</code> - <code>6</code></td> -->
                                                    <td><b>x<?= $config['1P3']['ratio_N2']; ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-tai">
                                                            </span><span class="fa-stack-1x text-white" id=""><?= $config['1P3']['cmt_N3']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-3"></span>
                                                            <span class="fa-stack-1x text-white comment-chan">7</span>
                                                        </span>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-4"></span>
                                                            <span class="fa-stack-1x text-white comment-chan">8</span>
                                                        </span>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                                            <span class="fa-stack-1x text-white comment-chan">9</span>
                                                        </span>
                                                        <!-- <code>7</code> - <code>8</code> - <code>9</code></td> -->
                                                    <td><b>x<?= $config['1P3']['ratio_N3']; ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-xiu">
                                                            </span><span class="fa-stack-1x text-white" id=""><?= $config['1P3']['cmt_N0']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-5"></span>
                                                            <span class="fa-stack-1x text-white comment-chan">0</span>
                                                        </span>

                                                        <!-- <code>0</code></td> -->
                                                    <td><b>x<?= $config['1P3']['ratio_N0']; ?></b></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <p>- Nếu mã giao dịch có số cuối trùng với 1 trong 3 số trên, bạn sẽ chiến thắng.
                                    </p>
                                    <b>- Lưu ý : Mức cược mỗi số khác nhau,
                                        nếu chuyển sai hạn mức hoặc sai nội dung vui lòng không than hoàn tiền.</b>
                                </div>


                                <!-- H2S -->
                                <div class="panel-body game" style="padding-top: 10px; padding-bottom: 20px;" game-tab="hieu2so">
                                    <p>- <b>H3</b> là một game tính kết quả bằng <b>hiệu 2 số cuối mã giao dịch (Số
                                            trước trừ số sau). Ví dụ: xxx94 =&gt; 9 - 4 = 5</b>.</p>
                                    <p>- Cách chơi vô cùng đơn giản:</p>
                                    <p>- Chuyển tiền vào một trong các tài khoản:</p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center mb-0">
                                            <thead>
                                                <tr>
                                                    <th class="text-center text-white bg-primary">Số điện thoại</th>
                                                    <th class="text-center text-white bg-primary">Tối thiểu</th>
                                                    <th class="text-center text-white bg-primary">Tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="result-table-10" role="alert">
                                                <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['H2S']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                                        <tr>
                                                            <td id="mm_<?= $data['phone']; ?>">
                                                                <b id="mln">
                                                                    <?= $data['phone']; ?> <b style="position: absolute;
top: 17px;
/* left: 1%; */
/* margin: auto; */
margin-left: auto;
margin-right: auto;
left: 0;
right: 0;
text-align: center;
font-size: 9px;"><font color="green"><?=format_cash($sum_chuyentien);?></font>/<font color="6861b1">30M</font>|<font color="green"><?=format_cash($sum_gd);?></font>/<font color="6861b1">150</font>
                                                                    </b>
                                                                </b>
                                                                <span class="label label-success text-uppercase" onclick="DUNGA.coppy('<?= $data['phone']; ?>', '<?= $config_phone['H2S']['min']; ?>', '<?= $config_phone['H2S']['max']; ?>')"><i class="fa fa-clipboard" aria-hidden="true"></i></span>
                                                            </td>
                                                            <td><?= format_cash($config_phone['H2S']['min']); ?> VNĐ</td>
                                                            <td><?= format_cash($config_phone['H2S']['max']); ?> VNĐ</td>
                                                        </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- <div class="text-center font-weight-bold">
                                        <b>Làm mới sau <span class="text-danger coundown-time">9</span> s</b>
                                    </div> -->
                                    <p class="mt-3">
                                        - Nội dung chuyển : <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-chan"></span><span class="fa-stack-1x text-white comment-n1"><?= $config['H2S']['cmt']; ?></span></span>
                                    </p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr class="bg-primary" role="row">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">Hiệu 2 Số cuối bằng</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="" id="result-table" role="alert">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-chan">
                                                            </span><span class="fa-stack-1x text-white" id=""><?= $config['H2S']['cmt']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                                            <span class="fa-stack-1x text-white comment-chan"><?= $config['H2S']['rules_1']; ?></span>
                                                        </span>
                                                    </td>
                                                    <td><b>x<?= $config['H2S']['ratio_1']; ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-chan">
                                                            </span><span class="fa-stack-1x text-white" id=""><?= $config['H2S']['cmt']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                                            <span class="fa-stack-1x text-white comment-chan"><?= $config['H2S']['rules_2']; ?></span>
                                                        </span>
                                                    </td>
                                                    <td><b>x<?= $config['H2S']['ratio_2']; ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-chan">
                                                            </span><span class="fa-stack-1x text-white" id=""><?= $config['H2S']['cmt']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-3"></span>
                                                            <span class="fa-stack-1x text-white comment-chan"><?= $config['H2S']['rules_3']; ?></span>
                                                        </span>
                                                    </td>
                                                    <td><b>x<?= $config['H2S']['ratio_3']; ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-chan">
                                                            </span><span class="fa-stack-1x text-white" id=""><?= $config['H2S']['cmt']; ?></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-4"></span>
                                                            <span class="fa-stack-1x text-white comment-chan"><?= $config['H2S']['rules_4']; ?></span>
                                                        </span>
                                                    <td><b>x<?= $config['H2S']['ratio_4']; ?></b></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <p>- Nếu mã giao dịch có hiệu của 2 số (số trước trừ số sau) trùng 1 trong những số
                                        trên bạn sẽ chiến thắng.</p>
                                    <b>- Lưu ý : Mức cược mỗi số khác nhau,
                                        nếu chuyển sai hạn mức hoặc sai nội dung vui lòng không than hoàn tiền.</b>
                                </div>


                                <!-- Lô -->
                                <div class="panel-body game" style="padding-top: 10px; padding-bottom: 20px;" game-tab="lo">
                                    <p>- <b>Lô</b> là một game tính kết quả bằng <b> 2 số cuối mã giao dịch</b>.</p>
                                    <p>- Cách chơi vô cùng đơn giản:</p>
                                    <p>- Chuyển tiền vào một trong các tài khoản:</p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center mb-0">
                                            <thead>
                                                <tr>
                                                    <th class="text-center text-white bg-primary">Số điện thoại</th>
                                                    <th class="text-center text-white bg-primary">Tối thiểu</th>
                                                    <th class="text-center text-white bg-primary">Tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="result-table-10" role="alert">
                                                <tr>
                                                    <td id="mm_0566242964">
                                                        <b id="mln">
                                                            0566242964 <b id="hmln" attr-name="amount" class="">
                                                                <font color="green">956,763</font>/<font color="6861b1">
                                                                    50M</font>
                                                            </b>
                                                            <b id="hmln" class="hidden" attr-name="times">
                                                                <font color="red">18</font>/<font color="6861b1">200
                                                                    Giao dịch
                                                                </font>
                                                            </b>
                                                        </b>
                                                        <span class="label label-success text-uppercase" onclick="DUNGA.coppy('0566242964', '5000', '500000')"><i class="fa fa-clipboard" aria-hidden="true"></i></span>
                                                        <span class="label label-success text-uppercase" onclick="DUNGA.play('0566242964')"><i class="fa fa-play" aria-hidden="true"></i></span>
                                                    </td>
                                                    <td>5,000 VNĐ</td>
                                                    <td>500,000 VNĐ</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- <div class="text-center font-weight-bold">
                                        <b>Làm mới sau <span class="text-danger coundown-time">9</span> s</b>
                                    </div> -->
                                    <p class="mt-3">
                                        - Nội dung chuyển : <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-chan"></span><span class="fa-stack-1x text-white comment-n1">LO</span></span>
                                    </p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center table-responsive">
                                            <thead>
                                                <tr class="bg-primary" role="row">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">2 Số cuối</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="" id="result-table" role="alert">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-chan">
                                                            </span><span class="fa-stack-1x text-white" id="">LO</span></span>
                                                    </td>
                                                    <td>
                                                        <code>01</code> - <code>03</code> - <code>12</code> -
                                                        <code>19</code> - <code>23</code> -
                                                        <code>24</code> - <code>30</code> - <code>33</code> -
                                                        <code>39</code> - <code>48</code> -
                                                        <code>54</code> - <code>55</code> -
                                                        <code>60</code> - <code>61</code> - <code>71</code> -
                                                        <code>77</code> - <code>81</code> -
                                                        <code>82</code> - <code>83</code> - <code>67</code> -
                                                        <code>88</code> - <code>76</code> -
                                                        <code>64</code> - <code>79</code> -
                                                        <code>29</code> - <code>99</code>
                                                    </td>
                                                    <td><b>3</b></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <p>- Nếu mã giao dịch có 2 số cuối trùng với 1 trong các số trên, bạn sẽ chiến
                                        thắng.</p>
                                    <b>- Lưu ý : Mức cược mỗi số khác nhau,
                                        nếu chuyển sai hạn mức hoặc sai nội dung vui lòng không than hoàn tiền.</b>
                                </div>



                                <!-- Gấp 3 -->
                                <div class="panel-body game" style="padding-top: 10px; padding-bottom: 20px;" game-tab="gap3">
                                    <p>- <b>Gấp 3</b> là một game tính kết quả bằng <b>nhiều số cuối mã giao dịch</b>.
                                    </p>
                                    <p>- Cách chơi vô cùng đơn giản:</p>
                                    <p>- Chuyển tiền vào một trong các tài khoản:</p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center mb-0">
                                            <thead>
                                                <tr>
                                                    <th class="text-center text-white bg-primary">Số điện thoại</th>
                                                    <th class="text-center text-white bg-primary">Tối thiểu</th>
                                                    <th class="text-center text-white bg-primary">Tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="result-table-10" role="alert">
                                                <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['T3S']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                                        <tr>
                                                            <td id="mm_<?= $data['phone']; ?>">
                                                                <b id="mln">
                                                                    <?= $data['phone']; ?> <b style="position: absolute;
top: 17px;
/* left: 1%; */
/* margin: auto; */
margin-left: auto;
margin-right: auto;
left: 0;
right: 0;
text-align: center;
font-size: 9px;"><font color="green"><?=format_cash($sum_chuyentien);?></font>/<font color="6861b1">30M</font>|<font color="green"><?=format_cash($sum_gd);?></font>/<font color="6861b1">150</font>
                                                                    </b>
                                                                </b>
                                                                <span class="label label-success text-uppercase" onclick="DUNGA.coppy('<?= $data['phone']; ?>', '<?= $config_phone['T3S']['min']; ?>', '<?= $config_phone['T3S']['max']; ?>')"><i class="fa fa-clipboard" aria-hidden="true"></i></span>
                                                            </td>
                                                            <td><?= format_cash($config_phone['T3S']['min']); ?> VNĐ</td>
                                                            <td><?= format_cash($config_phone['T3S']['max']); ?> VNĐ</td>
                                                        </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- <div class="text-center font-weight-bold">
                                        <b>Làm mới sau <span class="text-danger coundown-time">9</span> s</b>
                                    </div> -->
                                    <p class="mt-3">- Nội dung chuyển : <?= $config['T3S']['cmt']; ?> (nếu đuôi mã giao dịch có các số sau)</p>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr class="bg-primary" role="row">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">Các số cuối</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody aria-live="polite" aria-relevant="all" class="" id="result-table" role="alert">
                                                <tr>
                                                    <td><?= $config['T3S']['cmt']; ?></td>
                                                    <td>
                                                        <?php
                                                        $lis_rules_1 = explode(',', $config['T3S']['rules_1']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($lis_rules_1); $i++) {
                                                            $rules = $lis_rules_1[$i];
                                                        ?>
                                                            <span class="fa-stack">
                                                                <span class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"></span>
                                                                <span class="fa-stack-1x text-white comment-chan"><?= $rules; ?></span>
                                                            </span>
                                                        <?php } ?>
                                                    </td>
                                                    <td><b>x<?= $config['T3S']['ratio_1']; ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td><?= $config['T3S']['cmt']; ?></td>
                                                    <td>
                                                        <?php
                                                        $lis_rules_2 = explode(',', $config['T3S']['rules_2']);
                                                        $dem = 2;
                                                        for ($i = 0; $i < count($lis_rules_2); $i++) {
                                                            $rules = $lis_rules_2[$i];
                                                        ?>
                                                            <span class="fa-stack">
                                                                <span class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"></span>
                                                                <span class="fa-stack-1x text-white comment-chan"><?= $rules; ?></span>
                                                            </span>
                                                        <?php } ?>
                                                    </td>
                                                    <td><b>x<?= $config['T3S']['ratio_2']; ?></b></td>
                                                </tr>
                                                <tr>
                                                    <td><?= $config['T3S']['cmt']; ?></td>
                                                    <td>
                                                        <?php
                                                        $lis_rules_3 = explode(',', $config['T3S']['rules_3']);
                                                        $dem = 3;
                                                        for ($i = 0; $i < count($lis_rules_3); $i++) {
                                                            $rules = $lis_rules_3[$i];
                                                        ?>
                                                            <span class="fa-stack">
                                                                <span class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"></span>
                                                                <span class="fa-stack-1x text-white comment-chan"><?= $rules; ?></span>
                                                            </span>
                                                        <?php } ?>
                                                    </td>
                                                    <td><b>x<?= $config['T3S']['ratio_3']; ?></b></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <b>- Lưu ý : Mức cược mỗi số khác nhau,
                                        nếu chuyển sai hạn mức hoặc sai nội dung vui lòng không than hoàn tiền.</b>
                                </div>
                            </div>


                            <!-- Điểm danh -->
                            <div class="minigame-rules">
                                <div class="panel-body game" style="padding-top: 10px; padding-bottom: 20px;" game-tab="diemdanh">
                                    <style>
                                        #diemDanhCard {
                                            margin-top: 0.5rem;
                                            color: #155724;
                                            border-color: #c3e6cb;
                                        }

                                        #occard {
                                            margin-top: 0.5rem;
                                            color: #155724;
                                            background-color: #9cbca4;
                                            border-color: #c3e6cb;
                                            padding: 20px;
                                        }

                                        .occho {
                                            margin-top: 0.5rem;
                                            color: #155724;
                                            background-color: #aed6b8;
                                            border-color: #c3e6cb;
                                            padding: 20px;
                                        }
                                    </style>
                                    <div class="row collapse show" id="diemDanhCard" style="">
                                        <div class="col-lg-12">
                                            <div class="body">
                                                <div class="text-center">
                                                    <font color="blue"><big><b>Điểm Danh Nhận Quà Miễn Phí</b></big>
                                                    </font>
                                                    <br>
                                                    <small><i class="fa fa-info-circle" aria-hidden="true"></i> Mã quà:
                                                        <font color="orange"><b id="diemdanh_id">8098</b></font>
                                                    </small><br>
                                                    <small><i class="fa fa-usd" aria-hidden="true"></i> Giá trị: <font color="Maroon"><b id="">5.000 ~ 100.000</b> vnđ</font></small><br>
                                                    <small><i class="fa fa-user" aria-hidden="true"></i>: <font color="333366"><b id="diemdanh_user">24</b> người</font></small><br>
                                                    <small><i class="fa fa-clock-o" aria-hidden="true"></i> Quay thưởng sau: <font color="660000"><b id="diemdanh_thoigian">16</b> giây </font></small><br>
                                                    <small><i class="fa fa-star" aria-hidden="true"></i> Thắng phiên<p id="textLuckOld" style="display: none;"> trước</p>:</small>
                                                    <b id="diemdanh_last" class="text-danger font-weight-bold" style="word-break: break-word;">0165***4405</b>
                                                    <br>
                                                    <small><i class="fa fa-bandcamp" aria-hidden="true"></i> Tổng tiền
                                                        đã trao: <font color="blue"><b id="diemdanh_tongtien">1,000</b>
                                                            VNĐ</font></small><br>
                                                    <div class="form-group occard" id="occard">
                                                        <label for="exampleInputEmail1">Số điện thoại:</label>
                                                        <input type="text" class="form-control" name="phoneattendance" id="phoneattendance" placeholder="03837755">
                                                        <small id="emailHelp" class="form-text text-muted">Nhập số điện
                                                            thoại của bạn để điểm
                                                            danh.</small>
                                                        <br>
                                                        <button class="btn btn-success" data-toggle="modal" data-target="#modalDiemDanh" onclick="attendance()">Điểm danh
                                                        </button>
                                                    </div>

                                                    <button class="btn btn-info" onclick="$('#muc_huongdan').show();$('#muc_users').hide();$('#muc_lichsu').hide();">Cách
                                                        chơi
                                                    </button>
                                                    <button class="btn btn-dark" data-toggle="modal" onclick="$('#muc_huongdan').hide();$('#muc_users').hide();$('#muc_lichsu').show();">Lịch
                                                        sử
                                                    </button>
                                                    <button class="btn btn-danger" onclick="$('#muc_huongdan').hide();$('#muc_users').show();$('#muc_lichsu').hide();">Danh
                                                        sách
                                                    </button>
                                                </div>
                                                <div class="occho" id="muc_huongdan">
                                                    - Mỗi phiên quà các bạn có 10 phút để điểm danh. <br>
                                                    - Số điện thoại điểm danh phải chơi <?= ucfirst($_SERVER['SERVER_NAME']); ?> ít nhất 1 lần trong
                                                    ngày. Không giới hạn số lần điểm
                                                    danh trong ngày. <br>
                                                    - Khi hết thời gian, người may mắn sẽ nhận được số tiền của phiên
                                                    đó. <br>
                                                    - Game <b>Điểm danh miễn phí</b> chỉ hoạt động từ <b>7h sáng</b> đến
                                                    1h đêm
                                                </div>

                                                <div class="occho" id="muc_lichsu" style="display:none;">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped table-bordered table-hover text-center">
                                                            <thead>
                                                                <tr role="row" class="bg-primary">
                                                                    <th class="text-center text-white">Mã</th>
                                                                    <th class="text-center text-white">Tổng</th>
                                                                    <th class="text-center text-white">SDT</th>
                                                                    <th class="text-center text-white">VND</th>

                                                                </tr>
                                                            </thead>
                                                            <tbody id="mayman_log">
                                                                <tr>
                                                                    <td><small>7159</small></td>
                                                                    <td><small>1</small></td>
                                                                    <td>0168***5004</td>
                                                                    <td>1,000</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>

                                                <div class="occho" id="muc_users" style="display:none;">0165***2736,
                                                    0167***2259, 0162***3463, 0163***2282, 0985***913, 0916***984,
                                                    0164***1368, 0128***4800, 0982***376, 0168***1217, 0976***897,
                                                    0971***448, 0965***207, 0981***427, 0164***3208, 0165***1248,
                                                    0165***4405, 0163***2484, 0962***303, 0937***713, 0928***014,
                                                    0918***215, 0165***3287, 0907***932</div>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <script>
                                    setInterval(() => {
                                        countSeccond();
                                    }, 1000);

                                    function countSeccond() {
                                        var send = Number(diemdanh_thoigian.innerHTML);
                                        if (send <= 0) {
                                            return;
                                        }
                                        $("#diemdanh_thoigian").text(send - 1);
                                        $("#diemdanh_time").text(send - 1);
                                    }

                                    function attendance() {
                                        var phone = $("#phoneattendance").val();
                                        $.ajax({
                                            type: "POST",
                                            url: "/api/public/attendance",
                                            data: {
                                                phone
                                            },
                                            success: function(result1) {
                                                result = JSON.parse(result1);
                                                document.getElementById("submit").disabled = false;
                                                if (result.status == 'success') {
                                                    alert(result.msg);
                                                } else {
                                                    alert(result.msg);
                                                }
                                            },
                                        });
                                    }
                                </script>
                                <!-- <script src="js/muster.js"></script> -->
                                <style>
                                    #day_mission_querying {
                                        margin-top: 0.5rem;
                                        color: #155724;
                                        background-color: #9cbca4;
                                        border-color: #c3e6cb;
                                        padding: 20px;
                                    }
                                </style>
                                <div class="panel-body game" style="padding-top: 10px; padding-bottom: 20px;" game-tab="day_mission">
                                    <div class="body">
                                        <div class="text-center">
                                            <font color="blue">
                                                <big><b>Nhiệm Vụ Ngày</b></big>
                                            </font>
                                            <br>
                                            <div class="form-group" id="non_query" style="background-color: #7ee2ff; border-color: #ad4105; padding: 20px;">
                                                <label for="partnerId">Số điện thoại:</label>
                                                <input type="text" class="form-control" name="partnerId" id="PhoneChoi" aria-describedby="partnerId" placeholder="094xxxxxxx">
                                                <small id="partnerId" class="form-text text-muted">Nhập số điện thoại (đầu số cũ) của bạn để kiểm tra và nhận thưởng.</small> <br>
                                                <button class="btn btn-success check-day-mission" onclick="getPhoneAmount()">Kiểm Tra</button>
                                                <p>Tổng tiền Nhiệm Vụ Ngày đã trao: <b id="total_reward" style="color: blue;"><?= format_cash($landmark['sum_bonus']); ?></b>
                                                    <font style="color: blue;">VNĐ</font>
                                                </p>
                                            </div>
                                            <div class="form-group" id="query_done" style="display: none;"></div>
                                            <div class="form-group bg-warning" id="day_mission_querying" style="display: none;">Đang truy vấn... xin chờ nhé...
                                            </div>
                                        </div>
                                        <div class="day_mission" style="background-color: #7ee2ff; border-color: #ad4105; padding: 20px;">
                                            - Thật tuyệt vời ! Mỗi ngày chỉ cần chơi trên <b class="text-success"><?= ucfirst($_SERVER['SERVER_NAME']); ?></b> chắc chắn bạn
                                            sẽ nhận được tiền. <br>
                                            - Khi chơi đủ số tiền (ko cần biết thắng thua) chắc chắn sẽ nhận được tiền.
                                            <br>
                                            - Hãy nhập số điện thoại của bạn vào mục bên trên để kiểm tra đã chơi bao
                                            nhiêu nhé. Chú ý : Phải nhập sdt
                                            là số cũ vd: 082xxx -&gt; 0129xxx , 03xxx -&gt; 016... <br>
                                            - Khi chơi đủ mốc tiền, các bạn ấn vào nhận thưởng để nhận được các mốc như
                                            sau:
                                            <div class="table-responsive">
                                                <table class="table table-striped table-bordered table-hover text-center">
                                                    <thead>
                                                        <tr role="row" class="bg-primary">
                                                            <th class="text-center text-white">Mốc chơi</th>
                                                            <th class="text-center text-white">Thưởng</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="tbody_day_mission">
                                                        <tr>
                                                            <td><?= format_cash($landmark['top1']); ?></td>
                                                            <td><?= format_cash($day_mission_bonus['top1']); ?> đ</td>
                                                        </tr>
                                                        <tr>
                                                            <td><?= format_cash($landmark['top2']); ?></td>
                                                            <td><?= format_cash($day_mission_bonus['top2']); ?> đ</td>
                                                        </tr>
                                                        <tr>
                                                            <td><?= format_cash($landmark['top3']); ?></td>
                                                            <td><?= format_cash($day_mission_bonus['top3']); ?> đ</td>
                                                        </tr>
                                                        <tr>
                                                            <td><?= format_cash($landmark['top4']); ?></td>
                                                            <td><?= format_cash($day_mission_bonus['top4']); ?> đ</td>
                                                        </tr>
                                                        <tr>
                                                            <td><?= format_cash($landmark['top5']); ?></td>
                                                            <td><?= format_cash($day_mission_bonus['top5']); ?> đ</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <script>
                                    function getPhoneAmount() {
                                        $('#day_mission_querying').show();
                                        var phone = $("#PhoneChoi").val();
                                        $.ajax({
                                            type: "POST",
                                            url: "/api/public/daymiss",
                                            data: {
                                                phone
                                            },
                                            success: function(result1) {
                                                result = JSON.parse(result1);
                                                $('#day_mission_querying').hide();
                                                $("#query_done").show();
                                                if (result.status == 'success') {
                                                    $("#query_done").attr("class", "").addClass("alert alert-success").html(result.msg);
                                                } else {
                                                    $("#query_done").attr("class", "").addClass("alert alert-danger").html(result.msg);
                                                }
                                            },
                                        });
                                    }

                                    function NhanQuaNgay() {
                                        let phone = $("#partnerId").val();
                                        if (phone.length <= 9) {
                                            alert('Số điện thoại không hợp lệ');
                                            return false;
                                        }
                                        $("#non_query").hide();
                                        $("#day_mission_querying").hide();
                                        $.ajax({
                                            url: '/api/public/daymiss',
                                            data: {
                                                phone: phone
                                            },
                                            type: 'POST',
                                            success: function(result1) {
                                                result = JSON.parse(result1);
                                                $("#day_mission_querying").show();
                                                $("#day_mission_querying").html(result.msg);
                                            }
                                        })
                                    }
                                </script>
                                <div class="panel-body game" style="padding-top: 10px; padding-bottom: 20px;" game-tab="giftcode">
                                    <style>
                                        #diemDanhCard {
                                            margin-top: 0.5rem;
                                            color: #155724;
                                            border-color: #c3e6cb;
                                        }

                                        #occard {
                                            margin-top: 0.5rem;
                                            color: #155724;
                                            background-color: #9cbca4;
                                            border-color: #c3e6cb;
                                            padding: 20px;
                                        }

                                        .occho {
                                            margin-top: 0.5rem;
                                            color: #155724;
                                            background-color: #aed6b8;
                                            border-color: #c3e6cb;
                                            padding: 20px;
                                        }
                                    </style>
                                    <div class="row collapse show" id="diemDanhCard" style="">
                                        <div class="col-lg-12">
                                            <div class="body">
                                                <div class="text-center">
                                                    <p style="line-height: 0.8;"></p>
                                                    <p style="font-size:120%;text-align:center;"><b>CODE KHUYẾN MẠI</b>
                                                    </p>
                                                    <div class="form-group" id="non_query" style="background-color: #7ee2ff; border-color: #ad4105; padding: 20px;">
                                                        <label for="partnerId">Mã code:</label>
                                                        <input type="text" class="form-control" name="giftcode" id="giftcode" placeholder="ABCXYZ">
                                                        <label for="partnerId" style="margin-top: 10px;">Số điện
                                                            thoại:</label>
                                                        <input type="text" class="form-control" name="phoneCode" id="phoneCode" placeholder="094xxxxxxx">
                                                        <small id="partnerId" class="form-text text-muted" style="color: #ff0000">Nhập số điện thoại của
                                                            bạn để kiểm tra và
                                                            nhận
                                                            thưởng.</small> <br>
                                                        <button type="submit" class="btn btn-success" onclick="check_Giftcode()">Kiểm Tra</button>
                                                    </div>
                                                    <div class="form-group" id="query_done" style="display: none;">
                                                    </div>
                                                    <div class="form-group bg-warning" id="day_mission_querying" style="display: none;">Đang truy vấn...
                                                        xin chờ
                                                        nhé...
                                                    </div>
                                                    <div class="occho" id="muc_huongdan">
                                                        1. Một số điện thoại chỉ được nhập 1 mã/ngày. <br>
                                                        2. Mã code khuyến mại sẽ tùy vào điều kiện để sử dụng, có thời
                                                        hạn. <br>
                                                        3. Mã code khuyến mại sẽ được cấp theo các chương trình khuyến
                                                        mại của hệ thống Momo Lô Tô. <br>
                                                        4. Vui lòng liên hệ chát CSKH để biết thêm chi tết khi bạn nhận
                                                        được CODE. <br>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <script>
                                    function check_Giftcode() {
                                        let phone = $("#phoneCode").val();
                                        let code = $("#giftcode").val();
                                        if (phone.length <= 9) {
                                            alert('Số điện thoại không hợp lệ');
                                            return false;
                                        }
                                        $("#non_query").hide();
                                        $("#day_mission_querying").show();
                                        $.ajax({
                                            url: '/api/public/checkcode',
                                            data: {
                                                phone: phone,
                                                code: code
                                            },
                                            type: 'POST',
                                            success: function(result1) {
                                                result = JSON.parse(result1);
                                                if (result.status == 'success') {
                                                    alert(result.msg);
                                                    $("#non_query").show();
                                                    $("#day_mission_querying").hide();
                                                } else {
                                                    alert(result.msg);
                                                    $("#non_query").show();
                                                    $("#day_mission_querying").hide();
                                                }
                                            }
                                        })
                                    }
                                </script>
                            </div>
                        </div>
                    </div>


                    <!-- Kiểm tra mã giao dịch -->
                    <div class="col-md-6 mt-3 cl">
                        <div class="panel panel-primary">
                            <div class="panel-heading text-center">
                                TRẠNG THÁI MOMO
                           </div>
                                            <div class="panel-body text-center">
                                         <center><b>Lưu ý: Khi đạt 120 GD hoặc 40 triệu sẽ tự đổi số.</center>
                 <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover text-center">
                      <thead>
                        <tr role="row" class="bg-primary">
                          <th class="text-center text-white">Số điện thoại</th>
                          <th class="text-center text-white">Trạng thái</th>
                          <th class="text-center text-white">Số lần</th>
                          <th class="text-center text-white">GD ngày</th>
                        </tr>
                                    </thead>
                                    <tbody id="momo-status">
                                        <?php
                                            $list = $soicoder->fetch_assoc("SELECT `id`, `phone`, `DataJson`, `receive_day`, `today_gd`  FROM `cron_momo` WHERE `pay` = 'on' LIMIT 1000", 0);
                                            foreach ($list as $data) {
                                                $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                // print_r($info_chuyentien)
                                                $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                if ($sum_chuyentien > 49000000) {
                                                    continue;
                                                }
                                                if ($sum_gd > 195) {
                                                    continue;
                                                }
                                            ?><tr>
      <td id="p_1060"><b id="since04_1060" style="
position: relative;
                                            "><?=$data['phone'];?> <b style="position: absolute;
top: 17px;
/* left: 1%; */
/* margin: auto; */
margin-left: auto;
margin-right: auto;
left: 0;
right: 0;
text-align: center;
font-size: 9px;"> <font color="green"><?=format_cash($sum_chuyentien);?></font>/<font color="6861b1">30M</font>|<font color="green"><?=format_cash($sum_gd);?></font>/<font color="6861b1">150</font></b>
                                                                </b><span class="label label-success text-uppercase" onclick="coppy('<?=$data['phone'];?>')"><i class="fa fa-clipboard" aria-hidden="true"></i></span>
                                            <td><span class="label label-success text-uppercase">Hoạt động</span></td>
                                            <td><span class="text-danger"><?=$sum_gd;?></span></td>
                                            <td><span class="text-danger cash-format"><?=($sum_chuyentien);?>&nbsp;</span></td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                             
                  </div>
                                <div class="alert text-left">
                                </div>
                                <div class="text-center">
                                    <div class="form-group">
                                        <label for="check-trans">Nhập mã giao dịch</label>
                                        <input type="number" class="form-control" id="tran_id" placeholder="Vd: 123456xxx">
                                    </div>
                                    <button id="submit" class="btn btn-primarsy mb-2 check-tran" onclick="check_tranid()">Kiểm tra</button>
                                    <div style="margin-top: 5px;">
                                    </div>
                                </div>
                                <div id="result-check" class="alert alert-danger"><small id="emailHelp" class="form-text text-muted">Nếu quá 10' chưa nhận được tiền vui lòng dán mã vào đây kiểm tra.</small></div>
                                <script>
                                    function check_tranid() {
                                        var tran_id = $("#tran_id").val();
                                        $.ajax({
                                            type: "POST",
                                            url: "/api/public/lichsu",
                                            data: {
                                                tran_id
                                            },
                                            success: function(result1) {
                                                result = JSON.parse(result1);
                                                document.getElementById("submit").disabled = false;
                                                if (result.status == 'success') {
                                                    $("#result-check").attr("class", "").addClass("alert alert-success").html(result.msg);
                                                } else {
                                                    $("#result-check").attr("class", "").addClass("alert alert-danger").html(result.msg);
                                                }
                                            },
                                        });
                                
                                    }
                                </script>
                                
                                <div id="contact" class="mt-5">
                                    <p>
                                        <a class="text-white" href="<?= $setting['tele']; ?>" target="_blank">
                                            <span class="btn btn-success text-uppercase">SUPPORT TELEGRAM</span>
                                        </a>
                                    </p>
                                    <p>
                                        <a class="text-white" href="<?= $setting['box_zalo']; ?>" target="_blank">
                                            <span class="btn btn-success text-uppercase">BOX ZALO</span>
                                        </a>
                                    </p>
                                    <p>
                                        <a class="text-white" href="<?= $setting['video']; ?>" target="_blank">
                                            <span class="btn btn-success text-uppercase">Video Hướng Dẫn Chơi</span>
                                        </a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mt-5 text-center ">
                    <div class="row">
                        <div class="col-md-12 mt-3">
                            <div class="text-center mb-3">
                                <h3 class="text-uppercase">
                                    Lịch sử tham gia
                                </h3>
                            </div>
                            <!--<div class="text-center font-weight-bold m-3"><b>Làm mới sau <span class="text-danger coundown-time">9</span> s</b></div>-->
                            <center class="" style="width: 76%;margin: auto;">
                                <marquee>
                                    <b id="msg_history_hu"></b>
                                </marquee>
                            </center>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover text-center">
                                    <thead>
                                        <tr class="bg-primary" role="row">
                                        <th class="text-center text-white">Số điện thoại</th>
                                        <th class="text-center text-white">Tiền cược</th>
                                        <th class="text-center text-white">Tiền nhận</th>
                                        <th class="text-center text-white">Trò chơi</th>
                                        <th class="text-center text-white">Nội dung </th>
                                        <th class="text-center text-white">Trạng thái</th>
                                        </tr>
                                </thead>
                                <tbody role="alert" aria-live="polite" aria-relevant="all" class="history-table">
                                    <?php
                                    $list = $soicoder->fetch_assoc("SELECT * FROM `lich_su_choi` WHERE `result` = 'win' ORDER BY id desc LIMIT 10", 0);
                                    $list_game = array(
                                        'CL' => "Chẵn Lẻ",
                                        'CL2' => "Chẵn Lẻ 2",
                                        'TX' => "Tài Xỉu",
                                        'TX2' => "Tài Xỉu 2",
                                        '1P3' => "1 Phần 3",
                                        'G3' => "Gấp 3",
                                        'T3S' => "Tổng 3 Số",
                                        'H2S' => "H3"
                                    );
                                            $dem = 0;
                                            foreach ($list as $data) {
                                                $phone = $data['phone'];
                                        ?>
                                        
                                       <tr>
                                        <td>
                                            <span><?=substr($phone, 0, 7)."***";?></span>

                                        </td>
                                        <td><?=format_cash($data['amount_play']);?></td>
                                        <td><?=format_cash($data['result_number']);?></td>
                                        <td><?=$list_game[$data['game']];?></td>
                                        <td>
                                            <span class="fa-stack">
                                                <span class="fa fa-circle fa-stack-2x dot-text-<?=$dem++;?>">
                                                </span>
                                                <span class="fa-stack-1x text-white" id=""><b><?=$data['comment'];?></b>
                                                </span>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="label label-success text-uppercase">Thắng</span>
                                        </td>
                                    </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div><div class="text-center panel ">
                    <div class="row">
               <div class="col-md-6">
                    <div class="panel panel-danger">
                        <div class="panel-headings text-center">
                            <h4>Lưu Ý</h4>
                        </div>
                        <div class="panel-body"><h3 style="text-align: justify;"><strong><span style="color: #ff00ff;">Chào mừng bạn đến với <?=($_SERVER['SERVER_NAME']); ?>.</span></strong></h3>
<p style="text-align: justify;"><strong>Trước khi chơi, bạn nên đọc kĩ những lưu ý sau, nếu <span style="color: #ff0000;">bỏ qua</span> những lưu ý này, thì khi&nbsp;<span style="color: #ff0000;">mất tiền</span>, web sẽ <span style="color: #ff0000;">không chịu trách nhiệm</span>.</strong></p>
<p style="text-align: justify;"><strong>&nbsp; &nbsp; 1. Chẵn lẻ tài xỉu số cuối mã giao dịch là 0, 9 thua, nếu muốn tính 0 và 9 vui lòng chơi chẵn lẻ 2.</strong></p>
<p style="text-align: justify;"><strong>&nbsp; &nbsp; 2. Mỗi số chỉ có thể giao dịch tối đa 50tr hoặc 150 lần một ngày. Vì vậy,&nbsp;<span style="color: #ff0000;">số trên hệ thống&nbsp;sẽ thay đổi liên tục </span></strong><strong>nên&nbsp;trước khi chơi bạn nên lên lấy số trước, tránh việc bị hoàn tiền.</strong></p>
<p style="text-align: justify;"><strong>&nbsp; &nbsp; 3. Mỗi số có một mức cược khác nhau, n</strong><strong>ếu chuyển sai hạn mức, sai nội dung,&nbsp;số ngừng hoạt động, hãy sử dụng chức năng&nbsp;KIỂM TRA MÃ GIAO DỊCH để được&nbsp;nhận lại tiền chơi .</strong></p>
<p style="text-align: justify;"><em><span style="color: #ff0000;"><strong>&nbsp; &nbsp; &nbsp; - Tất cả các mã giao dịch chỉ được hỗ trợ trong ngày nha ae!</strong></span></em></p>
<p style="text-align: justify;"><strong>&nbsp; &nbsp; 4.&nbsp;Nếu gặp các vấn đề khác nữa thì bạn hãy click vào icon chát ở&nbsp;góc phải màn hình để liên hệ hỗ trợ. (24/7).</strong></p>
<p style="text-align: center;"><span style="color: #800000;"><em><strong>Khi bạn tắt chú ý này đi, đồng nghĩa với việc bạn đã đọc và chấp nhận những điều đó!</strong></em></span></p></div>
                    </div>
                </div>
               
               <div class="col-md-6">
                        <div class="panel-headings text-center">
                                    <h4>TOP THẮNG TUẦN </h4>
                                </div>
                     <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover text-center">
                                <tbody role="alert" aria-live="polite" aria-relevant="all" id="week_top" class="text-center">
                                    <?php
                                        if ($setting['topfake'] == 'on') {
                                        ?>
                                    <tr>
                                        <td><span class="fa-stack"> <span class="fa fa-circle fa-stack-2x text-danger"></span><strong class="fa-stack-1x text-white">1</strong></span></td>
                                        <td class="col-xs-2"><span class="label "><font color="black"><?=substr($sdt_fake['top1'], 0, 6);?>****</font></span></td>
                                        <td class="col-xs-5 text-center"><span class="label"><font color="black"><?=($top_fake['top1']);?>&nbsp;₫</font></span></td>
                                        <td class="col-xs-5 text-center"><span class="label "><font color="red">+<?=format_cash($top['top1']);?>&nbsp;</font><font color="black">Momo</font></span></td>
                                    </tr>
                                    <tr>
                                        <td><span class="fa-stack"> <span class="fa fa-circle fa-stack-2x text-danger"></span><strong class="fa-stack-1x text-white">2</strong></span></td>
                                        <td class="col-xs-2"><span class="label "><font color="black"><?=substr($sdt_fake['top2'], 0, 6);?>****</font></span></td>
                                        <td class="col-xs-5 text-center"><span class="label "><font color="black"><?=($top_fake['top2']);?>&nbsp;₫</font></span></td>
                                         <td class="col-xs-5 text-center"><span class="label "><font color="red">+<?=format_cash($top['top2']);?>&nbsp;</font><font color="black">Momo</font></span></td>
                                    </tr>
                                    <tr>
                                        <td><span class="fa-stack"> <span class="fa fa-circle fa-stack-2x text-danger"></span><strong class="fa-stack-1x text-white">3</strong></span></td>
                                        <td class="col-xs-2"><span class="label "><font color="black"><?=substr($sdt_fake['top3'], 0, 6);?>****</font></span></td>
                                        <td class="col-xs-5 text-center"><span class=" label"><font color="black"><?=($top_fake['top3']);?>&nbsp;₫</font></span></td>
                                         <td class="col-xs-5 text-center"><span class="label "><font color="red">+<?=format_cash($top['top3']);?>&nbsp;</font><font color="black">Momo</font></span></td>
                                    </tr>
                                    <tr>
                                        <td><span class="fa-stack"> <span class="fa fa-circle fa-stack-2x text-danger"></span><strong class="fa-stack-1x text-white">4</strong></span></td>
                                        <td class="col-xs-2"><span class="label "><font color="black"><?=substr($sdt_fake['top4'], 0, 6);?>****</font></span></td>
                                        <td class="col-xs-5 text-center"><span class=" label"><font color="black"><?=($top_fake['top4']);?>&nbsp;₫</font></span></td>
                                        <td class="col-xs-5 text-center"><span class="label "><font color="red">+<?=format_cash($top['top4']);?>&nbsp;</font><font color="black">Momo</font></span></td>
                                    </tr>
                                    <tr>
                                        <td><span class="fa-stack"> <span class="fa fa-circle fa-stack-2x text-danger"></span><strong class="fa-stack-1x text-white">5</strong></span></td>
                                        <td class="col-xs-2"><span class="label"><font color="black"><?=substr($sdt_fake['top5'], 0, 6);?>****</font></span></td>
                                        <td class="col-xs-5 text-center"><span class=" label"><font color="black"><?=($top_fake['top5']);?>&nbsp;₫</font></span></td>
                                        <td class="col-xs-5 text-center"><span class="label "><font color="red">+<?=format_cash($top['top5']);?>&nbsp;</font><font color="black">Momo</font></span></td>
                                    </tr>
                                    <?php } else {
                                        $list = $soicoder->fetch_assoc("SELECT DISTINCT `phone` FROM `lich_su_choi` " , 0);
                                        $i = 0;
                                        $list_top = [];
                                        foreach ($list as $data) {
                                            $phone = $data['phone'];
                                            if (!is_numeric($phone)) { continue; }
                                            $topreal = $soicoder->fetch_assoc("SELECT SUM(`amount_play`),SUM(`result_number`) FROM `lich_su_choi` WHERE `amount_play` >= 0 AND `result_number` >= 0 AND `time` >= '".(time() - 604800)."' AND `phone` =  '".$phone."' ORDER BY 'SUM(`amount_play`)' desc" , 1);
                                            $list_top[$phone] = $topreal['SUM(`amount_play`)'];
                                        }
                                        arsort($list_top);
                                        $dem = 0;
                                        foreach($list_top as $phone => $amount_play) {
                                            $dem++;
                                            if ($dem > 5) { break; }
                                        ?>
                                        <tr>
                                            <td><span class="fa-stack"> <span class="fa fa-circle fa-stack-2x text-danger"></span><strong class="fa-stack-1x text-white"><?=$dem;?></strong></span></td>
                                            <td class="col-xs-2"><span class="label "><font color="black"><?=substr($phone, 0, 6);?>****</font></span></td>
                                            <td class="col-xs-5 text-center"><span class="label "><font color="black"><?=format_cash($amount_play);?>&nbsp;₫</font></span></td>
                                            <td class="col-xs-5 text-center"><span class="label "><font color="red">+<?=format_cash($top['top'.$dem]);?>&nbsp;</font><font color="black">MoMo</font></span></td>
                                        </tr>
                                    <?php }} ?>
                                </tbody>
                            </table>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                <div class="mt-5 panel panel-primary">
               <div class="panel-heading text-center">
                  <h4>GIỚI THIỆU</h4>
               </div>
               <div class="panel-body">
                  <div class="footer-descriptopm">
                     <p><strong>Chẵn lẻ Momo</strong><span style="font-weight: 400;"> là một loại trò chơi giải trí, Có thể giúp bạn kiếm tiền nhanh chóng chỉ sau vài thao tác trên momo.&nbsp;</span></p>
                     <p><span style="font-weight: 400;">Chẵn lẻ momo thuộc loại trò chơi cá cược và hiện đang khá là phổ biến trong giới trẻ hiện nay bởi tính minh bạch, xanh chín của nó.</span><a href="../"><span style="font-weight: 400;"> Chơi chẵn lẻ trên momo</span></a><span style="font-weight: 400;"> (CLMM) là trò chơi cá cược chuyển tiền dựa trên mã giao dịch kết thúc trong Ví Momo.</span></p>
                     <p><span style="font-weight: 400;">Các bạn sẽ có những lựa chọn chẵn hoặc lẻ, tài hoặc xỉu để điền vào nội dung lúc chuyển khoản.&nbsp;</span></p>
                     <p><span style="font-weight: 400;">Nếu đoán đúng, các bạn sẽ nhận được tiền từ hệ thống tự động chuyển khoản lại ngay sau đó 5s - 10s. Số tiền thưởng sẽ bằng số tiền cược nhân với tỉ lệ cược do website quy định. Nếu dự đoán sai, các bạn sẽ bị mất số tiền đã đặt cược.</span></p>
                     <h3><strong>Một vài lưu ý sơ lược về Chẵn Lẻ Momo (Viết tắt là Clmm) mà bạn cần biết đến:</strong></h3>
                     <ul>
                        <li style="font-weight: 400;" aria-level="1"><strong>Số bình thường:</strong><span style="font-weight: 400;"> (Tốc độ trả thưởng là 4s) là số đang hiển thị ở trên web, </span><strong>Mỗi momo sẽ có 120 lần trả thưởng và 40 triệu/1 ngày</strong><span style="font-weight: 400;">. Khi đạt đến ngưỡng mức trong ngày web sẽ tắt đi và bật số mới.</span></li>
                     </ul>
                     <p><span style="font-weight: 400;">GIẢI THÍCH CÁC TRẠNG THÁI KHI CÁC BẠN SỬ DỤNG TÍNH NĂNG CHECK MÃ:</span></p>
                     <ul>
                        <li style="font-weight: 400;" aria-level="1"><strong>Số đang hoạt động</strong><span style="font-weight: 400;"> : Là số vẫn còn ở trên web nhưng giao dịch này bị lag hãy </span><strong>Liên hệ ADMIN</strong><span style="font-weight: 400;"> ở góc phải web nhé bạn</span></li>
                        <li style="font-weight: 400;" aria-level="1"><strong>Giao đang được xử lý vui lòng đợi 1 - 7p: </strong><span style="font-weight: 400;">Lỗi này do tài khoản Momo bị lag bạn chỉ cần đợi vài phút hệ thống sẽ tự đổi số khác và thanh toán cho bạn</span></li>
                        <li style="font-weight: 400;" aria-level="1"><strong>Tài khoản hết tiền:</strong><span style="font-weight: 400;">&nbsp; Nếu đang chơi khi check mã hệ thống báo bị lỗi này thì đừng lo, Do số Momo đó bị hết tiền, Hệ thống sẽ tự đổi số khác và thanh toán cho bạn, Không việc gì phải lo lắng cả nhé.</span></li>
                        <li style="font-weight: 400;" aria-level="1"><strong>Hoàn tiền quá lâu:</strong><span style="font-weight: 400;"> Khuyến khích các bạn chơi khi gặp bất kể vấn đề gì về thanh toán vui lòng: </span><strong>“Liên hệ admin góc phải ” </strong><span style="font-weight: 400;">(Lưu ý: Phải đọc kỹ luật chơi và check mã trước khi báo lỗi, Vì hiện tại web chạy rất mượt đa phần các bạn báo lỗi ở đây là do Nhầm lẫn chơi C - L không có 0 và 9 nhưng khi ra 0 hoặc 9 thì các bạn lại nghĩ rằng mình thắng và đi báo lỗi @@)</span></li>
                     </ul>
                     <h3><strong>Những điểm mạnh lợi ích khi bạn chơi Chẵn lẻ MoMo (CLMM):</strong></h3>
                     <ul>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Là loại mini game với lối chơi cực kỳ đơn giản, dễ hiểu , kiếm tiền ăn triệu mỗi ngày</span></li>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Nhận thưởng nhanh chỉ khoảng tầm 3 - 15 giây tối đa</span></li>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Là game xanh chín nhất trong các loại game cá cược, dự đoán số</span></li>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Có thể chơi mọi lúc, mọi nơi, chỉ cần bạn có tài khoản momo là chơi được video phía dưới màn hình</span></li>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Cho bạn cảm giác hấp dẫn gây cấn khi chơi game tạo cảm giác mạnh thể thao mạo hiểm phiên bản online nhập vai</span></li>
                     </ul>
                     <h3><strong>Khuyết điểm game Chẵn lẻ momo (CLMM):</strong></h3>
                     <ul>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Là thể loại game chơi mới nên chưa phổ biến rộng rãi</span></li>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Người chơi thể loại game chẵn lẻ momo đa phần là dân buôn và dân game thủ</span></li>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Nhiều website lừa đảo tạo ra nhưng không trả thưởng cho người chơi.</span></li>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Chơi chẵn lẻ momo thuộc thể loại game cờ bạc online, chưa được nhà nước công nhận</span></li>
                     </ul>
                     <h3><strong>Hướng dẫn chơi chẵn lẻ tài xỉu bằng tài khoản Momo:</strong></h3>
                     <ul>
                        <li style="font-weight: 400;" aria-level="1"><strong>Bước 1:</strong><span style="font-weight: 400;"> Các bạn truy cập vào trang chủ website TrumMoMo.Com, ngay phía dưới logo có các thể loại game "Chẵn lẻ", "Chẵn lẻ 2", "Tài xỉu", "Tài xỉu 2", "1 phần 3", “Tổng 3 số”,"G3", "H3",&nbsp; “Lô”&nbsp; ae ấn chọn 1 trong số các game đó để chơi, ví dụ: Chẵn lẻ.</span></li>
                        <li style="font-weight: 400;" aria-level="1"><strong>Bước 2:</strong><span style="font-weight: 400;"> Sau khi ấn chọn game chẵn lẻ, thì bên dưới sẽ hiển thị hướng dẫn chơi và các sđt nhận tiền cược. ae chọn coppy 1 momo bất kỳ trong các số đó, và lưu ý ngay bên cạnh các sđt đó có ghi mức cược tối thiểu, và cược tối đa mà ae có thể cược. như hiện tại đối với </span><strong>trò chẵn lẻ momo</strong><span style="font-weight: 400;"> thì mức cược</span><strong> Tối thiểu là 5.000 VNĐ</strong><span style="font-weight: 400;"> và mức cược </span><strong>Tối đa là 2.000.000 VNĐ.</strong></li>
                        <li style="font-weight: 400;" aria-level="1"><strong>Bước 3:</strong><span style="font-weight: 400;"> Sau khi coppy SĐT, ae xem kỹ nội dung chuyển tương đương với sự lựa chọn, dự đoán của ae cho số cuối của mã giao dịch.</span></li>
                     </ul>
                     <p>&nbsp;</p>
                     <p>&nbsp;</p>
                     <ul>
                        <li aria-level="1"><strong>CHẴN LẺ</strong></li>
                     </ul>
                     <p>&nbsp;</p>
                     <ul>
                        <li style="font-weight: 400;" aria-level="1"><strong>(C):</strong><span style="font-weight: 400;"> 2 - 4 - 6 - 8</span></li>
                        <li style="font-weight: 400;" aria-level="1"><strong>(L):</strong><span style="font-weight: 400;"> 1 - 3 - 5 - 7</span></li>
                     </ul>
                     <ul>
                        <li style="font-weight: 400;" aria-level="2"><strong>Thưởng:</strong><span style="font-weight: 400;"> x2.35 </span><strong>Tiền đặt cược</strong></li>
                     </ul>
                     <p>&nbsp;</p>
                     <p>&nbsp;</p>
                     <ul>
                        <li aria-level="1"><strong>CHẴN LẺ 2</strong></li>
                     </ul>
                     <p>&nbsp;</p>
                     <ul>
                        <li style="font-weight: 400;" aria-level="1"><strong>(C):</strong><span style="font-weight: 400;"> 0 - 2 - 4 - 6 - 8</span></li>
                        <li style="font-weight: 400;" aria-level="1"><strong>(L):</strong><span style="font-weight: 400;"> 1 - 3 - 5 - 7 - 9</span></li>
                     </ul>
                     <ul>
                        <li style="font-weight: 400;" aria-level="2"><strong>Thưởng:</strong><span style="font-weight: 400;"> x1.96 </span><strong>Tiền đặt cược</strong></li>
                     </ul>
                     <p style="text-align: center;">&nbsp;</p>
                     <p>&nbsp;</p>
                     <ul>
                        <li aria-level="1"><strong>TÀI XỈU</strong></li>
                     </ul>
                     <p>&nbsp;</p>
                     <ul>
                        <li style="font-weight: 400;" aria-level="1"><strong>Tài (T):</strong><span style="font-weight: 400;"> 5 - 6 - 7 - 8</span></li>
                        <li style="font-weight: 400;" aria-level="1"><strong>Xỉu (X):</strong><span style="font-weight: 400;"> 1 - 2 - 3 - 4</span></li>
                     </ul>
                     <ul>
                        <li style="font-weight: 400;" aria-level="2"><strong>Thưởng:</strong><span style="font-weight: 400;"> x2.35 </span><strong>Tiền đặt cược&nbsp;&nbsp;</strong></li>
                     </ul>
                     <p style="text-align: center;">&nbsp;</p>
                     <p>&nbsp;</p>
                     <ul>
                        <li aria-level="1"><strong>TÀI XỈU 2</strong></li>
                     </ul>
                     <p>&nbsp;</p>
                     <ul>
                        <li style="font-weight: 400;" aria-level="1"><strong>Tài (T2):</strong><span style="font-weight: 400;"> 5 - 6 - 7 - 8 - 9</span></li>
                        <li style="font-weight: 400;" aria-level="1"><strong>Xỉu (X2):</strong><span style="font-weight: 400;"> 0 - 1 - 2 - 3 - 4</span></li>
                     </ul>
                     <ul>
                        <li style="font-weight: 400;" aria-level="2"><strong>Thưởng:</strong><span style="font-weight: 400;"> x1.96 </span><strong>Tiền đặt cược&nbsp;&nbsp;</strong></li>
                     </ul>
                     <p style="text-align: center;">&nbsp;</p>
                     <p>&nbsp;</p>
                     <ul>
                        <li aria-level="1"><strong>1 PHẦN 3</strong></li>
                     </ul>
                     <p>&nbsp;</p>
                     <ul>
                        <li style="font-weight: 400;" aria-level="1"><strong>(N1):</strong><span style="font-weight: 400;"> 1 2 3</span></li>
                        <li style="font-weight: 400;" aria-level="1"><strong>(N2):</strong><span style="font-weight: 400;"> 4 5 6</span></li>
                        <li style="font-weight: 400;" aria-level="1"><strong>(N3):</strong><span style="font-weight: 400;"> 7 8 9</span><strong>&nbsp;</strong></li>
                     </ul>
                     <ul>
                        <li style="font-weight: 400;" aria-level="2"><strong>Thưởng:</strong><span style="font-weight: 400;"> x3 </span><strong>Tiền đặt cược</strong></li>
                     </ul>
                     <p style="text-align: center;">&nbsp;</p>
                     <p>&nbsp;</p>
                     <ul>
                        <li aria-level="1"><strong>TỔNG 3 SỐ</strong></li>
                     </ul>
                     <p>&nbsp;</p>
                     <ul>
                        <li style="font-weight: 400;" aria-level="1"><strong>(S):</strong><span style="font-weight: 400;"> 7 - 17 - 27&nbsp; &nbsp; Thưởng x2 </span><strong>Tiền đặt cược&nbsp;</strong></li>
                        <li style="font-weight: 400;" aria-level="1"><strong>(S):</strong><span style="font-weight: 400;"> 2 - 18&nbsp; &nbsp; Thưởng x3 </span><strong>Tiền đặt cược&nbsp;&nbsp;</strong></li>
                        <li style="font-weight: 400;" aria-level="1"><strong>(S):</strong><span style="font-weight: 400;"> 9 - 19&nbsp; &nbsp; Thưởng x4 </span><strong>Tiền đặt cược&nbsp;&nbsp;</strong></li>
                     </ul>
                     <p><strong>NGOÀI RA WEB CÒN RẤT NHIỀU MINI GAME KHÁC CỦA CLMM ANH EM CÓ THỂ THAM KHẢO TRỰC TIẾP Ở TRÊN WEB, ĐÂY LÀ WEB CHƠI CHẴN LẺ MOMO UY TÍN (CLMM) VÀ TRAO THƯỞNG NHANH NHẤT HIỆN TẠI</strong></p>
                     <p style="text-align: center;">&nbsp;</p>
                     <p><strong>Ví dụ:</strong><span style="font-weight: 400;"> Bạn dự đoán số cuối mã giao dịch momo khả năng sẽ là số lẻ, Bạn chọn (L) thì coppy SĐT bất kỳ trong dãy SĐT bên trên rồi vào mục chuyển tiền trên momo, bạn muốn cược 100k phần nội dung chuyển khoản bạn gõ chữ L và ấn chuyển khoản.&nbsp;</span></p>
                     <p><span style="font-weight: 400;">Sau khi chuyển khoản xong, Bạn hãy xem mã giao dịch của bill chuyển khoản đó là gì, số cuối của mã giao dịch đó là chẵn hay lẻ, ví dụ nó là số 3, thì là lẻ mà bạn chọn L thì đợi khoảng 5 - 10s.</span></p>
                     <p><span style="font-weight: 400;">Bên hệ thống sẽ tự động chuyển lại với số tiền là 100k x 2,35 = 235.000đ, Nếu số cuối mã giao dịch k về như bạn nghĩ thì bạn mất số tiền cược đó.</span></p>
                     <h4><strong>Cách nhận thưởng “NHIỆM VỤ NGÀY” (nhận lộc lá ):</strong></h4>
                     <p><span style="font-weight: 400;">Đây là phần mục thưởng lộc cho bạn mỗi khi </span><strong>chơi chẵn lẻ momo</strong><span style="font-weight: 400;"> trên website. Khi chơi đủ số tiền (ko cần biết thắng thua), ae hãy nhập số điện thoại của ae vào để kiểm tra đã chơi bao nhiêu.&nbsp;</span></p>
                     <ul>
                        <li style="font-weight: 400;" aria-level="1"><strong>Chú ý:</strong><span style="font-weight: 400;"> Phải nhập sdt là đầu số cũ vd: 082xxx -&gt; 0129xxx , 03xxx -&gt; 016...</span></li>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Nếu Ae đạt nhiều mốc, thì Bạn load lại web nhập nhiều lần nhé, mỗi lần sẽ nhận thưởng theo từng mốc.</span></li>
                     </ul>
                     <h3><strong>Một số lưu ý cần thiết khi chơi chẵn lẻ momo :</strong></h3>
                     <ul>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Nội dung chuyển không phân biệt in hoa, thường. Nếu chuyển sai hạn mức hoặc sai nội dung, hoặc chuyển nhầm số bảo trì, vui lòng sử dụng chức năng “</span><strong>KIỂM TRA MÃ GIAO DỊCH</strong><span style="font-weight: 400;">” (Nhập mã giao dịch và SỐ ĐIỆN THOẠI của web mà bạn đã đánh) sau đó bấm hoàn tiền để được nhận lại tiền chơi</span></li>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Số MoMo nhận tiền thường xuyên được cập nhật, vì thế trước khi chơi hãy vào web để lấy đúng số, tránh bank nhầm.</span></li>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Chế độ "Chẵn lẻ" không tính số đuôi 0 và 9. Muốn có cả 2 thì bạn chọn qua chế độ "Chẵn lẻ 2" để chơi.</span></li>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Chế độ "Tài xỉu" không tính số đuôi 0 và 9. Muốn có cả 2 thì bạn chọn qua chế độ "Tài xỉu 2" để chơi.</span></li>
                        <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Nếu bạn chiến thắng, vui lòng chờ từ 10 - 20 giây hệ thống sẽ tự động chuyển trả thưởng cho bạn.</span><code></code></li>
                     </ul>
                  </div>
               </div>
            </div>
                <!-- <div id="hu-left-display"
                    style="position: fixed; bottom: 15px; left: 15px; z-index: 1000; cursor: pointer; width: 15%;"
                    class="hidden">
                    <div onclick="$('#hu-left-display').hide()" class="" style="left: 100%; position: absolute;">
                        <font color="red">
                            <big><b>[X]</b></big>
                        </font>
                    </div>
                    <b onclick="DUNGA.hu_click()">
                        <center><img class="animate__animated animate__heartBeat animate__infinite infinite"
                                src="/upload/files/hu.png" width="100%"
                                style="max-height: 130px;max-width: 150px;min-height: 50px; min-width:80px;"></center>
                        <div class="text-center">
                            <p class="animate__animated animate__shakeX animate__infinite infinite animate__slow 2 hu-balance"
                                style="border-top-right-radius: 30px; border-top-left-radius: 30px; border-radius: 30px; background: aquamarine;">
                                0</p>
                        </div>
                    </b>
                </div> -->
            </div>
        </div>
    </div>
    <footer class="footer">
        <!-- <script id="facebook-jssdk" src="https://connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js"></script> -->
        <!-- <script>
            var chatbox = document.getElementById('fb-customer-chat');
            chatbox.setAttribute("page_id", "107751992017864");
            chatbox.setAttribute("attribution", "biz_inbox");
        </script> -->

        <!-- Your SDK code -->
        <!-- <script>
            window.fbAsyncInit = function () {
                FB.init({
                    xfbml: true,
                    version: 'v14.0'
                });
            };

            (function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) return;
                js = d.createElement(s); js.id = id;
                js.src = 'https://connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js';
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script> -->
        <div class="container text-center">
            <div class="row">
                <div class="col-xs-12 text-white ">
                    Copyright 2022 © <?= $_SERVER['SERVER_NAME']; ?>
                </div>
            </div>
        </div>
    </footer>
<!-- noteModal -->

<!-- <div class="modal fade" id="noteModal" tabindex="-1" role="dialog" style="overflow: scroll; display: block; overflow-y: scroll" aria-hidden="false"> -->
        <div class="modal fade in" id="noteModal" tabindex="-1" role="dialog" aria-hidden="false" aria-labelledby="noteModalLabel"
        aria-hidden="true" style="display: block; overflow-y: scroll; animation: 3s;">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="noteModalLabel">Thông báo</h5>
                    <button type="button" class="close" onclick="$('#noteModal').hide();" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h3 style="text-align: justify;"><strong><span style="color: #ff00ff;">Chào mừng bạn đến với <?= strtoupper($_SERVER['SERVER_NAME']); ?>.</span></strong></h3>
                    <p style="text-align: justify;"><strong>Trước khi chơi, bạn nên đọc kĩ những lưu ý sau, nếu <span style="color: #ff0000;">bỏ qua</span> những lưu ý này, thì khi&nbsp;<span style="color: #ff0000;">mất tiền</span>, web sẽ <span style="color: #ff0000;">không chịu trách nhiệm</span>.</strong></p>
                    <p style="text-align: justify;"><strong>&nbsp; &nbsp; 1. Chẵn lẻ tài xỉu số cuối mã giao dịch là 0, 9 thua, nếu muốn tính 0 và 9 vui lòng chơi chẵn lẻ 2.</strong></p>
                    <p style="text-align: justify;"><strong>&nbsp; &nbsp; 2. Mỗi số chỉ có thể giao dịch tối đa 50tr hoặc 150 lần một ngày. Vì vậy,&nbsp;<span style="color: #ff0000;">số trên hệ thống&nbsp;sẽ thay đổi liên tục </span></strong><strong>nên&nbsp;trước khi chơi bạn nên lên lấy số trước, tránh việc bị mất tiền.</strong></p>
                    <p style="text-align: justify;"><strong>&nbsp; &nbsp; 3. Mỗi số có một mức cược khác nhau, nếu chuyển sai hạn mức, sai nội dung, số ngừng hoạt động sẽ mất tiền</strong></p>
                    <p style="text-align: justify;"><em><span style="color: #ff0000;"><strong>&nbsp; &nbsp; &nbsp; - Tất cả các mã giao dịch chỉ được hỗ trợ trong ngày nha ae!</strong></span></em></p>
                    <p style="text-align: justify;"><strong>&nbsp; &nbsp; 4.&nbsp;Nếu gặp các vấn đề khác nữa thì bạn hãy click vào phần hỗ trợ telegram hoặc Zalo để liên hệ hỗ trợ. (24/7).</strong></p>
                    <p style="text-align: center;"><span style="color: #800000;"><em><strong>Khi bạn tắt chú ý này đi, đồng nghĩa với việc bạn đã đọc và chấp nhận những điều đó!</strong></em></span></p>
                </div>
                
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="$('#noteModal').hide();" data-dismiss="modal">Đã hiểu</button>
                </div>
            </div>
        </div>
    </div>




    <!-- Hủ -->
    <div class="modal fade" id="hu-info" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">×</span></button>
                    <h3 class="modal-title"></h3>
                    <h2 class="text-danger"><b>NỔ HŨ GAME</b></h2>
                </div>
                <div class="modal-body" id="result_hu">
                    <center><img class="animate__animated animate__heartBeat animate__infinite infinite"
                            src="/upload/files/hu.png" width="30%" style=""></center>
                    1. Hệ thống tự động thêm vào hũ <b>66,666đ</b> sau khi người chơi được nổ hũ <br>
                    2. Người chơi sẽ được nổ hũ với điều kiện: <br>
                    - <b>Nổ 100% hũ:</b> Nếu 5 số cuối của mã giao dịch momo trùng nhau. <br>
                    - <b>Nổ 20% hũ:</b> Nếu 4 số cuối của mã giao dịch momo trùng nhau. <br>
                    - Ví dụ 1: Mã giao dịch <b>20235788888</b> có 5 số cuối là <b>88888</b> đều là <b>8</b>. <br>
                    + Người chơi sẽ ăn toàn bộ tiền trong hũ. <br>
                    - Ví dụ 2: Mã giao dịch <b>20235786666</b> có 4 số cuối là <b>6666</b> đều là <b>6</b>. <br>
                    + Người chơi sẽ ăn <b>20%</b> tiền trong hũ. <br>
                    3. Sau khi bạn được Nổ Hũ vui lòng LH chát <b>CSKH</b> gửi mã giao dịch để nhận tiền. <br>
                    (Lưu ý trương trình chỉ áp dụng trong ngày, qua ngày sẽ không được tính)
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" style="border-radius: 0;"
                        data-dismiss="modal">Đóng</button>
                </div>
            </div>
        </div>
    </div>
    <div id="player" class="hidden"></div>

    <script type="text/javascript" src="https://js.pusher.com/7.0/pusher.min.js" id="pusher-js"></script>
    <script src="js2/wheel.min.js?V2"></script>
    <script src="js2/jquery-1.10.1.min.js"></script>
    <script src="js2/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="js2/bootstrap.min.js"></script>
    <script src="js2/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-notify@0.5.5/dist/simple-notify.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/notify/0.4.2/notify.min.js" integrity="sha512-efUTj3HdSPwWJ9gjfGR71X9cvsrthIA78/Fvd/IN+fttQVy7XWkOAXb295j8B3cmm/kFKVxjiNYzKw9IQJHIuQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>

noti = function () {
            new Notify({
                status: 'success',
                title: 'Trò chơi: ',
                text: `Chúc mừng <b>${'09' + String(Math.floor(Math.random() * 100000))}****</b> đã thắng khi chơi ${number_format(Math.floor(Math.random() * 99) + '000')}`,
                autoclose: true,
                customIcon: '<svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 24 24" width="512" height="512"><path d="M19,9H14a5.006,5.006,0,0,0-5,5v5a5.006,5.006,0,0,0,5,5h5a5.006,5.006,0,0,0,5-5V14A5.006,5.006,0,0,0,19,9Zm-5,6a1,1,0,1,1,1-1A1,1,0,0,1,14,15Zm5,5a1,1,0,1,1,1-1A1,1,0,0,1,19,20ZM15.6,5,12.069,1.462A5.006,5.006,0,0,0,5,1.462L1.462,5a5.006,5.006,0,0,0,0,7.071L5,15.6a4.961,4.961,0,0,0,2,1.223V14a7.008,7.008,0,0,1,7-7h2.827A4.961,4.961,0,0,0,15.6,5ZM5,10A1,1,0,1,1,6,9,1,1,0,0,1,5,10ZM9,6a1,1,0,1,1,1-1A1,1,0,0,1,9,6Z"></path></svg>',
            })
        }
        setInterval(noti, 5000);
        
        </script>
    <script src="/js2/script.js?ver=28042003.v890">
    </script>
    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
    <script>$(document).ready(function () { $('.newfeed-modal').modal('show'); $('.newfeed-seen').click(function () { $.ajax({ url: './', data: { seen_newfeed: true, id_newfeed: '381', id_ctv: '105679' }, method: 'POST', beforeLoad: LOADER(true) }).done(function () { LOADER(false); $('.newfeed-modal').modal('hide'); }) }); })</script>
    <script>$(document).ready(function () { $('.newfeed-content img').each(function () { $(this).attr('data-mfp-src', $(this).attr('src')); }); $('.newfeed-content img').magnificPopup({ type: 'image', removalDelay: 300, mainClass: 'mfp-fade' }); });</script>
    <script>
        window.addEventListener('DOMContentLoaded', (event) => {
            $('[data-toggle="tooltip"]').tooltip();
            $('.cash-format').each(function (index) {
                $(this).html(parseInt($(this).text()).toLocaleString('it-IT', {
                    style: 'currency',
                    currency: 'VND'
                }));
            });
            $('button[data-game]').click(function () {
                let button = $(this);
                let game = button.attr('data-game');
                game_active = game;
                $('.game').removeClass('active');
                $(`.game[game-tab=${game}]`).addClass('active').removeClass("hidden");
                $("button[data-game]").removeClass("btn-info").addClass("btn-primary");
                $("[data-minigame]").removeClass("btn-success");
                button.removeClass("btn-primary").addClass("btn-info");
            });
            $('button[data-minigame]').click(function () {
                let button = $(this);
                let game = button.attr('data-minigame');
                game_active = "minigame";
                $('.game').removeClass('active');
                $(`.game[game-tab=${game}]`).addClass('active').removeClass("hidden");
                $("[data-minigame]").removeClass("btn-success");
                $("[data-game]").removeClass("btn-success").addClass("btn-primary");
                button.addClass("btn-success");
            });
        });
        function copyStringToClipboard(str) {
            // Create new element
            var el = document.createElement('textarea');
            // Set value (string to be copied)
            el.value = str;
            // Set non-editable to avoid focus and move outside of view
            el.setAttribute('readonly', '');
            el.style = {
                position: 'absolute',
                left: '-9999px'
            };
            document.body.appendChild(el);
            // Select text inside element
            el.select();
            // Copy text to clipboard
            document.execCommand('copy');
            // Remove temporary element
            document.body.removeChild(el);
        }

        function coppy(text) {
            copyStringToClipboard(text);
            alert('Đã sao chép số điện thoại này. Chúc bạn may mắn.');
        }
    </script>

    <div class="notifications-container notify-is-right notify-is-top" style="--distance:20px;"></div>
</body>

</html>