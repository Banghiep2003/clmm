<?php
class Session {
    public function start()
    {
        @session_start();
    }
    public function send($user)
    {
        $_SESSION['user'] = $user;
    }
    public function get($type) 
    {
        if (isset($_SESSION[''.$type.'']))
        {
            $user = $_SESSION[''.$type.''];
        }
        else
        {
            $user = '';
        }
        return $user;
    }
    public function destroy()
    {
        @session_destroy();
    }
}
 
?>