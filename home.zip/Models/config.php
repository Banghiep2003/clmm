<?php
define('SERVERNAME','localhost');
define('USERNAME','tclmm5swin_clmm');
define('PASSWORD','tclmm5swin_clmm');
define('DATABASE','tclmm5swin_clmm');
?>