<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) . '/Models/connect.php');
$list = $soicoder->fetch_assoc("SELECT `id`,`phone`, `DataJson`, `receive_day`, `today_gd`, `status`  FROM `cron_momo` WHERE `pay` = 'on' AND `status` = 'success' LIMIT 1000", 0);
// print_r($list);
// die;
if (count($list) == 0) {
    $data = $soicoder->fetch_assoc("SELECT * FROM `default` WHERE `id` = 1", 1)['data'];
} else {

    $data = $list[0]['DataJson'];
}
$config = json_decode($data, true);


// cài đặt chung
$setting = $soicoder->fetch_assoc("SELECT * FROM `settings` ", 1);
// điểm danh nhận quà
$attendance = $soicoder->fetch_assoc("SELECT * FROM `attendance` ", 1);
// top
$top_up = $soicoder->fetch_assoc("SELECT * FROM `top_up` ", 0);
$top = $top_up[0];
$sdt_fake = $top_up[1];
$top_fake = $top_up[2];
// nhiệm vụ ngày
$day_mission = $soicoder->fetch_assoc("SELECT * FROM `day_miss_up` ", 0);
$landmark = $day_mission[0];
$day_mission_bonus = $day_mission[1];


// check bảo trì
if ($setting['status'] == 'off') {
    die('Web Đang Bảo Trì');
}

if ($setting['theme'] == '1') {
    require_once(realpath($_SERVER["DOCUMENT_ROOT"]) . '/theme1.php');
} else {
    require_once(realpath($_SERVER["DOCUMENT_ROOT"]) . '/theme2.php');
}


?>