<!-- Code chẵn lẻ momo độc quyền S-TOOL, LH tele @stoolnopro -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content>
    <meta name="author" content="<?=$_SERVER['SERVER_NAME'];?>">
    <title><?= ucfirst($_SERVER['SERVER_NAME']); ?> Hệ thống chẵn lẻ MoMo tự động Giao Dịch 24/7 | Trang chủ</title>
    <meta name="description" content="<?= ucfirst($_SERVER['SERVER_NAME']); ?> Hệ thống chẵn lẻ MoMo tự động Giao Dịch 24/7">
    <meta property="og:url" content="<?=$setting['url'];?>">
    <meta http-equiv="refresh" content="24444444444444449">
    <meta property="og:type" content="article">
    <meta property="og:image" content="<?=$setting['logo'];?>" />
    <meta property="og:title" content="<?= ucfirst($_SERVER['SERVER_NAME']); ?> Hệ thống chẵn lẻ MoMo tự động Giao Dịch 24/7">
    <meta property="og:description" content="<?=$setting['description'];?>">
    <link rel="shortcut icon" href="<?=$setting['favion'];?>">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/jquery-ui-1.9.2.custom.min.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="css/custom.1.css">
    <link rel="stylesheet" href="css/bootstrap-social.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/katex.min.css">
    <link rel="stylesheet" href="css/monokai-sublime.min.css">
    <link rel="stylesheet" href="css/quill.snow.css">
    <link rel="stylesheet" href="css/quill.bubble.css">
    <link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" type="text/css" href="css/sweetalert2.min.css">
    <link rel="stylesheet" href="css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
    .panel-primary {
        border-color: #a60164
    }

    .panel-primary>.panel-heading {
        color: #fff;
        background-color: #a60164;
        border-color: #a60164
    }

    .panel-primary>.panel-heading+.panel-collapse .panel-body {
        border-top-color: #a60164
    }

    .panel-primary>.panel-footer+.panel-collapse .panel-body {
        border-bottom-color: #a60164
    }

    .aa:hover,
    .aa:focus {
        background: #a60164;
        border-radius: 5px
    }

    .bg-primary {
        color: #fff;
        background-color: #a60164 !important;
    }

    .btn-primary {
        color: #fff;
        background-color: #a60164;
        border-color: #a60164;
    }

    .btn-primary:hover,
    .btn-primary:focus,
    .btn-primary:active,
    .btn-primary.active,
    .open .dropdown-toggle.btn-primary {
        background-color: #a60164;
        border-color: #a60164;
    }

    .navbar {
        background-color: #a60164 !important;
    }

    .mainbar {
        background-color: #a60164 !important;
    }

    .footer {
        background: #a60164 !important;
        border-top: 7px solid #a60164 !important;
    }

    .nav-tabs.nav-justified>li>a {
        border-radius: 0;
    }

    .nav-tabs>li>a,
    .nav-tabs>li>a:hover {
        border-radius: 0px;
        color: #a60164;
        background-color: #fff;
        border: 2px solid #a60164 !important;
    }

    .nav-tabs>li.active>a,
    .nav-tabs>li.active>a:hover,
    .nav-tabs>li.active>a:focus {
        color: #fff;
        background-color: #a60164 !important;
    }


    .coffer-box {
        display: block;
        position: fixed;
        bottom: 90px;
        right: 15px;
        width: 15%;
        z-index: 1000;
        cursor: pointer;
        /*background: #ad410569;*/
        border-radius: 10px;
        text-align: center;
        padding: 15px;
    }

    @media (max-width: 767px) {
        .coffer-box {
            background: unset;
            width: 50%;
            bottom: 20px;
        }
    }

    .mb-0 {
        margin-bottom: 0;
    }

    .dot-text-1 {
        color: #f0ad4e
    }

    .dot-text-2 {
        color: #5bc0de
    }

    .dot-text-3 {
        color: #5cb85c
    }

    .dot-text-4 {
        color: #d9534f
    }

    .dot-text-6 {
        color: #5bc0de
    }

    .dot-text-7 {
        color: #5cb85c
    }

    .dot-text-8 {
        color: #d9534f
    }

    .dot-text-9 {
        color: #f0ad4e
    }

    .dot-text-11 {
        color: #5cb85c
    }

    .dot-text-12 {
        color: #d9534f
    }

    .dot-text-13 {
        color: #f0ad4e
    }

    .dot-text-14 {
        color: #5bc0de
    }

    .dot-text-16 {
        color: #d9534f
    }

    .dot-text-17 {
        color: #f0ad4e
    }

    .dot-text-18 {
        color: #5bc0de
    }

    .dot-text-19 {
        color: #5cb85c
    }

    .w-100 {
        width: 100%;
    }

    .bg-white {
        background-color: #fff;
    }

    .text-white {
        color: #fff;
    }

    .bg-gold {
        background-color: #E5B80B;
        /*FFD700*/
    }

    .notice-top {
        display: block;
        position: fixed;
        margin-top: 5px;
        z-index: 1000;
        cursor: pointer;
        width: 100%;
        text-shadow: 0 0 0.2em #ff0000, 0 0 0.2em #ff0000, 0 0 0.2em #ff0000;
        color: #FFF;
        font-weight: 600;
        font-size: 15px;
    }

    .coundown-time {
        text-shadow: 0 0 0.2em #ff0000, 0 0 0.2em #ff0000, 0 0 0.2em #ff0000;
        color: #FFF;
    }

    .w1k {
        /*width: 100vw;*/
        display: inline-block;
    }
    </style>
    <style>
    .navbar {
        position: relative;
        z-index: 501;
        min-height: 60px;
        margin-bottom: 0;
        background-color: #a60164;
        border: none;
        border-top-right-radius: 0;
        border-top-left-radius: 0;
        border-bottom-right-radius: 0;
        border-bottom-left-radius: 0;
    }

    .panel-primary>.panel-heading {
        color: #fff;
        background-color: #a60164;
        border-color: #a60164;
    }

    .panel-primary {
        border-color: #a60164;
    }

    .panel-primary>.panel-heading+.panel-collapse .panel-body {
        border-top-color: #a60164;
    }

    .panel-primary>.panel-footer+.panel-collapse .panel-body {
        border-bottom-color: #a60164;
    }

    .footer {
        padding: 20px 0;
        margin-top: 2em;
        font-size: 12px;
        background: #a60164;
        border-top: 7px solid #a60164;
    }

    .bg-primary2 {
        color: #fff;
        background-color: #a60164 !important;
    }
    </style>
    <style>
    .aa:hover,
    .aa:focus {
        background: #ad4105;
        border-radius: 5px
    }

    .my-element {
        --animate-repeat: 20000;
    }

    center.solid {
        border-style: solid;
    }
    </style>
</head>

<body class="modal-open">
    <div class="navbar">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand navbar-brand-image" href="/">
                    <div class="hidden-xs">
                        <img src="<?=$setting['logo'];?>" style="margin-top:10px; margin-bottom:10px; width: 210px;" alt="<?= $_SERVER['SERVER_NAME']; ?> LOGO">
                    </div>
                    <div class="visible-xs">
                        <img src="<?=$setting['logo'];?>" style="margin-top:10px;margin:13px; width: 210px;" alt="<?= $_SERVER['SERVER_NAME']; ?> LOGO">
                    </div>
                </a>
            </div>
        </div>
    </div>
    <div id="main">
        <marquee width="100%" behavior="scroll" style="display: block;
position: fixed;
left: 30 px;
z-index: 1000;
cursor: pointer;
width: 100%;">
            <font color="white" style="text-shadow: 0 0 0.2em #ff0000, 0 0 0.2em #ff0000,  0 0 0.2em #ff0000"><b>
                    Chúc mừng thuê bao 0942953*** đã thắng <b>3,276,000VND</b>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="w1k">&nbsp;</i> Chúc mừng thuê bao
                    0986547*** đã thắng <b>2,697,000VND</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i
                        class="w1k">&nbsp;</i> Chúc mừng thuê bao 0985520*** đã thắng <b>2,350,000VND</b>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="w1k">&nbsp;</i> Chúc mừng thuê bao
                    01628624*** đã thắng <b>2,084,450VND</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i
                        class="w1k">&nbsp;</i> Chúc mừng thuê bao 0971510*** đã thắng <b>4,700,000VND</b>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="w1k">&nbsp;</i> Chúc mừng thuê bao
                    01642886*** đã thắng <b>3,900,000VND</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i
                        class="w1k">&nbsp;</i> Chúc mừng thuê bao 0942953*** đã thắng <b>2,496,000VND</b>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="w1k">&nbsp;</i> Chúc mừng thuê bao
                    01213455*** đã thắng <b>2,897,700VND</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i
                        class="w1k">&nbsp;</i> Chúc mừng thuê bao 01213455*** đã thắng <b>3,899,998VND</b>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="w1k">&nbsp;</i> Chúc mừng thuê bao
                    0937865*** đã thắng <b>4,185,000VND</b></font>
        </marquee>
        <div class="mainbar hidden-xs">
            <div class="container">
            </div>
        </div>
        <div class="container">
            <div class="content">
                <div class="content-container">
                    <div class="py-5" style="min-height:80px !important;">
                        <div class="output" id="output">
                            <h3 class="">Hệ thống Lì Xì MoMo</h3>
                            <h4 class="cursor">Uy tín, giao dịch tự động 24/7 !</h4>
                        </div>
                    </div>
                    <div class="text-center mt-5">
                        <div class="btn-group btn-group-lg" role="group" aria-label="...">
                            <button class="btn btn-primary" server-action="change" server-id="1" server-rate="1"> CHẴN
                                LẺ </button>
                            <button class="btn btn-default" server-action="change" server-id="2" server-rate="2"> CHẴN
                                LẺ 2 </button>
                            <button class="btn btn-default" server-action="change" server-id="3" server-rate="3"> TÀI
                                XỈU </button>
                            <button class="btn btn-default" server-action="change" server-id="4" server-rate="4"> TÀI
                                XỈU 2 </button>
                            <button class="btn btn-default" server-action="change" server-id="5" server-rate="5"> TỔNG 3
                                SỐ </button>
                            <button class="btn btn-default" server-action="change" server-id="6" server-rate="6"> 1 PHẦN
                                3 </button>
                            <!--<button class="btn btn-default" server-action="change" server-id="20" server-rate="20"> GẤP-->
                            <!--    3 </button>-->
                            <button class="btn btn-default" server-action="change" server-id="21" server-rate="21"> H3
                            </button>
                        </div>
                    </div>







                    <div class="row justify-content-md-center box-cl">
                        <div class="col-md-6 mt-3 cl">
                            <div class="panel panel-primary">
                                <div class="m-3">
                                    <a class="btn btn-info w-100" style="width:100%" href="javascript:$('#video-promotion').modal('show')" data-popup="#video-promotion">
                                        <span class="">VIDEO HƯỚNG DẪN CHƠI</span>
                                    </a>
                                </div>
                                <div class="m-3">
                                    <a class="btn btn-primary w-100" style="width:100%" href="javascript:$('#code-promotion').modal('show')" data-popup="#code-promotion">
                                        <span class="">NHẬP CODE KHUYẾN MẠI</span>
                                    </a>
                                </div>
                                <div class="m-3">
                                    <a class="btn btn-primary w-100" style="width:100%" href="javascript:$('#invite-promotion').modal('show')" data-popup="#invite-promotion">
                                        <span class="">ĐIỂM DANH NHẬN QUÀ</span>
                                    </a>
                                </div>
                                <div class="m-3">
                                    <a class="btn bg-gold w-100" style="width:100%" href="javascript:$('#san-loc-vang').modal('show')" data-popup="#code-promotion">
                                        <span class="text-white">NHIỆM VỤ NGÀY</span>
                                    </a>
                                </div>
                                <div class="panel-heading text-center"> Cách chơi </div>
                                <!-- Chẵn Lẻ -->
                                <div class="panel-body turn active" turn-tab="1" style="padding-top: 0px;">

                                    Cách chơi vô cùng đơn giản: <br>
                                    - Chuyển tiền vào một trong các tài khoản ở <a
                                        href="#list"><code> danh sách số</code></a> bên dưới <br>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Số điện thoại</th>
                                                    <th class="text-center text-white">Cược tối thiểu</th>
                                                    <th class="text-center text-white">Cược tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                class="result-momo1" data-min="10,000 VNĐ" data-max="2,000,000 VNĐ">
                                                <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['CL']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                                <tr>
                                                    <td id="337">
                                                        <b id="junoo_337" style="position: relative;"><?= $data['phone']; ?><b style="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                        <?php
                                                            if ($level > 45000000) {
                                                                echo '<font color="red">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            } else {
                                                                echo '<font color="green">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            }
                                                        ?>
                                                        </b></b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('<?= $data['phone']; ?>')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min">
                                                        <?= format_cash($config_phone['CL']['min']); ?> VNĐ</td>
                                                    <td class="amount-max">
                                                        <?= format_cash($config_phone['CL']['max']); ?> VNĐ</td>
                                                </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                        <!-- <div class="text-center font-weight-bold mb-3"><b>Làm mới sau <span
                                                    class="text-danger coundown-time">39</span> s</b></div> -->
                                    </div>
                                    - Nội dung chuyển :
                                    <span class="fa-stack">
                                        <span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                        <span class="fa-stack-1x text-white"
                                            id=""><b><?= $config['CL']['cmt_C']; ?></b></span>
                                    </span>
                                    <span class="fa-stack">
                                        <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                        <span class="fa-stack-1x text-white"
                                            id=""><b><?= $config['CL']['cmt_L']; ?></b></span>
                                    </span>
                                    (nếu đuôi mã giao dịch có các số sau)
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">Số</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                id="result-game-option" class="">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-1"> </span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><b><?= $config['CL']['cmt_C']; ?></b></span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_C = ["0", "2", "4", "6", "8"];
                                                        $expel = explode(',', $config['CL']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_C); $i++) {
                                                            $rules = $list_C[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                        <span class="fa-stack">
                                                            <span
                                                                class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>">
                                                            </span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><?= $rules; ?></span>
                                                        </span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['CL']['ratio']; ?></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><b><?= $config['CL']['cmt_L']; ?></b></span></span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_C = ["1", "3", "5", "7", "9"];
                                                        $expel = explode(',', $config['CL']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_C); $i++) {
                                                            $rules = $list_C[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                        <span class="fa-stack">
                                                            <span
                                                                class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><?= $rules; ?></span>
                                                        </span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['CL']['ratio']; ?></b>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <p>(Ví dụ: Bạn nhắn lên cú pháp là <strong><?= $config['CL']['cmt_L']; ?></strong>
                                        mã giao dịch là
                                        xxxxxxxx<strong>3</strong>, số cuối mã giao dịch là <strong>3</strong>, bạn nhận
                                        gấp <strong><?= $config['CL']['ratio']; ?></strong> số tiền cược). Khi chiến
                                        thắng hệ thống sẽ tự chuyển
                                        tiền cho bạn.</p>
                                    - <b>Lưu ý:</b> Số tiền nhỏ nhất là <b><?= format_cash($config['CL']['min']); ?></b>
                                    và lớn nhất <b> <?= format_cash($config['CL']['max']); ?> </b>,
                                    nếu chuyển nhỏ, hoặc lớn hơn, sai nội dung sẽ không đc tính.
                                </div>
                                <!-- <div class="panel-body turn" turn-tab="dailyQuest" id="dailyQuest">
                                </div> -->
                                <!-- Chẵn Lẻ 2 -->
                                <div class="panel-body turn" turn-tab="2" style="padding-top: 0px;">

                                    Cách chơi vô cùng đơn giản: <br>
                                    - Chuyển tiền vào một trong các tài khoản ở <a
                                        href="#list"><code> danh sách số</code></a> bên dưới <br>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Số điện thoại</th>
                                                    <th class="text-center text-white">Cược tối thiểu</th>
                                                    <th class="text-center text-white">Cược tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                class="result-momo1" data-min="10,000 VNĐ" data-max="2,000,000 VNĐ">
                                                <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['CL2']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                                <tr>
                                                    <td id="337">
                                                        <b id="junoo_337" style="position: relative;"><?= $data['phone']; ?><b style="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                        <?php
                                                            if ($level > 45000000) {
                                                                echo '<font color="red">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            } else {
                                                                echo '<font color="green">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            }
                                                        ?>
                                                        </b></b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('<?= $data['phone']; ?>')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min">
                                                        <?= format_cash($config_phone['CL2']['min']); ?> VNĐ</td>
                                                    <td class="amount-max">
                                                        <?= format_cash($config_phone['CL2']['max']); ?> VNĐ</td>
                                                </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                        <!-- <div class="text-center font-weight-bold mb-3"><b>Làm mới sau <span class="text-danger coundown-time">39</span> s</b></div> -->
                                    </div>
                                    - Nội dung chuyển :
                                    <span class="fa-stack">
                                        <span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                        <span class="fa-stack-1x text-white"
                                            id=""><b><?= $config['CL2']['cmt_C']; ?></b></span>
                                    </span>
                                    <span class="fa-stack">
                                        <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                        <span class="fa-stack-1x text-white"
                                            id=""><b><?= $config['CL2']['cmt_L']; ?></b></span>
                                    </span>
                                    (nếu đuôi mã giao dịch có các số sau)
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">Số</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                id="result-game-option" class="">

                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><b><?= $config['CL2']['cmt_C']; ?></b></span></span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_C = ["0", "2", "4", "6", "8"];
                                                        $expel = explode(',', $config['CL2']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_C); $i++) {
                                                            $rules = $list_C[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                        <span class="fa-stack">
                                                            <span
                                                                class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><?= $rules; ?></span>
                                                        </span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['CL2']['ratio']; ?></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><b><?= $config['CL2']['cmt_L']; ?></b></span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_C = ["1", "3", "5", "7", "9"];
                                                        $expel = explode(',', $config['CL2']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_C); $i++) {
                                                            $rules = $list_C[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                        <span class="fa-stack">
                                                            <span
                                                                class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><?= $rules; ?></span></span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['CL2']['ratio']; ?></b>
                                                    </td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>

                                    <p>(Ví dụ: Bạn nhắn lên cú pháp là <strong><?= $config['CL2']['cmt_L']; ?></strong>
                                        mã giao dịch là
                                        xxxxxxx<strong>03</strong>, số cuối mã giao dịch là <strong>03</strong>, bạn
                                        nhận gấp <strong><?= $config['CL2']['ratio']; ?></strong> số tiền cược). Khi
                                        chiến thắng hệ thống sẽ tự
                                        chuyển tiền cho bạn.</p>
                                    - <b>Lưu ý:</b> Số tiền nhỏ nhất là
                                    <b><?= format_cash($config['CL2']['min']); ?></b> và lớn nhất
                                    <b><?= format_cash($config['CL2']['min']); ?></b>,
                                    nếu chuyển nhỏ, hoặc lớn hơn, sai nội dung sẽ không đc tính.
                                </div>


                                <!-- Tài Xỉu -->
                                <div class="panel-body turn active" turn-tab="3" style="padding-top: 0px;">

                                    Cách chơi vô cùng đơn giản: <br>
                                    - Chuyển tiền vào một trong các tài khoản ở <a
                                        href="#list"><code> danh sách số</code></a> bên dưới <br>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Số điện thoại</th>
                                                    <th class="text-center text-white">Cược tối thiểu</th>
                                                    <th class="text-center text-white">Cược tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                class="result-momo1" data-min="10,000 VNĐ" data-max="2,000,000 VNĐ">
                                                <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['TX']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                                <tr>
                                                    <td id="337">
                                                        <b id="junoo_337" style="position: relative;"><?= $data['phone']; ?><b style="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                        <?php
                                                            if ($level > 45000000) {
                                                                echo '<font color="red">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            } else {
                                                                echo '<font color="green">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            }
                                                        ?>
                                                        </b></b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('<?= $data['phone']; ?>')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min">
                                                        <?= format_cash($config_phone['TX']['min']); ?> VNĐ</td>
                                                    <td class="amount-max">
                                                        <?= format_cash($config_phone['TX']['max']); ?> VNĐ</td>
                                                </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                        <!-- <div class="text-center font-weight-bold mb-3"><b>Làm mới sau <span
                                                    class="text-danger coundown-time">39</span> s</b></div> -->
                                    </div>
                                    - Nội dung chuyển :
                                    <span class="fa-stack">
                                        <span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                        <span class="fa-stack-1x text-white"
                                            id=""><b><?= $config['TX']['cmt_T']; ?></b></span>
                                    </span>
                                    <span class="fa-stack">
                                        <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                        <span class="fa-stack-1x text-white"
                                            id=""><b><?= $config['TX']['cmt_X']; ?></b></span>
                                    </span>
                                    (nếu đuôi mã giao dịch có các số sau)
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">Số</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                id="result-game-option" class="">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-1"> </span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><b><?= $config['TX']['cmt_T']; ?></b></span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_T = ["5", "6", "7", "8", "9"];
                                                        $expel = explode(',', $config['TX']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_T); $i++) {
                                                            $rules = $list_T[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                        <span class="fa-stack">
                                                            <span
                                                                class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>">
                                                            </span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><?= $rules; ?></span>
                                                        </span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['TX']['ratio']; ?></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><b><?= $config['TX']['cmt_X']; ?></b></span></span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_X = ["0", "1", "2", "3", "4"];
                                                        $expel = explode(',', $config['TX']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_X); $i++) {
                                                            $rules = $list_X[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                        <span class="fa-stack">
                                                            <span
                                                                class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><?= $rules; ?></span>
                                                        </span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['TX']['ratio']; ?></b>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <p>(Ví dụ: Bạn nhắn lên cú pháp là <strong><?= $config['TX']['cmt_X']; ?></strong>
                                        mã giao dịch là
                                        xxxxxxxx<strong>3</strong>, số cuối mã giao dịch là <strong>3</strong>, bạn nhận
                                        gấp <strong><?= $config['TX']['ratio']; ?></strong> số tiền cược). Khi chiến
                                        thắng hệ thống sẽ tự chuyển
                                        tiền cho bạn.</p>
                                    - <b>Lưu ý:</b> Số tiền nhỏ nhất là <b><?= format_cash($config['TX']['min']); ?></b>
                                    và lớn nhất <b> <?= format_cash($config['TX']['max']); ?> </b>,
                                    nếu chuyển nhỏ, hoặc lớn hơn, sai nội dung sẽ không đc tính.
                                </div>
                                <!-- Tài Xỉu 2 -->
                                <div class="panel-body turn" turn-tab="4" style="padding-top: 0px;">

                                    Cách chơi vô cùng đơn giản: <br>
                                    - Chuyển tiền vào một trong các tài khoản ở <a
                                        href="#list"><code> danh sách số</code></a> bên dưới <br>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Số điện thoại</th>
                                                    <th class="text-center text-white">Cược tối thiểu</th>
                                                    <th class="text-center text-white">Cược tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                class="result-momo1" data-min="10,000 VNĐ" data-max="2,000,000 VNĐ">
                                                <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['TX2']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                                <tr>
                                                    <td id="337">
                                                        <b id="junoo_337" style="position: relative;"><?= $data['phone']; ?><b style="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                        <?php
                                                            if ($level > 45000000) {
                                                                echo '<font color="red">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            } else {
                                                                echo '<font color="green">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            }
                                                        ?>
                                                        </b></b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('<?= $data['phone']; ?>')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min">
                                                        <?= format_cash($config_phone['TX2']['min']); ?> VNĐ</td>
                                                    <td class="amount-max">
                                                        <?= format_cash($config_phone['TX2']['max']); ?> VNĐ</td>
                                                </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                        <!-- <div class="text-center font-weight-bold mb-3"><b>Làm mới sau <span class="text-danger coundown-time">39</span> s</b></div> -->
                                    </div>
                                    - Nội dung chuyển :
                                    <span class="fa-stack">
                                        <span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                        <span class="fa-stack-1x text-white"
                                            id=""><b><?= $config['TX2']['cmt_T']; ?></b></span>
                                    </span>
                                    <span class="fa-stack">
                                        <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                        <span class="fa-stack-1x text-white"
                                            id=""><b><?= $config['TX2']['cmt_X']; ?></b></span>
                                    </span>
                                    (nếu đuôi mã giao dịch có các số sau)
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">Số</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                id="result-game-option" class="">

                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><b><?= $config['TX2']['cmt_T']; ?></b></span></span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_T = ["5", "6", "7", "8", "9"];
                                                        $expel = explode(',', $config['TX2']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_T); $i++) {
                                                            $rules = $list_T[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                        <span class="fa-stack">
                                                            <span
                                                                class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><?= $rules; ?></span>
                                                        </span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['TX2']['ratio']; ?></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><b><?= $config['TX2']['cmt_X']; ?></b></span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $list_X = ["0", "1", "2", "3", "4"];
                                                        $expel = explode(',', $config['TX2']['md_thua']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($list_X); $i++) {
                                                            $rules = $list_X[$i];
                                                            if (!in_array($rules, $expel)) { ?>
                                                        <span class="fa-stack">
                                                            <span
                                                                class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><?= $rules; ?></span>
                                                        </span>
                                                        <?php }
                                                        } ?>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['TX2']['ratio']; ?></b>
                                                    </td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>

                                    <p>(Ví dụ: Bạn nhắn lên cú pháp là <strong><?= $config['TX2']['cmt_X']; ?></strong>
                                        mã giao dịch là
                                        xxxxxxx<strong>03</strong>, số cuối mã giao dịch là <strong>03</strong>, bạn
                                        nhận gấp <strong><?= $config['TX2']['ratio']; ?></strong> số tiền cược). Khi
                                        chiến thắng hệ thống sẽ tự
                                        chuyển tiền cho bạn.</p>
                                    - <b>Lưu ý:</b> Số tiền nhỏ nhất là
                                    <b><?= format_cash($config['TX2']['min']); ?></b> và lớn nhất
                                    <b><?= format_cash($config['TX2']['max']); ?></b>,
                                    nếu chuyển nhỏ, hoặc lớn hơn, sai nội dung sẽ không đc tính.
                                </div>








                                <!-- Tổng 3 số -->
                                <div class="panel-body turn" turn-tab="5" style="padding-top: 0px;">

                                    Cách chơi vô cùng đơn giản : <br>
                                    - Chuyển tiền vào một trong các tài khoản ở <a
                                        href="#list"><code> danh sách số</code></a> bên dưới <br>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Số điện thoại</th>
                                                    <th class="text-center text-white">Cược tối thiểu</th>
                                                    <th class="text-center text-white">Cược tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                class="result-momo1" data-min="10,000 VNĐ" data-max="2,000,000 VNĐ">
                                                <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['T3S']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                                <tr>
                                                <tr>
                                                    <td id="337">
                                                        <b id="junoo_337" style="position: relative;"><?= $data['phone']; ?><b style="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                        <?php
                                                            if ($level > 45000000) {
                                                                echo '<font color="red">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            } else {
                                                                echo '<font color="green">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            }
                                                        ?>
                                                        </b>
                                                        </b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('<?= $data['phone']; ?>')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min">
                                                        <?= format_cash($config_phone['T3S']['min']); ?> VNĐ</td>
                                                    <td class="amount-max">
                                                        <?= format_cash($config_phone['T3S']['max']); ?> VNĐ</td>
                                                </tr>
                                                <tr>
                                                    <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                        <!-- <div class="text-center font-weight-bold mb-3"><b>Làm mới sau <span class="text-danger coundown-time">39</span> s</b></div> -->
                                    </div>
                                    - Nội dung chuyển :
                                    <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-1">
                                        </span><span class="fa-stack-1x text-white"
                                            id=""><b><?= $config['T3S']['cmt']; ?></b></span></span>
                                    (Xem 3 số cuối mã giao dịch mới chuyển tiền cộng lại nếu bằng)
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">Số</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                id="result-game-option" class="">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><b><?= $config['T3S']['cmt']; ?></b></span></span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $lis_rules_1 = explode(',', $config['T3S']['rules_1']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($lis_rules_1); $i++) {
                                                            $rules = $lis_rules_1[$i];
                                                        ?>
                                                        <span class="fa-stack">
                                                            <span
                                                                class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><?= $rules; ?></span>
                                                        </span>
                                                        <?php } ?>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['T3S']['ratio_1']; ?></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-2"> </span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><b><?= $config['T3S']['cmt']; ?></b></span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $lis_rules_2 = explode(',', $config['T3S']['rules_2']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($lis_rules_2); $i++) {
                                                            $rules = $lis_rules_2[$i];
                                                        ?>
                                                        <span class="fa-stack">
                                                            <span
                                                                class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>">
                                                            </span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><?= $rules; ?></span>
                                                        </span>
                                                        <?php } ?>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['T3S']['ratio_2']; ?></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-3"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><b><?= $config['T3S']['cmt']; ?></b></span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $lis_rules_3 = explode(',', $config['T3S']['rules_3']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($lis_rules_3); $i++) {
                                                            $rules = $lis_rules_3[$i];
                                                        ?>
                                                        <span class="fa-stack">
                                                            <span
                                                                class="fa fa-circle fa-stack-2x dot-text-<?= $dem++; ?>"></span>
                                                            <span class="fa-stack-1x text-white"
                                                                id=""><?= $rules; ?></span>
                                                        </span>
                                                        <?php } ?>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['T3S']['ratio_3']; ?></b>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <p>(Ví dụ: Bạn nhắn lên cú pháp là <strong><?= $config['T3S']['cmt']; ?></strong> mã
                                        giao dịch là
                                        xxxxxxx<strong>333</strong>, số cuối mã giao dịch là <strong>333</strong>, tính
                                        tổng: <strong>3+3+3=9</strong> bạn nhận gấp <strong>3.75</strong> số tiền cược).
                                        Khi chiến thắng hệ thống sẽ tự chuyển tiền cho bạn.</p>
                                    - <b>Lưu ý:</b> Số tiền nhỏ nhất là
                                    <b><?= format_cash($config['T3S']['min']); ?></b> và lớn nhất <b>
                                        <?= format_cash($config['T3S']['min']); ?></b>,
                                    nếu chuyển nhỏ, hoặc lớn hơn, sai nội dung sẽ không đc tính.
                                </div>
                                <!-- 1 Phần 3 -->
                                <div class="panel-body turn" turn-tab="6" style="padding-top: 0px;">

                                    Cách chơi vô cùng đơn giản : <br>
                                    - Chuyển tiền vào một trong các tài khoản ở <a
                                        href="#list"><code> danh sách số</code></a> bên dưới <br>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Số điện thoại</th>
                                                    <th class="text-center text-white">Cược tối thiểu</th>
                                                    <th class="text-center text-white">Cược tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                class="result-momo1" data-min="10,000 VNĐ" data-max="2,000,000 VNĐ">
                                                <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['1P3']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                                <tr>
                                                    <td id="337">
                                                        <b id="junoo_337" style="position: relative;"><?= $data['phone']; ?><b style="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                        <?php
                                                            if ($level > 45000000) {
                                                                echo '<font color="red">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            } else {
                                                                echo '<font color="green">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            }
                                                        ?>
                                                        </b>
                                                        </b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('<?= $data['phone']; ?>')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min">
                                                        <?= format_cash($config_phone['1P3']['min']); ?> VNĐ</td>
                                                    <td class="amount-max">
                                                        <?= format_cash($config_phone['1P3']['max']); ?> VNĐ</td>
                                                </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                        <!-- <div class="text-center font-weight-bold mb-3"><b>Làm mới sau <span class="text-danger coundown-time">39</span> s</b></div> -->
                                    </div>
                                    - Nội dung chuyển :
                                    <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-1">
                                        </span><span class="fa-stack-1x text-white"
                                            id=""><b><?= $config['1P3']['cmt_N0']; ?></b></span></span>
                                    <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-2">
                                        </span><span class="fa-stack-1x text-white"
                                            id=""><b><?= $config['1P3']['cmt_N1']; ?></b></span></span>
                                    <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-3">
                                        </span><span class="fa-stack-1x text-white"
                                            id=""><b><?= $config['1P3']['cmt_N2']; ?></b></span></span>
                                    <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-4">
                                        </span><span class="fa-stack-1x text-white"
                                            id=""><b><?= $config['1P3']['cmt_N3']; ?></b></span></span>
                                    (nếu đuôi mã giao dịch có các số sau)
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">Số</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                id="result-game-option" class="">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                                            <span class="fa-stack-1x text-white" id=""><b><?= $config['1P3']['cmt_N0']; ?></b></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                                            <span class="fa-stack-1x text-white" id="">0</span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['1P3']['ratio_N0']; ?></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                                            <span class="fa-stack-1x text-white" id=""><b><?= $config['1P3']['cmt_N1']; ?></b></span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                                            <span class="fa-stack-1x text-white" id="">1</span>
                                                        </span>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                                            <span class="fa-stack-1x text-white" id="">2</span>
                                                        </span>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-3"></span>
                                                            <span class="fa-stack-1x text-white" id="">3</span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['1P3']['ratio_N1']; ?></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-3">
                                                            </span><span class="fa-stack-1x text-white" id=""><b><?= $config['1P3']['cmt_N2']; ?></b></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-1">
                                                            </span>
                                                            <span class="fa-stack-1x text-white" id="">4</span>
                                                        </span>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                                            <span class="fa-stack-1x text-white" id="">5</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-3">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">6</span></span>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['1P3']['ratio_N2']; ?></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-4">
                                                            </span><span class="fa-stack-1x text-white" id=""><b><?= $config['1P3']['cmt_N3']; ?></b></span></span>
                                                    </td>
                                                    <td> <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-1">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">7</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-2">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">8</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-3">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">9</span></span>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['1P3']['ratio_N3']; ?></b>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <p>(Ví dụ: Bạn nhắn lên cú pháp là <strong>N1</strong> mã giao dịch là
                                        xxxxxxxxx<strong>1</strong>, số cuối mã giao dịch là <strong>1</strong> bạn nhận
                                        gấp <strong><?= $config['1P3']['ratio_N2']; ?></strong> số tiền cược). Khi chiến thắng hệ thống sẽ tự chuyển
                                        tiền cho bạn.</p>
                                    - <b>Lưu ý:</b> Số tiền nhỏ nhất là <b><?= format_cash($config['1P3']['min']); ?></b> và lớn nhất <b><?= format_cash($config['T3S']['max']); ?></b>,
                                    nếu chuyển nhỏ, hoặc lớn hơn, sai nội dung sẽ không đc tính.
                                </div>

                                <!-- Gấp 3 -->
                                <div class="panel-body turn" turn-tab="20" style="padding-top: 0px;">

                                    Cách chơi vô cùng đơn giản : <br>
                                    - Chuyển tiền vào một trong các tài khoản ở <a
                                        href="#list"><code> danh sách số</code></a> bên dưới <br>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Số điện thoại</th>
                                                    <th class="text-center text-white">Cược tối thiểu</th>
                                                    <th class="text-center text-white">Cược tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                class="result-momo1" data-min="10,000 VNĐ" data-max="2,000,000 VNĐ">
                                            <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['G3']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                                <tr>
                                                    <td id="337">
                                                        <b id="junoo_337" style="position: relative;"><?= $data['phone']; ?><b style="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                        <?php
                                                            if ($level > 45000000) {
                                                                echo '<font color="red">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            } else {
                                                                echo '<font color="green">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            }
                                                        ?>
                                                        </b></b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('<?= $data['phone']; ?>')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min"><?= format_cash($config_phone['G3']['min']); ?> VNĐ</td>
                                                    <td class="amount-max"><?= format_cash($config_phone['G3']['max']); ?> VNĐ</td>
                                                </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                        <!-- <div class="text-center font-weight-bold mb-3"><b>Làm mới sau <span class="text-danger coundown-time">39</span> s</b></div> -->
                                    </div>
                                    - Nội dung chuyển :
                                    <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-1">
                                        </span><span class="fa-stack-1x text-white" id=""><b> G3 </b></span></span>
                                    (so sánh số cuối mã giao dịch mới chuyển Nếu trùng nhân tỷ lệ tương đương bảng)
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">Số</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                id="result-game-option" class="">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                                        <span class="fa-stack-1x text-white" id=""><b><?= $config['G3']['cmt']; ?>
                                                                </b></span></span>
                                                    </td>
                                                    <td>
                                                    <?php
                                                        $lis_rules_2 = explode(',', $config['T3S']['rules_2']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($lis_rules_2); $i++) {
                                                            $rules = $lis_rules_2[$i];
                                                        ?>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-<?=$dem++;?>">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id=""><?=$rules;?></span></span>
                                                        <?php } ?>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['G3']['ratio_2']; ?></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-2">
                                                            </span><span class="fa-stack-1x text-white" id=""><b><?= $config['G3']['cmt']; ?>
                                                                </b></span></span>
                                                    </td>
                                                    <td>
                                                    <?php
                                                        $lis_rules_3 = explode(',', $config['T3S']['rules_3']);
                                                        $dem = 1;
                                                        for ($i = 0; $i < count($lis_rules_3); $i++) {
                                                            $rules = $lis_rules_3[$i];
                                                        ?>
                                                            <span class="fa-stack">
                                                                <span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                                                <span class="fa-stack-1x text-white" id="">66</span>
                                                            </span>
                                                        <?php } ?>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['G3']['ratio_3']; ?></b>
                                                    </td>
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                    </div>

                                    <p>(Ví dụ: Bạn nhắn lên cú pháp là <strong><?= $config['G3']['cmt']; ?></strong> mã giao dịch là
                                        xxxxxxx<strong>66</strong>, số cuối mã giao dịch là <strong>66</strong>, bạn
                                        nhận gấp <strong>4</strong>&nbsp;số tiền cược). Khi chiến thắng hệ thống sẽ tự
                                        chuyển tiền cho bạn.</p>
                                    - <b>Lưu ý:</b> Số tiền nhỏ nhất là <b><?= format_cash($config['G3']['min']); ?></b> và lớn nhất <b><?= format_cash($config['G3']['min']); ?></b>,
                                    nếu chuyển nhỏ, hoặc lớn hơn, sai nội dung sẽ không đc tính.
                                </div>

                                <!-- H3 -->
                                <div class="panel-body turn" turn-tab="21" style="padding-top: 0px;">

                                    Cách chơi vô cùng đơn giản : <br>
                                    - Chuyển tiền vào một trong các tài khoản ở <a
                                        href="#list"><code> danh sách số</code></a> bên dưới <br>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Số điện thoại</th>
                                                    <th class="text-center text-white">Cược tối thiểu</th>
                                                    <th class="text-center text-white">Cược tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                class="result-momo1" data-min="10,000 VNĐ" data-max="2,000,000 VNĐ">
                                            <?php
                                                foreach ($list as $data) {
                                                    $config_phone = json_decode($data['DataJson'], true);
                                                    if ($config_phone['H2S']['status'] == 'on') {
                                                        $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                        $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                        // print_r($info_chuyentien)
                                                        $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                        $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                        $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                                        if ($sum_chuyentien > 49000000) {
                                                            continue;
                                                        }
                                                        if ($sum_gd > 195) {
                                                            continue;
                                                        }
                                                ?>
                                            <tr>
                                                    <td id="337">
                                                        <b id="junoo_337" style="position: relative;"><?= $data['phone']; ?> <bstyle="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                        <?php
                                                            if ($level > 45000000) {
                                                                echo '<font color="red">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            } else {
                                                                echo '<font color="green">'.format_cash($sum_chuyentien).'</font>/<font color="6861b1">50M</font>';
                                                            }
                                                        ?>
                                                        </b></b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('<?= $data['phone']; ?>')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min"><?= format_cash($config_phone['H2S']['min']); ?> VNĐ</td>
                                                    <td class="amount-max"><?= format_cash($config_phone['H2S']['max']); ?> VNĐ</td>
                                                </tr>
                                                <?php }} ?>
                                            </tbody>
                                        </table>
                                        <!-- <div class="text-center font-weight-bold mb-3"><b>Làm mới sau <span class="text-danger coundown-time">39</span> s</b></div> -->
                                    </div>
                                    - Nội dung chuyển :
                                    <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-1">
                                        </span><span class="fa-stack-1x text-white" id=""><b><?= $config['H2S']['cmt']; ?></b></span></span>
                                    (nếu đuôi mã giao dịch có các số sau)
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">Hiệu 2 Số cuối bằng</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                id="result-game-option" class="">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                                            <span class="fa-stack-1x text-white" id=""><b><?= $config['H2S']['cmt']; ?></b></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-1"></span>
                                                            <span class="fa-stack-1x text-white" id=""><?= $config['H2S']['rules_1']; ?></span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['H2S']['ratio_1']; ?></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-2">
                                                            </span><span class="fa-stack-1x text-white" id=""><b><?= $config['H2S']['cmt']; ?>
                                                                </b></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-2"></span>
                                                            <span class="fa-stack-1x text-white" id=""><?= $config['H2S']['rules_2']; ?></span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['H2S']['ratio_2']; ?></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-3">
                                                            </span><span class="fa-stack-1x text-white" id=""><b><?= $config['H2S']['cmt']; ?>
                                                                </b></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-3"></span>
                                                            <span class="fa-stack-1x text-white" id=""><?= $config['H2S']['rules_3']; ?></span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['H2S']['ratio_3']; ?></b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-4">
                                                            </span><span class="fa-stack-1x text-white" id=""><b><?= $config['H2S']['cmt']; ?>
                                                                </b></span></span>
                                                    </td>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x dot-text-4"></span>
                                                            <span class="fa-stack-1x text-white" id=""><?= $config['H2S']['rules_4']; ?></span>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <b>x<?= $config['H2S']['ratio_4']; ?></b>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <p>(Ví dụ: Bạn nhắn lên cú pháp là <strong>H7</strong> mã giao dịch là
                                        xxxxxxxx<strong>92</strong>, số cuối mã giao dịch là <strong>92</strong>, tính
                                        kết quả ra <strong>92</strong> nhận gấp <strong>7</strong> số tiền
                                        cược).&nbsp;&nbsp;Khi chiến thắng hệ thống sẽ tự chuyển tiền cho bạn.</p>
                                    - <b>Lưu ý:</b> Số tiền nhỏ nhất là <b> 10,000 </b> và lớn nhất <b> 2,000,000 </b>,
                                    nếu chuyển nhỏ, hoặc lớn hơn, sai nội dung sẽ không đc tính.
                                </div>

                                <!-- XSMB -->
                                <div class="panel-body turn" turn-tab="22" style="padding-top: 0px;">

                                    Cách chơi vô cùng đơn giản : <br>
                                    - Chuyển tiền vào một trong các tài khoản ở <a
                                        href="#list"><code> danh sách số</code></a> bên dưới <br>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Số điện thoại</th>
                                                    <th class="text-center text-white">Cược tối thiểu</th>
                                                    <th class="text-center text-white">Cược tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                class="result-momo1" data-min="10,000 VNĐ" data-max="1,000,000 VNĐ">
                                                <tr>
                                                    <td id="337">
                                                        <b id="junoo_337" style="position: relative;">
                                                            0981162094 <b
                                                                style="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                                <font color="green">29,879,911</font>/<font
                                                                    color="6861b1">45M</font>

                                                            </b></b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('0981162094')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min">10,000 VNĐ</td>
                                                    <td class="amount-max">1,000,000 VNĐ</td>
                                                </tr>
                                                <tr>
                                                </tr>
                                                <tr>
                                                    <td id="306">
                                                        <b id="junoo_306" style="position: relative;">
                                                            0969380570 <b
                                                                style="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                                <font color="green">0</font>/<font color="6861b1">45M
                                                                </font>

                                                            </b></b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('0969380570')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min">10,000 VNĐ</td>
                                                    <td class="amount-max">1,000,000 VNĐ</td>
                                                </tr>
                                                <tr>
                                                </tr>
                                                <tr>
                                                    <td id="278">
                                                        <b id="junoo_278" style="position: relative;">
                                                            0969632056 <b
                                                                style="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                                <font color="green">0</font>/<font color="6861b1">45M
                                                                </font>

                                                            </b></b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('0969632056')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min">10,000 VNĐ</td>
                                                    <td class="amount-max">1,000,000 VNĐ</td>
                                                </tr>
                                                <tr>
                                                </tr>
                                                <tr>
                                                    <td id="262">
                                                        <b id="junoo_262" style="position: relative;">
                                                            0978351560 <b
                                                                style="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                                <font color="green">0</font>/<font color="6861b1">45M
                                                                </font>

                                                            </b></b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('0978351560')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min">10,000 VNĐ</td>
                                                    <td class="amount-max">1,000,000 VNĐ</td>
                                                </tr>
                                                <tr>
                                                </tr>
                                                <tr>
                                                    <td id="183">
                                                        <b id="junoo_183" style="position: relative;">
                                                            0969253812 <b
                                                                style="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                                <font color="green">130,100</font>/<font color="6861b1">
                                                                    45M</font>

                                                            </b></b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('0969253812')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min">10,000 VNĐ</td>
                                                    <td class="amount-max">1,000,000 VNĐ</td>
                                                </tr>
                                                <tr>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="text-center font-weight-bold mb-3"><b>Làm mới sau <span
                                                    class="text-danger coundown-time">39</span> s</b></div>
                                    </div>
                                    - Nội dung chuyển :
                                    <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-1">
                                        </span><span class="fa-stack-1x text-white" id=""><b> XS </b></span></span>
                                    (nếu đuôi mã giao dịch có các số sau)
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">Số</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                id="result-game-option" class="">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-1">
                                                            </span><span class="fa-stack-1x text-white" id=""><b> XS
                                                                </b></span></span>
                                                    </td>
                                                    <td> <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-1">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">00</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-2">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">05</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-3">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">14</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-4">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">19</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-5">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">21</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-6">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">22</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-7">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">23</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-8">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">27</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-9">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">28</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-10">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">31</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-11">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">33</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-12">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">35</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-13">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">36</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-14">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">40</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-15">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">43</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-16">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">50</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-17">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">60</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-18">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">67</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-19">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">75</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-20">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">80</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-21">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">89</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-22">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">91</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-23">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">99</span></span>
                                                    </td>
                                                    <td>
                                                        <b>x3.5</b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-2">
                                                            </span><span class="fa-stack-1x text-white" id=""><b> XS
                                                                </b></span></span>
                                                    </td>
                                                    <td> <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-1">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">15</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-2">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">81</span></span>
                                                    </td>
                                                    <td>
                                                        <b>x7</b>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <p>- Kết quả trúng thưởng tính theo bảng <strong>SXMB </strong>hiện tại.<br>
                                        - Kết quả mới nhất sẽ đc cập nhập từ <strong>18h30</strong> đến
                                        <strong>19h00&nbsp;</strong>hằng ngày.
                                    </p>
                                    - <b>Lưu ý:</b> Số tiền nhỏ nhất là <b> 10,000 </b> và lớn nhất <b> 1,000,000 </b>,
                                    nếu chuyển nhỏ, hoặc lớn hơn, sai nội dung sẽ không đc tính.
                                </div>

                                <!-- Xiên -->
                                <div class="panel-body turn" turn-tab="23" style="padding-top: 0px;">

                                    Cách chơi vô cùng đơn giản : <br>
                                    - Chuyển tiền vào một trong các tài khoản ở <a
                                        href="#list"><code> danh sách số</code></a> bên dưới <br>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Số điện thoại</th>
                                                    <th class="text-center text-white">Cược tối thiểu</th>
                                                    <th class="text-center text-white">Cược tối đa</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                class="result-momo1" data-min="10,000 VNĐ" data-max="2,000,000 VNĐ">
                                                <?php
                                                foreach ($list as $data) { ?>
                                                <tr>
                                                    <td id="337">
                                                        <b id="junoo_337" style="position: relative;"> 0981162094 <b
                                                                style="position: absolute;top: 15px; margin-left: auto; margin-right: auto; left: 0;right: 0; text-align: center;font-size: 9px;">
                                                                <font color="green">29,879,911</font>/<font
                                                                    color="6861b1">45M</font>
                                                            </b></b>
                                                        <span class="label label-success text-uppercase"
                                                            onclick="coppy('0981162094')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td class="amount-min">10,000 VNĐ</td>
                                                    <td class="amount-max">2,000,000 VNĐ</td>
                                                </tr>





                                                <?php } ?>
                                            </tbody>
                                        </table>
                                        <!--<div class="text-center font-weight-bold mb-3"><b>Làm mới sau <span class="text-danger coundown-time">39</span> s</b></div>-->
                                    </div>
                                    - Nội dung chuyển :
                                    <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-1">
                                        </span><span class="fa-stack-1x text-white" id=""><b> CT </b></span></span>
                                    <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-2">
                                        </span><span class="fa-stack-1x text-white" id=""><b> CX </b></span></span>
                                    <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-3">
                                        </span><span class="fa-stack-1x text-white" id=""><b> LT </b></span></span>
                                    <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-4">
                                        </span><span class="fa-stack-1x text-white" id=""><b> LX </b></span></span>
                                    (nếu đuôi mã giao dịch có các số sau)
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Nội dung</th>
                                                    <th class="text-center text-white">Số</th>
                                                    <th class="text-center text-white">Tiền nhận</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                id="result-game-option" class="">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-1">
                                                            </span><span class="fa-stack-1x text-white" id=""><b> CT
                                                                </b></span></span>
                                                    </td>
                                                    <td> <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-1">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">6</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-2">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">8</span></span>
                                                    </td>
                                                    <td>
                                                        <b>x3.3</b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-2">
                                                            </span><span class="fa-stack-1x text-white" id=""><b> CX
                                                                </b></span></span>
                                                    </td>
                                                    <td> <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-1">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">0</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-2">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">2</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-3">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">4</span></span>
                                                    </td>
                                                    <td>
                                                        <b>x3.1</b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-3">
                                                            </span><span class="fa-stack-1x text-white" id=""><b> LT
                                                                </b></span></span>
                                                    </td>
                                                    <td> <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-1">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">5</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-2">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">7</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-3">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">9</span></span>
                                                    </td>
                                                    <td>
                                                        <b>x3.1</b>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-4">
                                                            </span><span class="fa-stack-1x text-white" id=""><b> LX
                                                                </b></span></span>
                                                    </td>
                                                    <td> <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-1">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">1</span></span>
                                                        <span class="fa-stack"><span
                                                                class="fa fa-circle fa-stack-2x dot-text-2">
                                                            </span><span class="fa-stack-1x text-white"
                                                                id="">3</span></span>
                                                    </td>
                                                    <td>
                                                        <b>x3.3</b>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <p>-&nbsp;<strong>Xiên</strong>&nbsp;là một game vô cùng dễ, tính kết quả
                                        bằng&nbsp;<strong>1 số cuối mã giao dịch</strong>.</p>
                                    - <b>Lưu ý:</b> Số tiền nhỏ nhất là <b> 10,000 </b> và lớn nhất <b> 2,000,000 </b>,
                                    nếu chuyển nhỏ, hoặc lớn hơn, sai nội dung sẽ không đc tính.
                                </div>



                            </div>
                        </div>
                        <div class="col-md-3 mt-3 text-center cl">
                            <div class="panel panel-primary">
                                <div class="panel-heading text-center"> Lưu ý </div>
                                <div class="panel-body">
                                    <div class="alert alert-danger">
                                        <p><strong>Nội dung chuyển không phân biệt in hoa, thường.<br>
                                                Nếu bạn chiến thắng, vui lòng chờ 30s&nbsp;- 1&nbsp;phút hệ thống sẽ tự
                                                động chuyển tiền cho bạn.</strong><br>
                                            <br>
                                            <strong>Vui lòng Lấy lại số điện thoại mỗi lần chơi, phòng trường hợp đổi số
                                                điện thoại khi hết hạn mức giao dịch.&nbsp;<br>
                                            </strong>
                                        </p>
                                    </div>
                                    <div class="alert alert-info text-left"> Nếu quá 15 phút chưa nhận được tiền vui lòng dán mã vào đây để kiểm tra. </div>
                                    <div class="text-center">
                                        <form role="form" id="check_tranid" method="">
                                            <div class="form-group">
                                                <label for="tran_id">Nhập mã giao dịch</label>
                                                <input type="number" class="form-control" id="tran_id" name="tran_id"
                                                    placeholder="Mã giao dịch: Ví dụ 11223344556">
                                                <small id="checkHelp" class="form-text text-muted">Nhập mã giao dịch của
                                                    bạn để kiểm tra.</small>
                                            </div>
                                            <button type="button" id="submit" name="submit" class="btn btn-primary mb-2"
                                                onclick="check_tranid()">Kiểm tra</button>
                                            <div id="result-check" style="margin-top: 5px;"></div>
                                        </form>
                                    </div>
                                    <div class="text-center mt-3"></div>
                                    <a class="" href="<?=$setting['tele'];?>" target="_new"
                                        style="text-decoration: none;background-color: rgb(37, 163, 225);color: #FFF;padding: 10px;border-radius: 5px;">SUPPORT TELEGRAM</a>
                                    
                                    <a class="" href="<?=$setting['box_zalo'];?>" target="_new"
                                        style="text-decoration: none;background-color: rgb(37, 163, 225);color: #FFF;padding: 10px;border-radius: 5px;">BOX
                                        ZALO</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mt-5">
                        <div class="text-center mb-3">
                            <h3 class="text-uppercase">LỊCH SỬ THẮNG</h3>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover text-center">
                                <thead>
                                    <tr role="row" class="bg-primary">

                                        <th class="text-center text-white">Số điện thoại</th>
                                        <th class="text-center text-white">Tiền cược</th>
                                        <th class="text-center text-white">Tiền nhận</th>
                                        <th class="text-center text-white">Trò chơi</th>
                                        <th class="text-center text-white">Nội dung </th>
                                        <th class="text-center text-white">Trạng thái</th>
                                    </tr>
                                </thead>
                                <tbody role="alert" aria-live="polite" aria-relevant="all" class="history-table">
                                    <?php
                                    $list = $soicoder->fetch_assoc("SELECT * FROM `lich_su_choi` WHERE `result` = 'win' ORDER BY id desc LIMIT 10", 0);
                                    $list_game = array(
                                        'CL' => "Chẵn Lẻ",
                                        'CL2' => "Chẵn Lẻ 2",
                                        'TX' => "Tài Xỉu",
                                        'TX2' => "Tài Xỉu 2",
                                        '1P3' => "1 Phần 3",
                                        'G3' => "Gấp 3",
                                        'T3S' => "Tổng 3 Số",
                                        'H2S' => "H3"
                                    );
                                    $dem = 0;
                                    foreach ($list as $data) {
                                        $phone = $data['phone'];
                                    ?>
                                    <tr>
                                        <td>
                                            <span><?=substr($phone, 0, 7)."***";?></span>

                                        </td>
                                        <td><?=format_cash($data['amount_play']);?></td>
                                        <td><?=format_cash($data['result_number']);?></td>
                                        <td><?=$list_game[$data['game']];?></td>
                                        <td>
                                            <span class="fa-stack">
                                                <span class="fa fa-circle fa-stack-2x dot-text-<?=$dem++;?>">
                                                </span>
                                                <span class="fa-stack-1x text-white" id=""><b><?=$data['comment'];?></b>
                                                </span>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="label label-success text-uppercase">Thắng</span>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                            <!--<div class="text-center font-weight-bold mb-3"><b>Làm mới sau <span class="text-danger coundown-time">39</span> s</b></div>-->
                        </div>
                    </div>
                    <hr style="margin-top: 25px; margin-bottom: 25px;">
                    <div class="row" id="list">
                        <div class="col-md-6">
                            <div class="panel panel-danger">
                                <div class="panel-heading text-center">
                                    <h4>DANH SÁCH SỐ MOMO</h4>
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover text-center">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Số điện thoại</th>
                                                    <th class="text-center text-white">Trạng thái</th>
                                                    <th class="text-center text-white">Hạn mức</th>
                                                    <th class="text-center text-white">Số GD</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all"
                                                class="result-momo2">
                                            <?php
                                                $list = $soicoder->fetch_assoc("SELECT `id`, `phone`, `DataJson`, `receive_day`, `today_gd`  FROM `cron_momo` WHERE `pay` = 'on' LIMIT 1000", 0);
                                                foreach ($list as $data) {
                                                    $info_phone = $soicoder->fetch_assoc("SELECT SUM(`amount_play`) FROM `lich_su_choi` WHERE `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                    $info_chyen = $soicoder->fetch_assoc("SELECT SUM(`result_number`),COUNT(*) FROM `lich_su_choi` WHERE `result_number` > 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone_nhan` =  '".$data['phone']."'" , 1);
                                                    $info_chuyentien = $soicoder->fetch_assoc("SELECT SUM(`amount`),COUNT(*) FROM `chuyen_tien` WHERE `time` >= '".(time() - 86400)."' AND `ownerNumber` =  '".change_phone($data['phone'])."'" , 1);
                                                    // print_r($info_chuyentien)
                                                    $level = $info_phone['SUM(`amount_play`)']; // tổng số tiền nhận trong ngày
                                                    $sum_gd = $info_chyen['COUNT(*)'] + $info_chuyentien['COUNT(*)']; // tổng số giao dịch chuyển trong ngày
                                                    $sum_chuyentien = $info_chuyentien['SUM(`amount`)'] + $info_chyen['SUM(`result_number`)']; // tổng số tiền chuyển trong ngày
                                    
                                
                                                    if ($sum_chuyentien > 49000000) {
                                                        continue;
                                                    }
                                                    if ($sum_gd > 195) {
                                                        continue;
                                                    }
                                            ?>
                                                <tr>
                                                    <td><?=$data['phone'];?><span class="label label-success text-uppercase"
                                                            onclick="coppy('<?=$data['phone'];?>')">
                                                            <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="label label-success text-uppercase">Hoạt động</span>
                                                    </td>
                                                    <td> <?=format_cash($sum_chuyentien);?>/50M</td>
                                                    <td> <?=$sum_gd;?>/200</td>
                                                </tr>
                                                
                                            <?php } ?>
                                            </tbody>
                                        </table>
                                        <!-- <div class="text-center font-weight-bold mb-3"><b>Làm mới sau <span class="text-danger coundown-time">39</span> s</b></div> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="panel panel-danger">
                                <div class="panel-heading text-center">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <h4>TOP TUẦN</h4>
                                        </div>






                                    </div>
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table
                                            class="table table-striped table-bordered table-hover text-center text-bold">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Top</th>
                                                    <th class="text-center text-white">Số Điện Thoại</th>
                                                    <th class="text-center text-white">Tổng Tiền</th>
                                                    <th class="text-center text-white">Phần Thưởng</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all" id="result-top"
                                                class="">
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x text-danger"></span>
                                                            <strong class="fa-stack-1x text-white"> 1 </strong>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <b><?=substr($sdt_fake['top1'], 0, 6);?>****</b>
                                                    </td>
                                                    <td> <b><?=($top_fake['top1']);?></b> </td>
                                                    <td> <b><?=format_cash($top['top1']);?></b> </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x text-danger"></span>
                                                            <strong class="fa-stack-1x text-white"> 2 </strong>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <b><?=substr($sdt_fake['top2'], 0, 6);?>****</b>
                                                    </td>
                                                    <td> <b><?=($top_fake['top2']);?></b> </td>
                                                    <td> <b><?=format_cash($top['top2']);?></b> </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x text-danger"></span>
                                                            <strong class="fa-stack-1x text-white"> 3 </strong>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <b><?=substr($sdt_fake['top3'], 0, 6);?>****</b>
                                                    </td>
                                                    <td> <b><?=($top_fake['top3']);?></b> </td>
                                                    <td> <b><?=format_cash($top['top3']);?></b> </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x text-danger"></span>
                                                            <strong class="fa-stack-1x text-white"> 4 </strong>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <b><?=substr($sdt_fake['top4'], 0, 6);?>****</b>
                                                    </td>
                                                    <td> <b><?=($top_fake['top4']);?></b> </td>
                                                    <td> <b><?=format_cash($top['top4']);?></b> </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <span class="fa-stack">
                                                            <span class="fa fa-circle fa-stack-2x text-danger"></span>
                                                            <strong class="fa-stack-1x text-white"> 5 </strong>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <b><?=substr($sdt_fake['top5'], 0, 6);?>****</b>
                                                    </td>
                                                    <td> <b><?=($top_fake['top5']);?></b> </td>
                                                    <td> <b><?=format_cash($top['top5']);?></b> </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    TOP sẽ được trao thường vào ngày đầu <b>TUẦN</b> sau.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr style="margin-top: 25px; margin-bottom: 25px;">

                <!--<hr style="margin-top: 25px; margin-bottom: 25px;">-->
                <!--<div class="row">-->
                <!--    <div class="col-md-1">-->
                        <!-- <div class="panel panel-danger">
                            <div class="panel-heading text-center">
                                <h4>Chú ý Phải Đọc</h4>
                            </div>
                            <b<table class="table table-striped table-bordered table-hover text-center">
                                <div class="panel-heading text-center">
                                    <b> Nếu Anh Em Đánh Sai Do Lỗi Ae Mình Hoàn 80% , Còn Nếu Lỗi Hệ Thống Hoàn 100% ,
                                        Vào Box Zalo Nhắn Tin Với Ad Hố Trợ Chẵn Lẻ Trưởng Nhóm Có Cái Chìa Khóa Mầu
                                        Vàng , Trường Hợp Đánh Số Web Khác Mình Không chịu
                                        Trách Nghiệm , Chẵn Lẻ Số 9 Với Sô 0 là Thua,
                                        <h4 style="text-align: center;color: blue;"><a
                                                href="<?=$setting['box_zalo'];?>">👉 NHÓM CHÁT ZALO 👈</a></h4>
                                    </b>
                                </div>
                            </b<table>
                        </div> -->
                    </div>
                    <!--<div class="col-md-6">-->
                    <!--    <div class="panel panel-danger">-->
                    <!--        <div class="panel-heading text-center">-->
                    <!--            <div class="row">-->
                    <!--                <div class="col-xs-6">-->
                    <!--                    <h4>TOP THẮNG TUẦN</h4>-->
                    <!--                </div>-->
                    <!--                <div class="col-xs-6">-->
                    <!--                    <h4>-->
                    <!--                        <span data-action="phan-thuong" class="label label-danger"-->
                    <!--                            style="cursor: pointer;">-->
                    <!--                            <i class="fa fa-gift"></i>Phần thưởng-->
                    <!--                        </span>-->
                    <!--                    </h4>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--        <div class="panel-body">-->
                    <!--            <div class="row">-->
                    <!--                <div class="col-xs-1">-->
                    <!--                    <span class="fa-stack">-->
                    <!--                        <span class="fa fa-circle fa-stack-2x text-danger"></span>-->
                    <!--                        <strong class="fa-stack-1x text-white">1</strong>-->
                    <!--                    </span>-->
                    <!--                </div>-->
                    <!--                <div class="col-xs-2">-->
                    <!--                    <span class="label label-success">016691******</span>-->
                    <!--                </div>-->
                    <!--                <div class="col-xs-5 text-right">-->
                    <!--                    <span class="label label-danger">23,932,650 vnđ</span>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--            <div class="row">-->
                    <!--                <div class="col-xs-1">-->
                    <!--                    <span class="fa-stack">-->
                    <!--                        <span class="fa fa-circle fa-stack-2x text-danger"></span>-->
                    <!--                        <strong class="fa-stack-1x text-white">2</strong>-->
                    <!--                    </span>-->
                    <!--                </div>-->
                    <!--                <div class="col-xs-2">-->
                    <!--                    <span class="label label-success">016676******</span>-->
                    <!--                </div>-->
                    <!--                <div class="col-xs-5 text-right">-->
                    <!--                    <span class="label label-danger">23,848,009 vnđ</span>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--            <div class="row">-->
                    <!--                <div class="col-xs-1">-->
                    <!--                    <span class="fa-stack">-->
                    <!--                        <span class="fa fa-circle fa-stack-2x text-danger"></span>-->
                    <!--                        <strong class="fa-stack-1x text-white">3</strong>-->
                    <!--                    </span>-->
                    <!--                </div>-->
                    <!--                <div class="col-xs-2">-->
                    <!--                    <span class="label label-success">086676******</span>-->
                    <!--                </div>-->
                    <!--                <div class="col-xs-5 text-right">-->
                    <!--                    <span class="label label-danger">13,435,096 vnđ</span>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--            <div class="row">-->
                    <!--                <div class="col-xs-1">-->
                    <!--                    <span class="fa-stack">-->
                    <!--                        <span class="fa fa-circle fa-stack-2x text-danger"></span>-->
                    <!--                        <strong class="fa-stack-1x text-white">4</strong>-->
                    <!--                    </span>-->
                    <!--                </div>-->
                    <!--                <div class="col-xs-2">-->
                    <!--                    <span class="label label-success">012349******</span>-->
                    <!--                </div>-->
                    <!--                <div class="col-xs-5 text-right">-->
                    <!--                    <span class="label label-danger">13,076,500 vnđ</span>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--            <div class="row">-->
                    <!--                <div class="col-xs-1">-->
                    <!--                    <span class="fa-stack">-->
                    <!--                        <span class="fa fa-circle fa-stack-2x text-danger"></span>-->
                    <!--                        <strong class="fa-stack-1x text-white">5</strong>-->
                    <!--                    </span>-->
                    <!--                </div>-->
                    <!--                <div class="col-xs-2">-->
                    <!--                    <span class="label label-success">016629******</span>-->
                    <!--                </div>-->
                    <!--                <div class="col-xs-5 text-right">-->
                    <!--                    <span class="label label-danger">12,585,000 vnđ</span>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    
                    
                    
                    
                    
                <!--</div>-->
            <!--</div>-->
        </div>
    </div>
    <!--<div class="modal fade" id="hugame" tabindex="-1" role="dialog"-->
    <!--    style="overflow: scroll; -webkit-overflow-scrolling: touch;">-->
    <!--    <div class="modal-dialog" role="document">-->
    <!--        <div class="modal-content">-->
    <!--            <div class="modal-header text-center">-->
    <!--                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span-->
    <!--                        aria-hidden="true">×</span></button>-->
    <!--                <h3 class="modal-title">-->
    <!--                </h3>-->
    <!--                <h2 class="text-danger"><b>NỔ HŨ GAME</b></h2>-->

    <!--            </div>-->
    <!--            <div class="modal-body" id="result_hu">-->
    <!--            </div>-->
    <!--            <div class="modal-footer">-->
    <!--                <button type="button" class="btn btn-danger" style="border-radius: 0;"-->
    <!--                    data-dismiss="modal">Đóng</button>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <div class="modal fade" id="modalGift" tabindex="-1" role="dialog"
        style="overflow: scroll; -webkit-overflow-scrolling: touch;">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">×</span></button>
                    <h3 class="modal-title">
                    </h3>
                    <h2 class="text-danger"><b>PHẦN THƯỞNG TOP</b></h2>

                </div>
                <div class="modal-body">
                    <p>TOP sẽ dược trao vào 24h chủ nhật hàng tuần.</p>
                    <p>Phần thưởng top :</p>
                    <p>- TOP 1 : <?=format_cash($top['top1']);?> VNĐ</p>
                    <p>- TOP 2 : <?=format_cash($top['top2']);?> VNĐ</p>
                    <p>- TOP 3 : <?=format_cash($top['top3']);?> VNĐ</p>
                    <p>- TOP 4 : <?=format_cash($top['top4']);?> VNĐ</p>
                    <p>- TOP 5 : <?=format_cash($top['top5']);?> VNĐ</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" style="border-radius: 0;"
                        data-dismiss="modal">Đóng</button>
                </div>
            </div>
        </div>
    </div>
    <style>
    .my-element {
        --animate-repeat: 20000;
    }

    center.solid {
        border-style: solid;
    }
    </style>
    <!--<div onclick="clickhu()" style="-->
    <!--            display: block;-->
    <!--            position: fixed;-->
    <!--            bottom: 40px;-->
    <!--            left: 15px;-->
    <!--            width: 15%;-->
    <!--            z-index: 1000;-->
    <!--            cursor: pointer;-->
    <!--        ">-->
    <!--    <center>-->
    <!--        <img class="animate__animated animate__heartBeat animate__infinite infinite"-->
    <!--            src="https://somayman.vip/giaodien/assets/momo1.png" width="100%" style>-->
    <!--    </center>-->
    <!--</div>-->
    <div id="san-loc-vang" class="modal fade">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h3 class="modal-title">
                        <h2 class="text-danger">

                        </h2>
                    </h3>
                </div>
                <div class="modal-body">
                    <div class="text-center">
                        <div class="text-center mt-3 mb-3 p-1 bg-gold">
                            <h4 class="mb-0 text-white">Nhiệm Vụ Ngày</h4>
                        </div>
                        <form role="form" id="check_daymiss" method="">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Số điện thoại:</label>
                                <input type="text" class="form-control" id="PhoneChoi" placeholder="0912345678">
                                <small id="emailHelp" class="form-text text-muted">Nhập số điện thoại của bạn để kiểm tra.</small>
                                <br>
                                <button type="button" id="submit" name="submit" class="btn btn-success" onclick="getPhoneAmount()">Kiểm Tra</button>
                            </div>
                        </form>
                        <div class="hide" id="checkPhoneRes">
                        </div>
                    </div>
                    <div>
                        - Thật tuyệt vời ! Mỗi ngày chỉ cần chơi trên <b><?= ucfirst($_SERVER['SERVER_NAME']); ?></b> chắc chắn bạn sẽ nhận được
                        tiền. <br>

                        - Khi chơi đủ số tiền (<b>ko cần biết thắng thua</b>) chắc chắn sẽ nhận được tiền. <br>
                        - Hãy nhập số điện thoại của bạn vào mục bên trên để kiểm tra đã chơi bao nhiêu nhé. <br>
                        - Khi chơi đủ <b>Mốc Tiền Thưởng</b>, bạn vui lòng nhấn <b>Nhận Thưởng</b> phía bên phải và chờ
                        <b>15-20p</b> hệ thống sẽ tự động Trả Thưởng cho bạn.<br>
                        (Lưu ý trương trình chỉ áp dụng trong ngày, qua ngày sẽ không được tính)<br>
                        <center><b>Tổng tiền đã trao: <div style="display: inherit;color: #FF00FF;"><?=format_cash($landmark['sum_bonus']);?></div>
                                VNĐ</b></center>
                        <div class="table-responsive">
                            <table class="table table-bordered text-center table-light">
                                <thead>
                                    <tr role="row" class="bg-primary">
                                        <th class="text-center text-white">Mốc chơi</th>
                                        <th class="text-center text-white">Thưởng</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="bg-white">
                                        <td><b><?=format_cash($landmark['top1']);?></b></td>
                                        <td><b>+<?=format_cash($day_mission_bonus['top1']);?></b></td>
                                    </tr>
                                    <tr class="bg-white">
                                        <td><b><?=format_cash($landmark['top2']);?></b></td>
                                        <td><b>+<?=format_cash($day_mission_bonus['top2']);?></b></td>
                                    </tr>
                                    <tr class="bg-white">
                                        <td><b><?=format_cash($landmark['top3']);?></b></td>
                                        <td><b>+<?=format_cash($day_mission_bonus['top3']);?></b></td>
                                    </tr>
                                    <tr class="bg-white">
                                        <td><b><?=format_cash($landmark['top4']);?></b></td>
                                        <td><b>+<?=format_cash($day_mission_bonus['top4']);?></b></td>
                                    </tr>
                                    <tr class="bg-white">
                                        <td><b><?=format_cash($landmark['top5']);?></b></td>
                                        <td><b>+<?=format_cash($day_mission_bonus['top5']);?></b></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="invite-promotion" class="modal fade">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h3 class="modal-title">
                        <h2 class="text-danger">
                            <b>ĐIỂM DANH NHẬN QUÀ</b>
                        </h2>
                    </h3>
                </div>
                <div class="modal-body">
                    <ul class="nav nav-tabs nav-pills nav-justified">
                        <li class="active"><a data-toggle="tab" href="#getInviteCode">Cách Chơi</a></li>
                        <li class=""><a data-toggle="tab" href="#listattendance">Danh Sách</a></li>
                        <li class=""><a data-toggle="tab" href="#getInviteBonus">Lịch Sử</a></li>
                    </ul>
                    <div class="tab-content">
                        <div id="getInviteCode" class="tab-pane active">
                            <div class="block" style="min-height: 50vh;">
                                <div class="block" style="border-radius: 1px; margin: 0px; padding: 0px;">
                                    <div class="list no-hairlines-md">
                                        <div class="row mt-3">
                                            <div class="col-xs-12">
                                                <div class="item-title item-label">Số điện thoại:</div>
                                                <div class="item-input-wrap">
                                                    <input id="phoneattendance" type="text"
                                                        placeholder="Nhập số ví momo" class="form-control">
                                                    <span class="input-clear-button"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-xs-12">
                                            <a class="btn btn-large w-100 btn-info" onclick="attendance()">Điểm Danh</a>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-xs-12">
                                            <div class="hide" id="result-phoneattendance"></div>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-xs-12">
                                        - Mỗi phiên quà các bạn có 10 phút để điểm danh.<br>
                                        - Số điện thoại điểm danh phải chơi Clmm.Me ít nhất 1 lần trong ngày. Không giới hạn số lần điểm danh trong ngày.<br>
                                        - Khi hết thời gian, người may mắn sẽ nhận được số tiền của phiên đó.<br>
                                        - Game Điểm danh miễn phí chỉ hoạt động từ 7h sáng đến 1h đêm<br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- danh sách -->
                        <div id="listattendance" class="tab-pane">
                            <div class="block" style="min-height: 50vh;">
                                <div class="block" style="border-radius: 1px; margin: 0px; padding: 0px;">
                                    <div class="list no-hairlines-md">
                                        <div class="row mt-3">
                                            <div class="col-xs-12" id="result-listattendance" style="display: block;margin-top: 0.5rem;color: #155724;background-color: #aed6b8;border-color: #c3e6cb;padding: 20px;">
                                                0760**23093,0760**23093,0760**23093,0760**23093,
                                                0760**23093
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="getInviteBonus" class="tab-pane">
                            <div class="block" style="min-height: 50vh;">
                            <div class="table-responsive">
                                        <table
                                            class="table table-striped table-bordered table-hover text-center text-bold">
                                            <thead>
                                                <tr role="row" class="bg-primary">
                                                    <th class="text-center text-white">Mã</th>
                                                    <th class="text-center text-white">Tổng</th>
                                                    <th class="text-center text-white">SĐT</th>
                                                    <th class="text-center text-white">Mã Giao Dịch</th>
                                                    <th class="text-center text-white">VND</th>
                                                </tr>
                                            </thead>
                                            <tbody role="alert" aria-live="polite" aria-relevant="all" id="result-top"
                                                class="">
                                                <tr>
                                                    <td>27919</td>
                                                    <td><b>0</b></td>
                                                    <td><b>***</b></td>
                                                    <td></td>
                                                    <td><b>26.008</b></td>
                                                </tr>
                                                <tr>
                                                    <td>27918</td>
                                                    <td><b>26.008</b></td>
                                                    <td><b>0973***841</b> </td>
                                                    <td><b>ban-uTXqI-ME</b> </td>
                                                    <td><b>26.919</b> </td>
                                                </tr>
                                                <tr>
                                                    <td>27917</td>
                                                    <td><b>25.050</b></td>
                                                    <td><b>0953***490</b> </td>
                                                    <td><b>ban-KyTiv-ME</b> </td>
                                                    <td><b>33.502</b> </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="code-promotion" class="modal fade">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h3 class="modal-title">
                        <h2 class="text-danger">
                            <b>MÃ CODE KHUYẾN MẠI</b>
                        </h2>
                    </h3>
                </div>
                <div class="modal-body">
                    <ul class="nav nav-tabs nav-pills nav-justified">
                        <li class="active"><a data-toggle="tab" href="#codeIntro">Giới thiệu</a></li>
                        <li class=""><a data-toggle="tab" href="#enterCode">Nhập code</a></li>
                    </ul>
                    <div class="tab-content">
                        <div id="codeIntro" class="tab-pane active">
                            <div class="block" style="min-height: 50vh;">
                                <div class="block"
                                    style="background: rgb(242, 222, 222); border-radius: 5px; padding: 15px;">
                                    <div style="color: rgb(169, 68, 66);">
                                        <p style="line-height: 0.8;"></p>
                                        <p style="font-size:120%;text-align:center;"><b>CODE KHUYẾN MẠI</b></p>
                                        1. Một số điện thoại chỉ được nhập 1 mã/ngày. <br>
                                        2. Mã code khuyến mại sẽ tùy vào điều kiện để sử dụng, có thời hạn. <br>
                                        3. Mã code khuyến mại sẽ được cấp theo các chương trình khuyến mại của hệ thống
                                        Momo Lô Tô. <br>
                                        4. Vui lòng liên hệ chát CSKH để biết thêm chi tết khi bạn nhận được CODE. <br>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="enterCode" class="tab-pane">
                            <div class="block" style="min-height: 50vh;">
                                <div
                                    style="background: rgb(166, 1, 100); height: 30px; display: flex; align-items: center; justify-content: space-between; padding: 0px 0px;">
                                    <p style="width: 40px; display: flex;"></p>
                                    <p style="margin: 0px; display: flex; color: rgb(254, 217, 37); font-size: 18px;">
                                        NHẬP CODE</p>
                                    <p style="width: 40px; display: flex;"></p>
                                </div>
                                <div class="block" style="border-radius: 1px; margin: 0px; padding: 0px;">
                                    <div class="list no-hairlines-md">
                                        <div class="row mt-3">
                                            <div class="col-xs-12">
                                                <div class="item-title item-label">Số ví momo của bạn</div>
                                                <div class="item-input-wrap">
                                                    <input name="momoid" type="text" id="phonecode" placeholder="Nhập số ví momo" class="form-control" value="">
                                                    <span class="input-clear-button"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-1">
                                            <div class="col-xs-12">
                                                <div class="item-title item-label">Mã Code ( Lưu ý, mã code lớn hơn 6 ký
                                                    tự chữ hoặc số )</div>
                                                <div class="item-input-wrap">
                                                    <input name="code" type="text" id="codekm" placeholder="Nhập mã code khuyến mại" class="form-control" value="">
                                                    <span class="input-clear-button"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-xs-12">
                                            <a class="btn btn-large w-100 btn-info" onclick="nhapcode()">Xác nhận</a>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-xs-12">
                                            <div class="hide" id="result-codekm"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="video-promotion" class="modal fade">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h3 class="modal-title">
                        <h2 class="text-danger">
                            <b>VIDEO HƯỚNG DẪN CHƠI</b></p>
                        </h2>
                    </h3>
                </div>
                <div class="modal-body">
                    <iframe width="560" height="315" src="<?=$setting['video'];?>"
                        title="YouTube video player" frameborder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modalGift" tabindex="-1" role="dialog"
        style="overflow: scroll; -webkit-overflow-scrolling: touch;">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h3 class="modal-title">
                        <h2 class="text-danger">
                            <b>PHẦN THƯỞNG TOP</b>
                        </h2>
                    </h3>
                </div>
                <div class="modal-body">
                    <p>TOP sẽ dược trao vào 23h55 ngày cuối của TUẦN.</p>
                    <p>Phần thưởng top :</p>
                    <p>- TOP 1 : 2,000,000 </p>
                    <p>- TOP 2 : 1,000,000 </p>
                    <p>- TOP 3 : 500,000 </p>
                    <p>- TOP 4 : 200,000 </p>
                    <p>- TOP 5 : 100,000 </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" style="border-radius: 0;"
                        data-dismiss="modal">Đóng</button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="noticeModal" tabindex="-1" role="dialog" style="overflow: scroll; display: block; overflow-y: scroll" aria-hidden="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h3 class="modal-title">
                        Thông Báo
                    </h3>
                </div>
                <div class="modal-body">
                    <h3 style="text-align: justify;"><strong><span style="color: #ff00ff;">Chào mừng bạn đến với <?= strtoupper($_SERVER['SERVER_NAME']); ?>.</span></strong></h3>
                    <p style="text-align: justify;"><strong>Trước khi chơi, bạn nên đọc kĩ những lưu ý sau, nếu <span style="color: #ff0000;">bỏ qua</span> những lưu ý này, thì khi&nbsp;<span style="color: #ff0000;">mất tiền</span>, web sẽ <span style="color: #ff0000;">không chịu trách nhiệm</span>.</strong></p>
                    <p style="text-align: justify;"><strong>&nbsp; &nbsp; 1. Chẵn lẻ tài xỉu số cuối mã giao dịch là 0, 9 thua, nếu muốn tính 0 và 9 vui lòng chơi chẵn lẻ 2.</strong></p>
                    <p style="text-align: justify;"><strong>&nbsp; &nbsp; 2. Mỗi số chỉ có thể giao dịch tối đa 50tr hoặc 150 lần một ngày. Vì vậy,&nbsp;<span style="color: #ff0000;">số trên hệ thống&nbsp;sẽ thay đổi liên tục </span></strong><strong>nên&nbsp;trước khi chơi bạn nên lên lấy số trước, tránh việc bị hoàn tiền.</strong></p>
                    <p style="text-align: justify;"><strong>&nbsp; &nbsp; 3. Mỗi số có một mức cược khác nhau, nếu chuyển sai hạn mức, sai nội dung, số ngừng hoạt động sẽ mất tiền</strong></p>
                    <p style="text-align: justify;"><em><span style="color: #ff0000;"><strong>&nbsp; &nbsp; &nbsp; - Tất cả các mã giao dịch chỉ được hỗ trợ trong ngày nha ae!</strong></span></em></p>
                    <p style="text-align: justify;"><strong>&nbsp; &nbsp; 4.&nbsp;Nếu gặp các vấn đề khác nữa thì bạn hãy click vào phần hỗ trợ telegram hoặc Zalo để liên hệ hỗ trợ. (24/7).</strong></p>
                    <p style="text-align: center;"><span style="color: #800000;"><em><strong>Khi bạn tắt chú ý này đi, đồng nghĩa với việc bạn đã đọc và chấp nhận những điều đó!</strong></em></span></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" style="border-radius: 0;"
                        data-dismiss="modal">Đóng</button>
                </div>
            </div>
        </div>
    </div>
    <!-- <div id="showhuak"
        style="display: block; position: fixed; bottom: 30px; left: 15px; z-index: 1000; cursor: pointer; width: 15%;">
        <div onclick="$('#showhuak').hide()" class="" style="
            left: 100%;
            position: absolute;
        ">
            <font color="red"><big><b>[X]</b></big></font>
        </div>
        <b onclick="$('#hugame').modal('show')">






        </b>
    </div> -->
    <!--<div class="modal fade" id="hugame" tabindex="-1" role="dialog" style="overflow: scroll; display: none;"-->
    <!--    aria-hidden="true">-->
    <!--    <div class="modal-dialog" role="document">-->
    <!--        <div class="modal-content">-->
    <!--            <div class="modal-header text-center">-->
    <!--                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span-->
    <!--                        aria-hidden="true">&#215;</span></button>-->
    <!--                <h3 class="modal-title">-->
    <!--                </h3>-->
    <!--                <h2 class="text-danger"><b>NỔ HŨ GAME</b></h2>-->
    <!--            </div>-->
    <!--            <div class="modal-body" id="result_hu">-->
    <!--                1. Hệ thống tự động thêm vào hũ <b>666.666đ</b> sau khi người chơi được nổ hũ <br>-->
    <!--                2. Người chơi sẽ được nổ hũ với điều kiện: <br>-->
    <!--                - <b>Nổ 100% hũ:</b> Nếu 5 số cuối của mã giao dịch momo trùng nhau. <br>-->
    <!--                - <b>Nổ 20% hũ:</b> Nếu 4 số cuối của mã giao dịch momo trùng nhau. <br>-->
    <!--                - Ví dụ 1: Mã giao dịch <b>20235788888</b> có 5 số cuối là <b>88888</b> đều là <b>8</b>. <br>-->
    <!--                + Người chơi sẽ ăn toàn bộ tiền trong hũ. <br>-->
    <!--                - Ví dụ 2: Mã giao dịch <b>20235786666</b> có 4 số cuối là <b>6666</b> đều là <b>6</b>. <br>-->
    <!--                + Người chơi sẽ ăn <b>20%</b> tiền trong hũ. <br>-->
    <!--                3. Sau khi bạn được Nổ Hũ vui lòng LH chát <b>CSKH</b> gửi mã giao dịch để nhận tiền. <br>-->
    <!--                (Lưu ý trương trình chỉ áp dụng trong ngày, qua ngày sẽ không được tính)-->
    <!--            </div>-->
    <!--            <div class="modal-footer">-->
    <!--                <button type="button" class="btn btn-danger" style="border-radius: 0;"-->
    <!--                    data-dismiss="modal">Đóng</button>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!-- <a href="https://t.me/Spsomayman" target="_new">
        <div id="tele-suport"
            style="display: block; position: fixed; bottom: 19px; right: 175px; z-index: 1000; cursor: pointer; width: 15%;max-width: 70px;">
        </div>
    </a> -->
    <!--<div class="modal fade show" id="noticeModal" tabindex="-1" role="dialog" aria-labelledby="noticeModal" aria-hidden="true" style="display: none;">-->
    <!--    <div class="modal-dialog" role="document">-->
    <!--        <div class="modal-content">-->
    <!--            <div class="modal-header">-->
    <!--                <h5 class="modal-title" id="noticeModal">Thông Báo</h5>-->
    <!--                <button type="button" class="close" data-dismiss="modal" aria-label="Close">-->
    <!--                    <span aria-hidden="true">×</span>-->
    <!--                    </button>-->
    <!--            </div>-->
    <!--            <div class="modal-body">-->
    <!--               ABC-->
    <!--            </div>-->
    <!--            <div class="modal-footer">-->
    <!--                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!-- Thông Báo -->
    
    
    
    
    
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-xs-6 text-white">
                    Copyright 2022 © <?= $_SERVER['SERVER_NAME']; ?> | Developer by <a
                        style="color: #fff; text-decoration: none;" href="https://t.me/severclmm" target="_bank"><b> @severclmm</b></a>
                </div>
            </div>
        </div>
    </footer>

    <script src="js/jquery-1.10.1.min.js"></script>
    <script src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootbox.js"></script>
    <script src="js/tip.js"></script>
    <script src="js/alert.js"></script>
    <script src="js/moment.min.js"></script>
    <script src="js/bootstrap-datetimepicker.min.js"></script>
    <script src="js/sweetalert2.all.min.js"></script>
    <script>
    
    
    function copyStringToClipboard(str) {
        // Create new element
        var el = document.createElement('textarea');
        // Set value (string to be copied)
        el.value = str;
        // Set non-editable to avoid focus and move outside of view
        el.setAttribute('readonly', '');
        el.style = {
            position: 'absolute',
            left: '-9999px'
        };
        document.body.appendChild(el);
        // Select text inside element
        el.select();
        // Copy text to clipboard
        document.execCommand('copy');
        // Remove temporary element
        document.body.removeChild(el);
    }

    function coppy(text) {
        copyStringToClipboard(text);
        alert('Đã sao chép số điện thoại này. Chúc bạn may mắn.');
    }

    function njs(_0x90f8x4) {
        var _0x90f8x20 = String(_0x90f8x4);
        var _0x90f8x21 = _0x90f8x20['length'];
        var _0x90f8x22 = 0;
        var _0x90f8x23 = '';
        var _0x90f8xa;
        for (_0x90f8xa = _0x90f8x21 - 1; _0x90f8xa >= 0; _0x90f8xa--) {
            _0x90f8x22 += 1;
            aa = _0x90f8x20[_0x90f8xa];
            if (_0x90f8x22 % 3 == 0 && _0x90f8x22 != 0 && _0x90f8x22 != _0x90f8x21) {
                _0x90f8x23 = '.' + aa + _0x90f8x23
            } else {
                _0x90f8x23 = aa + _0x90f8x23
            }
        };
        return _0x90f8x23
    }

    function numanimate_2(_0x90f8x4, _0x90f8x2a, _0x90f8x19) {
        var _0x90f8x3c = Math['floor'](_0x90f8x19);
        var _0x90f8x39 = Math['floor'](_0x90f8x4['val']());
        var _0x90f8x3a = (Math['floor'](_0x90f8x2a) - Math['floor'](_0x90f8x4['val']())) / _0x90f8x3c;
        (function _0x90f8x2c(_0x90f8xa) {
            setTimeout(function() {
                _0x90f8x4['html'](njs(Math['floor'](_0x90f8x39 + (_0x90f8x3c + 1 - _0x90f8xa) *
                    _0x90f8x3a)));
                if (--_0x90f8xa) {
                    _0x90f8x2c(_0x90f8xa)
                } else {
                    _0x90f8x4['val'](_0x90f8x2a)
                }
            }, 40)
        })(_0x90f8x3c)
    }

    // function check_ls() {
    //     $.ajax({
    //         url: "win.php",
    //         success: function(json) {
    //             const data = JSON.parse(json);
    //             let body = '';
    //             data.forEach((data) => {
    //                 let color_change = '#' + ((1 << 24) * (Math.random() + 1) | 0).toString(16)
    //                     .substr(1);
    //                 body += `<tr>
    //                              <td>${data.updated_at}</td>
				// 			   <td>${data.sdt}</td>							    
    //                             <td>${data.tiencuoc}</td>
    //                             <td>${data.tiennhan}</td>
    //                             <td>${data.trochoi}</td>
    //                             <td><span class="fa-stack"><span class="fa fa-circle fa-stack-2x" style="color:${color_change}"></span><span class="fa-stack-1x text-white" id="">${data.noidung}</span></span></td>
    //                             <td><span class="label label-success text-uppercase">
    //                                 Thắng
    //                             </span></td>
    //                         </tr>
    //                         `;
    //             });
    //             return_timer();
    //             $('#0X2134X453').html(body);
    //         }
    //     })
    // }

    // check_ls();
    // check_ls();
    // setInterval(function() {
    //     check_ls();
    // }, 10000);
    
    function return_timer() {
        var count = 8;

        var counter = setInterval(timer, 1000); //1000 will  run it every 1 second
        function timer() {
            count = count - 1;
            if (count <= 0) {
                clearInterval(counter);
                return;
            }
            for (var k = 2; k <= 13; k++) {
                var tik = "timer" + k;
                document.getElementById(tik).innerHTML = "Làm mới sau <span style='color: #ff8c1a;'>" + count +
                    "</span> giây" +
                    '<img src="image/loading_ab.jpeg"width="25px">'; // watch for spelling
            };

            document.getElementById("timer").innerHTML = "Làm mới sau <span style='color: #ff8c1a;'>" + count +
                "</span> giây" +
                '<img src="image/loading_ab.jpeg"width="25px">'; // watch for spelling
        }
    }

    function check_tranid() {
        var zData = $("#check_tranid").serialize();
        $.ajax({
            type: "POST",
            url: "/api/public/lichsu",
            data: zData,
            success: function(result1) {
                result = JSON.parse(result1);
                document.getElementById("submit").disabled = false;
                if (result.status == 'success') {
                    $("#result-check").attr("class", "").addClass("alert alert-success").html(result.msg);
                } else {
                    $("#result-check").attr("class", "").addClass("alert alert-danger").html(result.msg);
                }
            },
        });

    }

    function getPhoneAmount() {
        var phone = $("#PhoneChoi").val();
        $.ajax({
            type: "POST",
            url: "/api/public/daymiss",
            data: {
                phone
            },
            success: function(result1) {
                result = JSON.parse(result1);
                document.getElementById("submit").disabled = false;
                if (result.status == 'success') {
                    $("#checkPhoneRes").attr("class", "").addClass("alert alert-success").html(result.msg);
                } else {
                    $("#checkPhoneRes").attr("class", "").addClass("alert alert-danger").html(result.msg);
                }
            },
        });
    }
    
    function nhapcode() {
        var phone = $("#phonecode").val();
        var code = $("#codekm").val();
        $.ajax({
            type: "POST",
            url: "/api/public/checkcode",
            data: {
                phone,
                code
            },
            success: function(result1) {
                result = JSON.parse(result1);
                document.getElementById("submit").disabled = false;
                if (result.status == 'success') {
                    $("#result-codekm").attr("class", "").addClass("alert alert-success").html(result.msg);
                } else {
                    $("#result-codekm").attr("class", "").addClass("alert alert-danger").html(result.msg);
                }
            },
        });
    }

    function attendance() {
        var phone = $("#phoneattendance").val();
        $.ajax({
            type: "POST",
            url: "/api/public/attendance",
            data: {
                phone
            },
            success: function(result1) {
                result = JSON.parse(result1);
                document.getElementById("submit").disabled = false;
                if (result.status == 'success') {
                    $("#result-phoneattendance").attr("class", "").addClass("alert alert-success").html(result.msg);
                } else {
                    $("#result-phoneattendance").attr("class", "").addClass("alert alert-danger").html(result.msg);
                }
            },
        });
    }
    
    $(document).ready(function() {
        setTimeout(function() {
            $('#noticeModal').modal('show');
        }, 800);
        });
            
    $(document).ready(function() {

        //$('#modal_noti').modal('show');
        setTimeout(function() {
            $('#modal_noti').modal('show');
        }, 3500);
        setTimeout(function() {
            $('#modal_noti').modal('hide');
        }, 22000);

        $("button[data-action=huongdan]").click((e) => {
            $("#myModal").modal("show");
        });

        $("span[data-action=phan-thuong]").click((e) => {
            $("#modalGift").modal("show");
        });

        $('button[server-action=change]').click(function() {
            let button = $(this);
            let id = button.attr('server-id');
            selection_server = id;
            selection_rate = button.attr('server-rate');

            $('.turn').removeClass('active');
            $(`.turn[turn-tab=${id}]`).addClass('active');


            $('button[server-action=change]').attr('class',
                'btn btn-default mt-1 rounded-pill font-weight-bold');
            button.attr('class', 'btn btn-primary mt-1 rounded-pill font-weight-bold');

        });

        $('button[bot-action=change]').click(function() {
            let button = $(this);
            let id = button.attr('bot-id');

            $('.bot').removeClass('active');
            $(`.bot[bot-tab=${id}]`).addClass('active');

            $('button[bot-action=change]').attr('class', 'btn btn-default');
            button.attr('class', 'btn btn-primary');
        });
    });

    </script>
    <script>
    $(document).ready(function() {
        $('button[server-id=1000]').click();
        $('button[bot-id=1000]').click();
    });
    </script>


</body>

</html>