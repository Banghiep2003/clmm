<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');

$type = check_string($_POST['type']);

if ($type == 'config') {
    $soicoder->update("settings", array(
        'status' => $_POST['status'],
        'url' => $_POST['url'],
        'favion' => $_POST['favion'],
        'logo' => $_POST['logo'],
        'description' => $_POST['description'],
        'keyword' => $_POST['keyword'],
        'limit_trans' => $_POST['limit_trans'],
        'content' => $_POST['content'],
        'video' => $_POST['video'],
        'tele' => $_POST['tele'],
        'box_tele' => $_POST['box_tele'],
        'box_zalo' => $_POST['box_zalo']
    ), "`id` = '1' ");
} else if ($type == 'top') {
    $soicoder->update("top_up", array(
        'top1' => $_POST['top1'],
        'top2' => $_POST['top2'],
        'top3' => $_POST['top3'],
        'top4' => $_POST['top4'],
        'top5' => $_POST['top5']
    ), "`id` = '1' ");
} else if ($type == 'topfake') {
    // print_r($_POST);
    // die;
    $soicoder->update("top_up", array(
        'top1' => $_POST['sdt1'],
        'top2' => $_POST['sdt2'],
        'top3' => $_POST['sdt3'],
        'top4' => $_POST['sdt4'],
        'top5' => $_POST['sdt5']
    ), "`id` = '2' ");
    $soicoder->update("top_up", array(
        'top1' => $_POST['top1'],
        'top2' => $_POST['top2'],
        'top3' => $_POST['top3'],
        'top4' => $_POST['top4'],
        'top5' => $_POST['top5']
    ), "`id` = '3' ");
} else if ($type == 'day_mission') {
    $soicoder->update("day_miss_up", array(
        'top1' => $_POST['landmark1'],
        'top2' => $_POST['landmark2'],
        'top3' => $_POST['landmark3'],
        'top4' => $_POST['landmark4'],
        'top5' => $_POST['landmark5'],
        'sum_bonus' => $_POST['sum_bonus'],
    ), "`id` = '1' ");
    $soicoder->update("day_miss_up", array(
        'top1' => $_POST['top1'],
        'top2' => $_POST['top2'],
        'top3' => $_POST['top3'],
        'top4' => $_POST['top4'],
        'top5' => $_POST['top5'],
        'sum_bonus' => $_POST['sum_reward_daymiss'],
    ), "`id` = '2' ");
    $soicoder->update("settings", array(
        'momo_reward_daymiss' => $_POST['momo_reward_daymiss'],
        'sum_reward_daymiss' => $_POST['sum_bonus'],
    ), "`id` = '1' ");


} else if ($type == 'attendance') {
    $soicoder->update("attendance", array(
        'momo_reward' => $_POST['momo_reward'],
        'time_turn' => $_POST['time_turn'],
        'min' => $_POST['min'],
        'max' => $_POST['max'],
        'sum_fake' => $_POST['sum_fake']
    ), "`id` = '1' ");
}


echo "<script language='javascript'>alert('Cập Nhật Thành Công');window.location='/setting/setting.php';</script>";