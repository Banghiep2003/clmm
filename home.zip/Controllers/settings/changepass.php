<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');

$oldpass = check_string($_POST['oldpass']);
$password = check_string($_POST['password']);
$newpassword = check_string($_POST['newpassword']);


$query = $soicoder->get_list("SELECT * FROM `users` WHERE `username` = '".$_SESSION['username']."' ");
// print_r($query);
if ($oldpass == '' || $password == '' || $newpassword == '') {
    echo '<script type="text/javascript">alert("Vui Lòng Nhập Đầy Đủ Thông Tin");setTimeout(function(){ location.href = "/setting/changepass.php" },1500);</script>';
    die;
} else if ($oldpass !== decrypt($query[0]['password'], 'soicoder', 'khonglammadoicoanthichicoancutandaubuoi')) {
    echo '<script type="text/javascript">alert("Mật Khẩu Cũ Không Chính Xác");setTimeout(function(){ location.href = "/setting/changepass.php" },1500);</script>';
    die;
} else if ($password !== $newpassword) {
    echo '<script type="text/javascript">alert("Nhập Lại Mật Khẩu Không Đúng");setTimeout(function(){ location.href = "/setting/changepass.php" },1500);</script>';
    die;
} else if ($oldpass == $password) {
    echo '<script type="text/javascript">alert("Mật Khẩu Mới Không Được Trùng Với Mật Khẩu Cũ");setTimeout(function(){ location.href = "/setting/changepass.php" },1500);</script>';
    die;
} else {
    $passenc = encrypt($password, 'soicoder', 'khonglammadoicoanthichicoancutandaubuoi');
    $soicoder->update("users", array(
        'password' => $passenc,
        'token' => createToken(),
        'time' => date('H:i:s d/m/Y')
    ), "`username` = '".$_SESSION['username']."' ");
    echo '<script type="text/javascript">alert("Đổi Mật Khẩu Thành Công, Vui Lòng Đăng Nhập Lại");setTimeout(function(){ location.href = "/login" },1000);</script>';
    die;
}


