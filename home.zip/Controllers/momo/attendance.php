<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
$phone = check_string($_POST['phone']);

$return = array(
    'status' => 'success',
    'msg' => "Điểm Danh Thành Công"
);
die(json_encode($return));