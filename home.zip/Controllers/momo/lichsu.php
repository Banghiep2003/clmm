<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
$tran_id = check_string($_POST['tran_id']);

$check = $soicoder->num_rows("SELECT * FROM `lich_su_choi` WHERE `tranId` = '".$tran_id."' LIMIT 1 ");

if ($check == 0) {
    $return = array(
        'status' => 'error',
        'msg' => "Không Tồn Tại Mã Giao Dịch Này"
    );
    die(json_encode($return));
} else {
    $data = $soicoder->fetch_assoc("SELECT * FROM `lich_su_choi` WHERE `tranId` = '".$tran_id."' LIMIT 1 ", 1);
    if ($data['comment'] == 'NULL') {
        $return = array(
            'status' => 'error',
            'msg' => "Giao Dịch Không Có Nội Dung (Có Thể Do Lỗi)"
        );
        die(json_encode($return));
    } else {
        if ($data['result'] == 'win' && $data['status'] == 'done') {
            $return = array(
                'status' => 'success',
                'msg' => "WIN <br>
                Mã giao dịch : #$tran_id <br>
                Tiền cược : ".(number_format($data['amount_play']))."<br>
                Nội dung : ".($data['comment'])."<br>
                Thời gian : ".($data['time_tran'])."<br>
                Trạng Thái : ".$data['result_text']."
                "
            );
            die(json_encode($return));
        } else if ($data['status'] == 'wait' || $data['status'] == 'wait_auto') {
            $return = array(
                'status' => 'success',
                'msg' => "WIN | Lỗi Momo, Có Thể Admin Thanh Toán Tay Hoặc Tự Động Vào Ngày Mai"
            );
            die(json_encode($return));
        } else {
            $return = array(
                'status' => 'error',
                'msg' => "LOSE <br>
                Mã giao dịch : #$tran_id <br>
                Tiền cược : ".(number_format($data['amount_play']))."<br>
                Nội dung : ".($data['comment'])."<br>
                Thời gian : ".date('H:i:s d/m/Y', $data['time'])."<br>
                Trạng Thái : ".$data['result_text'].""
            );
            die(json_encode($return));
        }
    }
}


