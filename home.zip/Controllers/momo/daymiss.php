<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
$phone = check_string($_POST['phone']);


date_default_timezone_set('Asia/Ho_Chi_Minh');
$check = $soicoder->num_rows("SELECT * FROM `day_miss_his` WHERE `phone` =  '".$phone."' AND `day` = '".date('d/m/Y')."' LIMIT 1 ");
$day_mission = $soicoder->fetch_assoc("SELECT * FROM `day_miss_up` ", 0);
$landmark = $day_mission[0];
$day_mission_bonus = $day_mission[1];

// // echo $check; die;
// if ($check !== 0) {
    
    $check_top_1 = $soicoder->num_rows("SELECT * FROM `day_miss_his` WHERE `day` = '".date('d/m/Y')."' AND `phone` =  '".$phone."' LIMIT 1");
    $check_top_2 = $soicoder->num_rows("SELECT * FROM `day_miss_his` WHERE `day` = '".date('d/m/Y')."' AND `phone` =  '".$phone."' LIMIT 1");
    $check_top_3 = $soicoder->num_rows("SELECT * FROM `day_miss_his` WHERE `day` = '".date('d/m/Y')."' AND `phone` =  '".$phone."' LIMIT 1");
    $check_top_4 = $soicoder->num_rows("SELECT * FROM `day_miss_his` WHERE `day` = '".date('d/m/Y')."' AND `phone` =  '".$phone."' LIMIT 1");
    $check_top_5 = $soicoder->num_rows("SELECT * FROM `day_miss_his` WHERE `day` = '".date('d/m/Y')."' AND `phone` =  '".$phone."' LIMIT 1");
    // check tổng chơi
    // echo $phone;

    $check = $soicoder->fetch_assoc("SELECT SUM(`amount_play`),SUM(`result_number`) FROM `lich_su_choi` WHERE `amount_play` >= 0 AND `result_number` >= 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone` =  '".$phone."' ORDER BY id desc" , 1);
    $tongchoi =$check['SUM(`amount_play`)'];
    if ($tongchoi < $landmark['top1']) {
        $return = array(
            'status' => 'error',
            'msg' => "Chưa Đủ Hạn Mức"
        );
        die(json_encode($return));
    }
    
    if ($check_top_1 == 0 && $tongchoi > $landmark['top1']) {
        $soicoder->insert('day_miss_his' , array (
            'day' => date('d/m/Y'),
            'phone' => $phone,
            'sum_play' => $tongchoi,
            'top' => '1',
            'bonus' => $day_mission_bonus['top1'],
            'status' => 'wait',
            'time' => time()
        ));
    }
    
    if ($check_top_2 == 0 && $tongchoi > $landmark['top2']) {
        $soicoder->insert('day_miss_his' , array (
            'day' => date('d/m/Y'),
            'phone' => $phone,
            'sum_play' => $tongchoi,
            'top' => '2',
            'bonus' => $day_mission_bonus['top2'],
            'status' => 'wait',
            'time' => time()
        ));
    }
    
    if ($check_top_3 == 0 && $tongchoi > $landmark['top3']) {
        $soicoder->insert('day_miss_his' , array (
            'day' => date('d/m/Y'),
            'phone' => $phone,
            'sum_play' => $tongchoi,
            'top' => '3',
            'bonus' => $day_mission_bonus['top3'],
            'status' => 'wait',
            'time' => time()
        ));
    }
    
    if ($check_top_4 == 0 && $tongchoi > $landmark['top4']) {
        $soicoder->insert('day_miss_his' , array (
            'day' => date('d/m/Y'),
            'phone' => $phone,
            'sum_play' => $tongchoi,
            'top' => '4',
            'bonus' => $day_mission_bonus['top4'],
            'status' => 'wait',
            'time' => time()
        ));
    }
    
    
    
    
// } else  {
//     $check = $soicoder->fetch_assoc("SELECT SUM(`amount_play`),SUM(`result_number`) FROM `lich_su_choi` WHERE `amount_play` >= 0 AND `result_number` >= 0 AND `time_tran` = '".date('d/m/Y')."' AND `phone` =  '".$phone."' ORDER BY id desc" , 1);
//     $tongchoi =$check['SUM(`amount_play`)'];
//     if ($tongchoi < $landmark['top1']) {
//         $return = array(
//             'status' => 'error',
//             'msg' => "Chưa Đủ Hạn Mức"
//         );
//         die(json_encode($return));
//     }
    
//     if ($tongchoi > $landmark['top1']) {
//         $soicoder->insert('day_miss_his' , array (
//             'day' => date('d/m/Y'),
//             'phone' => $phone,
//             'sum_play' => $tongchoi,
//             'top' => '1',
//             'bonus' => $day_mission_bonus['top1'],
//             'status' => 'wait',
//             'time' => time()
//         ));
//     }
    
//     if ($tongchoi > $landmark['top2']) {
//         $soicoder->insert('day_miss_his' , array (
//             'day' => date('d/m/Y'),
//             'phone' => $phone,
//             'sum_play' => $tongchoi,
//             'top' => '2',
//             'bonus' => $day_mission_bonus['top2'],
//             'status' => 'wait',
//             'time' => time()
//         ));
//     }
    
//     if ($tongchoi > $landmark['top3']) {
//         $soicoder->insert('day_miss_his' , array (
//             'day' => date('d/m/Y'),
//             'phone' => $phone,
//             'sum_play' => $tongchoi,
//             'top' => '3',
//             'bonus' => $day_mission_bonus['top3'],
//             'status' => 'wait',
//             'time' => time()
//         ));
//     }
    
//     if ($tongchoi > $landmark['top4']) {
//         $soicoder->insert('day_miss_his' , array (
//             'day' => date('d/m/Y'),
//             'phone' => $phone,
//             'sum_play' => $tongchoi,
//             'top' => '4',
//             'bonus' => $day_mission_bonus['top4'],
//             'status' => 'wait',
//             'time' => time()
//         ));
//     }
    
//     if ($tongchoi > $landmark['top5']) {
//         $soicoder->insert('day_miss_his' , array (
//             'day' => date('d/m/Y'),
//             'phone' => $phone,
//             'sum_play' => $tongchoi,
//             'top' => '5',
//             'bonus' => $day_mission_bonus['top5'],
//             'status' => 'wait',
//             'time' => time()
//         ));
//     }
    
    $return = array(
        'status' => 'success',
        'msg' => "Đã Check Thành Công, Vui Lòng Đợi Trả Thưởng"
    );
    die(json_encode($return));
// }
