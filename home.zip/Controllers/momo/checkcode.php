<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/momo/momo.php');

$phone = change_phone(check_string($_POST['phone']));
$code = check_string($_POST['code']);

// error_reporting(E_ALL);
$check_code = $soicoder->num_rows("SELECT * FROM `code` WHERE `code` = '".$code."' LIMIT 1", 1);
if ($check_code == 0) {
    $return = array(
        'status' => 'error',
        'msg' => "Mã Code Không Tồn Tại"
    );
    die(json_encode($return));
}
$his = $soicoder->num_rows("SELECT * FROM `code_his` WHERE `code` = '".$code."' AND `momo` =  '".$phone."' LIMIT 1");
if ($his == 0) {
    $data = $soicoder->fetch_assoc("SELECT * FROM `code` WHERE `code` = '".$code."' LIMIT 1", 1);
    // print_r($data); die;
    if ($data['status'] == 'off') {
        $return = array(
            'status' => 'error',
            'msg' => "Mã Code Đã Bị Khóa"
        );
        die(json_encode($return));
    } else if ($data['momo_reward'] == 'NULL') {
        $return = array(
            'status' => 'error',
            'msg' => "Lỗi Do Momo Trả Thưởng Không Tồn Tại"
        );
        die(json_encode($return));
    } else if ($data['entered'] >= $data['limit_import']) {
        $return = array(
            'status' => 'error',
            'msg' => "Đã Hết Lượt Nhập Code"
        );
        die(json_encode($return));
    } else {
        $check = $soicoder->num_rows("SELECT phone FROM `lich_su_choi` WHERE `result` = 'win' AND `phone` =  '".$phone."'" , 1);
        // print_r($check); die;
        if ($check == 0) {
            $return = array(
                'status' => 'error',
                'msg' => "Số Điện Thoại Phải Win Ít Nhất 1 Lần Trên Hệ Thống"
            );
            die(json_encode($return));
        }
        $account = $data['momo_reward'];
        $select = $soicoder->num_rows("SELECT * FROM `cron_momo` WHERE `phone` = '".$account."' LIMIT 1 ");
        if ($select == 0) {
            $return = array(
                'status' => 'error',
                'msg' => "Số Momo Không Tồn Tại Trên Hệ Thống"
            );
            die(json_encode($return));
        } else {
            $momo = new MomoV2($soicoder);
            $content = "Thưởng Nhập Code | ".$code;
            $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$account."' LIMIT 1 " , 1);
            $send = $momo->LoadData($loadDATA)->SendMoney($phone,$data['money'],$content);
            // print_r($send); die;
            
            if ($send['status'] == 'success') {
                
                $soicoder->insert('code_his' , array (
                    'code' => $code,
                    'momo' => $phone,
                    'momo_reward' => $account,
                    'day' => ''.date('d/m/Y').'',
                    'money' => $data['money'],
                    'time' => time()
                ));
                
                $soicoder->update("code", array(
                    'entered' => $data['entered'] + 1,
                ), "`code` = '".$code."'");
    
                $return = array(
                    'status' => 'success',
                    'msg' => "Nhận Tiền Thành Công"
                );
                die(json_encode($return));
            } else {
                $return = array(
                    'status' => 'error',
                    'msg' => "Lỗi Momo, Vui Lòng Liên Hệ Admin"
                );
                die(json_encode($return));
            }
        }
    }
} else {
    $return = array(
        'status' => 'error',
        'msg' => "Bạn Đã Nhận Thưởng Từ Code Này"
    );
    die(json_encode($return));
}

